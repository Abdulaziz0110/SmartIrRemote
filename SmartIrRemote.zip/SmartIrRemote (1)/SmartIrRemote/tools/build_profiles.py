#!/usr/bin/env python3
"""
Build Smart IR Remote profile JSON files from public IR databases.

Supported inputs (auto-detected per file):
  * Flipper-IRDB  *.ir   (UberGuidoZ/Flipper-IRDB, CC0-1.0)   parsed NEC/NECext/Samsung32/SIRC*/RC5/RC6 + raw
  * probonopd/irdb *.csv (CC0-1.0)  functionname,protocol,device,subdevice,function

Usage:
  git clone --depth 1 https://github.com/UberGuidoZ/Flipper-IRDB
  python tools/build_profiles.py Flipper-IRDB --out-dir app/src/main/assets/profiles --license CC0-1.0 \
         --source "UberGuidoZ/Flipper-IRDB"
Then bump ProfileRepository.SEED_VERSION (or reinstall) and rebuild, or import the produced
JSON files via Settings > Import IR profiles (multiple files can be selected).

Always verify the license of the repository you convert. Unknown / unsupported signals are skipped.
"""
import argparse, csv, json, os, re, sys
from collections import Counter

NAMES = {
    "POWER": "POWER", "PWR": "POWER", "POWER_TOGGLE": "POWER", "POWER_ON": "POWER_ON", "POWER_OFF": "POWER_OFF",
    "VOL+": "VOLUME_UP", "VOL_UP": "VOLUME_UP", "VOLUME_UP": "VOLUME_UP", "VOLUP": "VOLUME_UP", "VOL_PLUS": "VOLUME_UP",
    "VOL-": "VOLUME_DOWN", "VOL_DN": "VOLUME_DOWN", "VOL_DOWN": "VOLUME_DOWN", "VOLUME_DOWN": "VOLUME_DOWN",
    "VOLDOWN": "VOLUME_DOWN", "VOL_MINUS": "VOLUME_DOWN", "MUTE": "MUTE",
    "CH+": "CHANNEL_UP", "CH_UP": "CHANNEL_UP", "CH_NEXT": "CHANNEL_UP", "CHANNEL_UP": "CHANNEL_UP", "CH_PLUS": "CHANNEL_UP",
    "CH-": "CHANNEL_DOWN", "CH_DN": "CHANNEL_DOWN", "CH_DOWN": "CHANNEL_DOWN", "CH_PREV": "CHANNEL_DOWN",
    "CHANNEL_DOWN": "CHANNEL_DOWN", "CH_MINUS": "CHANNEL_DOWN",
    "MENU": "MENU", "HOME": "HOME", "BACK": "BACK", "RETURN": "BACK", "EXIT": "BACK",
    "OK": "OK", "ENTER": "OK", "SELECT": "OK", "UP": "UP", "DOWN": "DOWN", "LEFT": "LEFT", "RIGHT": "RIGHT",
    "INPUT": "SOURCE", "SOURCE": "SOURCE", "TV_INPUT": "SOURCE", "SETTINGS": "SETTINGS",
    "TEMP_UP": "TEMP_UP", "TEMP+": "TEMP_UP", "TEMP_DOWN": "TEMP_DOWN", "TEMP_DN": "TEMP_DOWN", "TEMP-": "TEMP_DOWN",
    "MODE": "MODE", "FAN": "FAN_SPEED", "FAN_SPEED": "FAN_SPEED", "SWING": "SWING",
    "SPEED_UP": "SPEED_UP", "SPEED_DOWN": "SPEED_DOWN", "SPEED+": "SPEED_UP", "SPEED-": "SPEED_DOWN",
    "BRIGHT_UP": "BRIGHTNESS_UP", "BRIGHTNESS_UP": "BRIGHTNESS_UP", "BRIGHT_DOWN": "BRIGHTNESS_DOWN",
    "BRIGHTNESS_DOWN": "BRIGHTNESS_DOWN", "PLAY": "PLAY_PAUSE", "PAUSE": "PLAY_PAUSE", "PLAY_PAUSE": "PLAY_PAUSE",
    "STOP": "STOP", "REWIND": "REWIND", "RW": "REWIND", "FF": "FORWARD", "FORWARD": "FORWARD",
    "NEXT": "NEXT_TRACK", "PREV": "PREV_TRACK",
}

def norm(name, keep_unknown):
    n = re.sub(r"[\s\-]+", "_", name.strip().upper())
    if n in NAMES: return NAMES[n]
    m = re.fullmatch(r"(?:NUM_?|DIGIT_?|BTN_?)?([0-9])", n)
    if m: return "NUM_" + m.group(1)
    if keep_unknown:
        n = re.sub(r"[^A-Z0-9_]", "", n)
        return n or None
    return None

def category_for(path_parts):
    s = " ".join(path_parts).lower()
    rules = [("air_cond|\\bacs?\\b|aircon|hvac", ["AIR_CONDITIONER"]), ("projector", ["PROJECTOR"]),
             ("soundbar|speaker|audio|receiver|amplifier|hi-?fi|av_", ["AUDIO"]), ("fan", ["FAN"]),
             ("led|light", ["LED_CONTROLLER"]), ("dvd|blu", ["DVD"]), ("streaming|tv_?box|android_box|media_?player", ["TV_BOX"]),
             ("cable|set_?top|satellite|stb|iptv", ["SET_TOP_BOX"]), ("camera|dvr|nvr", ["CAMERA_DVR"]),
             ("\\btvs?\\b|television|monitor|display", ["TV", "SMART_TV"])]
    for pat, cats in rules:
        if re.search(pat, s): return cats
    return ["OTHER"]

def le(hexstr):
    b = bytes(int(x, 16) for x in hexstr.split())
    return int.from_bytes(b, "little"), b

def parse_ir(path):
    """Yield dicts: parsed signals and raw signals from a Flipper .ir file."""
    cur = {}
    def flush():
        if cur.get("name") and cur.get("type"): yield dict(cur)
    with open(path, encoding="utf-8", errors="replace") as fh:
        for line in fh:
            line = line.strip()
            if line.startswith("#") or not line:
                yield from flush(); cur.clear(); continue
            if ":" in line:
                k, v = line.split(":", 1); cur[k.strip().lower()] = v.strip()
    yield from flush()

def convert_flipper(sig):
    """-> (kind, protocol, address, subaddress, bits, code) or ('RAW', freq, data) or None"""
    if sig["type"] == "raw":
        try:
            data = [int(x) for x in sig["data"].split()]
            freq = int(sig.get("frequency", 38000))
        except (KeyError, ValueError):
            return None
        if not data or len(data) > 2000 or any(d <= 0 for d in data) or not 15000 <= freq <= 60000: return None
        return ("RAW", freq, data)
    p = sig.get("protocol", "")
    try:
        a, ab = le(sig["address"]); c, cb = le(sig["command"])
    except (KeyError, ValueError):
        return None
    if p == "NEC" and a < 256 and c < 256: return ("P", "NEC", a, 0, 0, c)
    if p == "NECext" and a < 65536 and len(cb) >= 2 and cb[1] == (~cb[0] & 255): return ("P", "NEC_EXT", a, 0, 0, cb[0])
    if p == "Samsung32" and a < 256 and c < 256: return ("P", "SAMSUNG", a, 0, 0, c)
    if p == "SIRC" and a < 32 and c < 128: return ("P", "SONY_SIRC", a, 0, 12, c)
    if p == "SIRC15" and a < 256 and c < 128: return ("P", "SONY_SIRC", a, 0, 15, c)
    if p == "SIRC20" and c < 128: return ("P", "SONY_SIRC", a & 31, (a >> 5) & 255, 20, c)
    if p == "RC5" and a < 32 and c < 128: return ("P", "RC5", a, 0, 0, c)
    if p == "RC6" and a < 256 and c < 256: return ("P", "RC6", a, 0, 0, c)
    return None

CSV_PROTO = {"NEC1": "NEC", "NEC2": "NEC", "Samsung32": "SAMSUNG", "Sony12": "SONY_SIRC", "Sony15": "SONY_SIRC",
             "Sony20": "SONY_SIRC", "RC5": "RC5", "JVC": "JVC", "Sharp": "SHARP"}
CSV_BITS = {"Sony12": 12, "Sony15": 15, "Sony20": 20}

def slug(s): return re.sub(r"[^a-z0-9]+", "_", s.lower()).strip("_")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("roots", nargs="+"); ap.add_argument("--out-dir", required=True)
    ap.add_argument("--source", default=""); ap.add_argument("--license", default="CC0-1.0")
    ap.add_argument("--per-file", type=int, default=1500, help="profiles per output JSON")
    ap.add_argument("--keep-unknown", action="store_true", help="keep buttons with non-standard names")
    a = ap.parse_args()
    profiles, skipped = {}, Counter()

    def add(pid, brand, model, cats, proto, addr, sub, bits, key, cmd, src):
        p = profiles.setdefault(pid, {"id": pid, "brand": brand, "model": model, "categories": cats, "protocol": proto,
                                      "address": addr, "subAddress": sub, "bits": bits, "commands": {}, "source": src})
        p["commands"].setdefault(key, cmd)

    for root in a.roots:
        for dp, _, files in os.walk(root):
            for f in files:
                full = os.path.join(dp, f)
                parts = os.path.relpath(full, root).split(os.sep)
                src = a.source or os.path.basename(os.path.abspath(root))
                if f.endswith(".ir"):
                    cats = category_for([parts[0]] if len(parts) > 1 else ["other"])
                    brand = parts[1] if len(parts) > 2 else (parts[0] if len(parts) > 1 else "Unknown")
                    brand = brand.replace("_", " "); model = os.path.splitext(f)[0].replace("_", " ")
                    base = slug("_".join(parts[:-1] + [os.path.splitext(f)[0]]))
                    for sig in parse_ir(full):
                        key = norm(sig["name"], a.keep_unknown)
                        if not key: skipped["unnamed"] += 1; continue
                        r = convert_flipper(sig)
                        if r is None: skipped[sig.get("protocol", sig["type"])] += 1; continue
                        if r[0] == "RAW":
                            add(base + "_raw", brand, model + " (raw)", cats, "RAW", 0, 0, 0, key,
                                {"frequency": r[1], "raw": r[2]}, src)
                        else:
                            _, proto, addr, sub, bits, code = r
                            add(f"{base}_{proto.lower()}_{addr}_{sub}", brand, model, cats, proto, addr, sub, bits,
                                key, {"code": code}, src)
                elif f.endswith(".csv"):
                    brand = parts[0].replace("_", " ")
                    cats = category_for([parts[1]]) if len(parts) > 2 else ["TV", "SMART_TV"]
                    model = parts[1].replace("_", " ") if len(parts) > 2 else ""
                    with open(full, newline="", encoding="utf-8", errors="replace") as fh:
                        for row in csv.DictReader(fh):
                            proto = CSV_PROTO.get(row.get("protocol", ""))
                            key = norm(row.get("functionname", ""), a.keep_unknown)
                            if not proto or not key: skipped[row.get("protocol", "?")] += 1; continue
                            try: dev, sub, fn = int(row["device"]), int(row["subdevice"]), int(row["function"])
                            except (ValueError, KeyError): continue
                            if proto == "NEC" and dev > 255: proto = "NEC_EXT"
                            sub = max(sub, 0) if proto == "SONY_SIRC" else 0
                            pid = slug(f"{brand}_{model}_{row['protocol']}_{dev}_{sub}")
                            add(pid, brand, model, cats, proto, dev, sub, CSV_BITS.get(row["protocol"], 0),
                                key, {"code": fn}, src)

    plist = [p for p in profiles.values() if p["commands"]]
    plist.sort(key=lambda p: (p["brand"].lower(), p["id"]))
    os.makedirs(a.out_dir, exist_ok=True)
    n = 0
    for i in range(0, len(plist), a.per_file):
        n += 1
        out = {"schema": 1, "source": a.source, "license": a.license, "profiles": plist[i:i + a.per_file]}
        with open(os.path.join(a.out_dir, f"db_{n:03d}.json"), "w", encoding="utf-8") as fh:
            json.dump(out, fh, separators=(",", ":"))
    brands = len({p["brand"].lower() for p in plist})
    print(f"{len(plist)} profiles, {brands} brands -> {n} file(s) in {a.out_dir}", file=sys.stderr)
    print("skipped (unsupported/unnamed):", dict(skipped.most_common(8)), file=sys.stderr)

if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""
Split the file made by the app's "Export ALL profiles" into smaller bundle files for assets/profiles/.

    python tools/split_export.py smart_ir_profiles.json app/src/main/assets/profiles --per-file 2000

The export has one profile per line, so this runs in constant memory.
"""
import argparse, os, sys

HEADER = '{"schema":1,"source":"Smart IR Remote bundle","license":"CC0-1.0 (Flipper-IRDB, probonopd/irdb)","profiles":['

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("export"); ap.add_argument("out_dir")
    ap.add_argument("--per-file", type=int, default=2000)
    ap.add_argument("--prefix", default="bundle")
    a = ap.parse_args()
    os.makedirs(a.out_dir, exist_ok=True)
    chunk, n_files, total = [], 0, 0

    def flush():
        nonlocal chunk, n_files
        if not chunk: return
        n_files += 1
        with open(os.path.join(a.out_dir, f"{a.prefix}_{n_files:03d}.json"), "w", encoding="utf-8") as f:
            f.write(HEADER + "\n" + ",\n".join(chunk) + "\n]}\n")
        chunk = []

    with open(a.export, encoding="utf-8") as src:
        next(src)  # header line
        for line in src:
            t = line.strip().rstrip(",")
            if t.startswith("]"): break
            if t.startswith("{"):
                chunk.append(t); total += 1
                if len(chunk) >= a.per_file: flush()
    flush()
    print(f"{total} profiles -> {n_files} file(s) in {a.out_dir}", file=sys.stderr)

if __name__ == "__main__":
    main()

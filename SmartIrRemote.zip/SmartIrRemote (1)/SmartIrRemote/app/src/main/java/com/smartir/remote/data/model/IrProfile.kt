package com.smartir.remote.data.model

import com.smartir.remote.ir.IrProtocol
import kotlinx.serialization.Serializable

@Serializable
data class CommandDef(
    val code: Int? = null,
    val frequency: Int? = null,
    val raw: List<Int>? = null,
)

@Serializable
data class IrProfile(
    val id: String,
    val brand: String,
    val model: String = "",
    val categories: List<String>,
    val protocol: IrProtocol,
    val address: Int = 0,
    val subAddress: Int = 0,
    val bits: Int = 0,
    val commands: Map<String, CommandDef>,
    val source: String = "",
    val license: String = "",
    val notes: String = "",
) {
    val displayName: String get() = if (model.isBlank()) brand else "$brand $model"
}

@Serializable
data class ProfileFile(
    val schema: Int = 1,
    val source: String = "",
    val license: String = "",
    val profiles: List<IrProfile>,
)

@Serializable
data class BackupFile(
    val schema: Int = 1,
    val remotes: List<com.smartir.remote.data.db.RemoteEntity> = emptyList(),
    /** profiles owned by the user plus every profile used by a saved remote */
    val userProfiles: List<IrProfile> = emptyList(),
)

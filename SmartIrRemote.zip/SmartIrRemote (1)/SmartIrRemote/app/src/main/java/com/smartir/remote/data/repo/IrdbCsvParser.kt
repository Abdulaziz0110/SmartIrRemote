package com.smartir.remote.data.repo

import com.smartir.remote.data.model.CommandDef
import com.smartir.remote.data.model.IrProfile
import com.smartir.remote.ir.IrProtocol

/** Converts one probonopd/irdb (CC0-1.0) CSV file: codes/<Brand>/<Type>/<device,subdevice>.csv */
object IrdbCsvParser {
    const val SOURCE = "probonopd/irdb"
    const val LICENSE = "CC0-1.0"

    private val PROTO = mapOf(
        "NEC1" to IrProtocol.NEC, "NEC2" to IrProtocol.NEC, "Samsung32" to IrProtocol.SAMSUNG,
        "Sony12" to IrProtocol.SONY_SIRC, "Sony15" to IrProtocol.SONY_SIRC, "Sony20" to IrProtocol.SONY_SIRC,
        "RC5" to IrProtocol.RC5, "JVC" to IrProtocol.JVC, "Sharp" to IrProtocol.SHARP,
    )
    private val BITS = mapOf("Sony12" to 12, "Sony15" to 15, "Sony20" to 20)

    private class Acc(val id: String, val p: IrProtocol, val addr: Int, val sub: Int, val bits: Int) {
        val commands = LinkedHashMap<String, CommandDef>()
    }

    private fun slug(s: String) = s.lowercase().replace(Regex("[^a-z0-9]+"), "_").trim('_')

    /** @param parts path inside the repository, e.g. ["codes", "LG", "TV", "4,-1.csv"] */
    fun parse(text: String, parts: List<String>, source: String = SOURCE): List<IrProfile> {
        if (parts.size < 3 || parts[0] != "codes") return emptyList()
        val brand = parts[1].replace('_', ' ')
        val type = if (parts.size > 3) parts[2] else ""
        val cats = if (type.isBlank()) listOf("TV", "SMART_TV") else FlipperIrParser.categoryFor(type)
        val model = type.replace('_', ' ')
        val accs = LinkedHashMap<String, Acc>()
        var first = true
        for (line in text.lineSequence()) {
            if (first) { first = false; if (line.startsWith("functionname", ignoreCase = true)) continue }
            val c = line.split(',')
            if (c.size < 5) continue
            val key = FlipperIrParser.normName(c[0]) ?: continue
            var p = PROTO[c[1].trim()] ?: continue
            val dev = c[2].trim().toIntOrNull() ?: continue
            var sub = c[3].trim().toIntOrNull() ?: continue
            val fn = c[4].trim().toIntOrNull() ?: continue
            if (p == IrProtocol.NEC && dev > 255) p = IrProtocol.NEC_EXT
            sub = if (p == IrProtocol.SONY_SIRC) maxOf(sub, 0) else 0
            val id = slug("irdb_${parts[1]}_${type}_${c[1].trim()}_${dev}_$sub")
            accs.getOrPut(id) { Acc(id, p, dev, sub, BITS[c[1].trim()] ?: 0) }.commands.putIfAbsent(key, CommandDef(code = fn))
        }
        return accs.values.filter { it.commands.isNotEmpty() }.map {
            IrProfile(
                id = it.id, brand = brand, model = model, categories = cats, protocol = it.p,
                address = it.addr, subAddress = it.sub, bits = it.bits, commands = it.commands,
                source = source, license = LICENSE,
            )
        }
    }
}

package com.smartir.remote.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.smartir.remote.R
import com.smartir.remote.domain.CompatStatus
import com.smartir.remote.domain.DeviceCategory

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppTopBar(title: String, onBack: (() -> Unit)?, actions: @Composable RowScope.() -> Unit = {}) {
    TopAppBar(
        title = { Text(title) },
        navigationIcon = {
            if (onBack != null) IconButton(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, contentDescription = stringResource(R.string.nav_back))
            }
        },
        actions = actions,
    )
}

@Composable
fun CategoryGrid(onClick: (DeviceCategory) -> Unit, counts: Map<String, Int> = emptyMap(), modifier: Modifier = Modifier) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(3), modifier = modifier,
        contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        items(DeviceCategory.entries.toList()) { c -> CategoryTile(c, counts[c.name] ?: 0, onClick) }
    }
}

@Composable
fun CategoryTile(c: DeviceCategory, count: Int = -1, onClick: (DeviceCategory) -> Unit) {
    Card(Modifier.fillMaxWidth().clickable { onClick(c) }) {
        Column(
            Modifier.fillMaxWidth().padding(12.dp).heightIn(min = 88.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
        ) {
            Icon(c.icon, null, Modifier.size(32.dp), tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(6.dp))
            Text(stringResource(c.labelRes), style = MaterialTheme.typography.labelMedium, textAlign = TextAlign.Center)
            if (count >= 0) Text(count.toString(), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun CategoryChoiceDialog(category: DeviceCategory, onChoose: (DeviceCategory, Boolean) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(category.labelRes)) },
        text = { Text(stringResource(R.string.choice_title)) },
        confirmButton = {
            TextButton(onClick = { onChoose(category, true); onDismiss() }) { Text(stringResource(R.string.home_auto_scan)) }
        },
        dismissButton = {
            TextButton(onClick = { onChoose(category, false); onDismiss() }) { Text(stringResource(R.string.home_manual)) }
        },
    )
}

@Composable
fun StatusChip(status: String) {
    val s = runCatching { CompatStatus.valueOf(status) }.getOrDefault(CompatStatus.UNVERIFIED)
    val color = when (s) {
        CompatStatus.FULL -> MaterialTheme.colorScheme.primaryContainer
        CompatStatus.PARTIAL -> MaterialTheme.colorScheme.tertiaryContainer
        CompatStatus.UNVERIFIED -> MaterialTheme.colorScheme.surfaceVariant
    }
    Surface(color = color, shape = MaterialTheme.shapes.small) {
        Text(stringResource(s.labelRes), Modifier.padding(horizontal = 8.dp, vertical = 4.dp), style = MaterialTheme.typography.labelMedium)
    }
}

fun fmtTime(ms: Long): String = "%02d:%02d".format(ms / 60000, (ms / 1000) % 60)

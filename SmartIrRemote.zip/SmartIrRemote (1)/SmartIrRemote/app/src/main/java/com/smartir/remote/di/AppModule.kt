package com.smartir.remote.di

import android.content.Context
import androidx.room.Room
import com.smartir.remote.data.db.*
import com.smartir.remote.ir.AndroidIrTransmitter
import com.smartir.remote.ir.IrTransmitter
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {
    @Provides @Singleton
    fun db(@ApplicationContext ctx: Context): AppDatabase =
        Room.databaseBuilder(ctx, AppDatabase::class.java, "smart_ir.db").addMigrations(MIGRATION_1_2).build()

    @Provides fun profileDao(db: AppDatabase): ProfileDao = db.profiles()
    @Provides fun remoteDao(db: AppDatabase): RemoteDao = db.remotes()
    @Provides fun historyDao(db: AppDatabase): HistoryDao = db.history()
    @Provides fun macroDao(db: AppDatabase): MacroDao = db.macros()

    @Provides @Singleton
    fun transmitter(impl: AndroidIrTransmitter): IrTransmitter = impl
}

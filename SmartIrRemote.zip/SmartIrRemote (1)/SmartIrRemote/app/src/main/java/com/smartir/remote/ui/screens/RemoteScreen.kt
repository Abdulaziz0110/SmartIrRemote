package com.smartir.remote.ui.screens

import android.content.Intent
import android.view.KeyEvent
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.smartir.remote.R
import com.smartir.remote.domain.Cmd
import com.smartir.remote.domain.DeviceCategory
import com.smartir.remote.ui.HardwareKeys
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val REPEATABLE = setOf(
    Cmd.VOLUME_UP, Cmd.VOLUME_DOWN, Cmd.CHANNEL_UP, Cmd.CHANNEL_DOWN, Cmd.UP, Cmd.DOWN, Cmd.LEFT, Cmd.RIGHT,
    Cmd.TEMP_UP, Cmd.TEMP_DOWN, Cmd.SPEED_UP, Cmd.SPEED_DOWN, Cmd.BRIGHTNESS_UP, Cmd.BRIGHTNESS_DOWN,
)

/** Keys with a fixed place on the TV-style layout (everything else goes to Functions / Other). */
private val TV_PLACED: Set<String> = setOf(
    Cmd.POWER, "POWER_ON", "POWER_OFF", Cmd.SOURCE, Cmd.SETTINGS, Cmd.VOLUME_UP, Cmd.VOLUME_DOWN, Cmd.MUTE, "INFO",
    Cmd.CHANNEL_UP, Cmd.CHANNEL_DOWN, Cmd.UP, Cmd.DOWN, Cmd.LEFT, Cmd.RIGHT, Cmd.OK, Cmd.BACK, Cmd.HOME, Cmd.MENU,
    "PREV_TRACK", "REWIND", "PLAY_PAUSE", "FORWARD", "NEXT_TRACK", "STOP", "RECORD", "EJECT",
    "RED", "GREEN", "YELLOW", "BLUE", "LAST", "CH_LIST",
) + (0..9).map { Cmd.num(it) }

private val TV_FUNCTIONS = listOf(
    "GUIDE", "SUBTITLE", "TEXT", "FAV", "SLEEP", "ASPECT", "PICTURE", "SOUND",
    "APPS", "SMART_HUB", "NETFLIX", "YOUTUBE", "TIMER", "TV",
)
private val AC_PLACED = setOf(Cmd.POWER, "POWER_ON", "POWER_OFF", Cmd.TEMP_UP, Cmd.TEMP_DOWN, Cmd.MODE, Cmd.FAN_SPEED, Cmd.SWING)
private val AC_FUNCTIONS = listOf("ECO", "TURBO", "SLEEP", "TIMER", "INFO")
private val FAN_PLACED = setOf(Cmd.POWER, "POWER_ON", "POWER_OFF", Cmd.SPEED_UP, Cmd.SPEED_DOWN, Cmd.MODE, Cmd.SWING)
private val FAN_FUNCTIONS = listOf("TIMER", "SLEEP", "ECO", "INFO")
private val LED_PLACED = setOf(Cmd.POWER, "POWER_ON", "POWER_OFF", Cmd.BRIGHTNESS_UP, Cmd.BRIGHTNESS_DOWN, Cmd.MODE)
private val LED_FUNCTIONS = listOf("TIMER", "SLEEP")

private class KeyCtx(
    val available: Set<String>,
    val hidden: Set<String>,
    /** buttons the user confirmed with WORKS */
    val verified: Set<String>,
    val editing: Boolean,
    val haptic: Boolean,
    val onSend: (String) -> Unit,
    val onEdit: (String) -> Unit,
) {
    fun shown(k: String?): Boolean = k != null && k in available && (k !in hidden || editing)
    fun has(k: String?): Boolean = k != null && k in available
}

@Composable
private fun KeyLabel(k: String) {
    when (k) {
        Cmd.UP -> Icon(Icons.Filled.KeyboardArrowUp, "Up", Modifier.size(40.dp))
        Cmd.DOWN -> Icon(Icons.Filled.KeyboardArrowDown, "Down", Modifier.size(40.dp))
        Cmd.LEFT -> Icon(Icons.Filled.KeyboardArrowLeft, "Left", Modifier.size(40.dp))
        Cmd.RIGHT -> Icon(Icons.Filled.KeyboardArrowRight, "Right", Modifier.size(40.dp))
        Cmd.POWER -> Icon(Icons.Filled.PowerSettingsNew, "Power", Modifier.size(32.dp))
        else -> {
            val label = Cmd.label(k)
            Text(
                label,
                style = when {
                    k.startsWith("NUM_") -> MaterialTheme.typography.headlineSmall
                    label.length > 8 -> MaterialTheme.typography.labelLarge
                    else -> MaterialTheme.typography.titleMedium
                },
                fontWeight = FontWeight.SemiBold, maxLines = 1, textAlign = TextAlign.Center, overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
private fun RemoteKey(k: String, c: KeyCtx, modifier: Modifier, height: Dp) {
    val scope = rememberCoroutineScope()
    val hf = LocalHapticFeedback.current
    val isPower = k.startsWith("POWER")
    val custom = when (k) {
        "RED" -> Color(0xFFD32F2F); "GREEN" -> Color(0xFF388E3C)
        "YELLOW" -> Color(0xFFFBC02D); "BLUE" -> Color(0xFF1976D2); else -> null
    }
    val base = if (isPower) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.secondaryContainer
    val content = when {
        custom == null -> contentColorFor(base)
        k == "YELLOW" -> Color.Black
        else -> Color.White
    }
    Surface(
        color = custom ?: base, contentColor = content,
        shape = RoundedCornerShape(if (height >= 70.dp) 24.dp else 16.dp),
        modifier = modifier
            .height(height)
            .alpha(if (k in c.hidden) 0.35f else 1f)
            .pointerInput(k, c.editing) {
                detectTapGestures(onPress = {
                    if (c.editing) {
                        tryAwaitRelease(); c.onEdit(k)
                    } else {
                        val job = scope.launch {
                            if (c.haptic) hf.performHapticFeedback(HapticFeedbackType.LongPress)
                            c.onSend(k)
                            if (k in REPEATABLE) { // hold to repeat
                                delay(450)
                                while (true) { c.onSend(k); delay(170) }
                            }
                        }
                        tryAwaitRelease(); job.cancel()
                    }
                })
            },
    ) {
        Box(Modifier.fillMaxSize().padding(horizontal = 6.dp), contentAlignment = Alignment.Center) {
            KeyLabel(k)
            if (k in c.verified) {
                Text("✓", Modifier.align(Alignment.TopEnd).padding(top = 3.dp, end = 3.dp), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

/** A key, or an empty slot of the same size so that every other key stays in its place. */
@Composable
private fun KeyOrGap(k: String?, c: KeyCtx, modifier: Modifier, height: Dp) {
    if (k != null && c.shown(k)) RemoteKey(k, c, modifier, height) else Spacer(modifier.height(height))
}

@Composable
private fun KeyRow(c: KeyCtx, height: Dp, vararg keys: String?) {
    if (keys.none { c.shown(it) }) return
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        keys.forEach { KeyOrGap(it, c, Modifier.weight(1f), height) }
    }
}

@Composable
private fun RowScope.KeyStack(c: KeyCtx, vararg keys: String?) {
    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        keys.forEach { KeyOrGap(it, c, Modifier.fillMaxWidth(), 64.dp) }
    }
}

@Composable
private fun KeyGrid(c: KeyCtx, keys: List<String>, columns: Int = 3, height: Dp = 56.dp) {
    keys.filter { c.shown(it) }.chunked(columns).forEach { row ->
        val padded: List<String?> = row + List<String?>(columns - row.size) { null }
        KeyRow(c, height, *padded.toTypedArray())
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun RemoteScreen(onBack: () -> Unit, vm: RemoteViewModel = hiltViewModel()) {
    val st by vm.state.collectAsStateWithLifecycle()
    val prefs by vm.prefs.collectAsStateWithLifecycle()
    val macros by vm.macros.collectAsStateWithLifecycle()
    val timer by vm.timer.collectAsStateWithLifecycle()
    val running by vm.runningMacro.collectAsStateWithLifecycle()
    val fix by vm.fix.collectAsStateWithLifecycle()
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(Unit) { vm.messages.collect { snack.showSnackbar(it) } }

    val view = LocalView.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    DisposableEffect(prefs.keepScreenOn) {
        view.keepScreenOn = prefs.keepScreenOn
        onDispose { view.keepScreenOn = false }
    }
    DisposableEffect(prefs.volumeKeys, st.available) {
        if (prefs.volumeKeys && (Cmd.VOLUME_UP in st.available || Cmd.VOLUME_DOWN in st.available)) {
            HardwareKeys.handler = { code ->
                val k = if (code == KeyEvent.KEYCODE_VOLUME_UP) Cmd.VOLUME_UP else Cmd.VOLUME_DOWN
                if (k in st.available) vm.send(k)
                true
            }
        }
        onDispose { HardwareKeys.handler = null }
    }

    var menu by remember { mutableStateOf(false) }
    var showRename by remember { mutableStateOf(false) }
    var showMacros by remember { mutableStateOf(false) }
    var showNewMacro by remember { mutableStateOf(false) }
    var showTimer by remember { mutableStateOf(false) }
    var showTips by remember { mutableStateOf(false) }

    val r = st.remote
    val hidden = r?.hiddenSet() ?: emptySet()
    val cat = st.category
    val c = KeyCtx(st.available, hidden, r?.verifiedSet() ?: emptySet(), st.editing, prefs.haptic, vm::send, vm::startFix)
    val placed = when (cat) {
        DeviceCategory.AIR_CONDITIONER -> AC_PLACED
        DeviceCategory.FAN -> FAN_PLACED
        DeviceCategory.LED_CONTROLLER -> LED_PLACED
        else -> TV_PLACED
    }
    val functions = when (cat) {
        DeviceCategory.AIR_CONDITIONER -> AC_FUNCTIONS
        DeviceCategory.FAN -> FAN_FUNCTIONS
        DeviceCategory.LED_CONTROLLER -> LED_FUNCTIONS
        else -> TV_FUNCTIONS
    }
    val extra = st.available.filter { it !in placed && it !in functions }.sorted()

    Scaffold(
        topBar = {
            AppTopBar(r?.name ?: "", onBack) {
                IconButton(onClick = vm::toggleFavorite) {
                    Icon(if (r?.favorite == true) Icons.Filled.Star else Icons.Filled.StarBorder, null)
                }
                Box {
                    IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, null) }
                    DropdownMenu(menu, { menu = false }) {
                        DropdownMenuItem(
                            text = { Text(stringResource(if (st.editing) R.string.remote_done else R.string.remote_edit)) },
                            onClick = { menu = false; vm.setEditing(!st.editing) },
                        )
                        DropdownMenuItem(text = { Text(stringResource(R.string.macros)) }, onClick = { menu = false; showMacros = true })
                        DropdownMenuItem(text = { Text(stringResource(R.string.timer)) }, onClick = { menu = false; showTimer = true })
                        DropdownMenuItem(text = { Text(stringResource(R.string.remote_rename)) }, onClick = { menu = false; showRename = true })
                        DropdownMenuItem(text = { Text(stringResource(R.string.tips_title)) }, onClick = { menu = false; showTips = true })
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.remote_share)) },
                            onClick = {
                                menu = false
                                scope.launch {
                                    val t = vm.exportText() ?: return@launch
                                    val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, t) }
                                    ctx.startActivity(Intent.createChooser(send, null))
                                }
                            },
                        )
                    }
                }
            }
        },
        snackbarHost = { SnackbarHost(snack) },
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            if (r != null) StatusChip(r.status)
            if (st.editing) {
                Text(stringResource(R.string.edit_hint), style = MaterialTheme.typography.bodySmall)
                TextButton(onClick = { vm.setEditing(false) }) { Text(stringResource(R.string.remote_done)) }
            }
            running?.let { name ->
                AssistChip(onClick = vm::cancelMacro, label = { Text(stringResource(R.string.macro_running, name)) })
            }
            timer?.let { t ->
                var now by remember(t) { mutableLongStateOf(System.currentTimeMillis()) }
                LaunchedEffect(t) { while (true) { now = System.currentTimeMillis(); delay(1000) } }
                AssistChip(
                    onClick = vm::cancelTimer,
                    label = { Text(stringResource(R.string.timer_left, Cmd.label(t.cmd), fmtTime(maxOf(0L, t.endAtMs - now)))) },
                )
            }

            when (cat) {
                DeviceCategory.AIR_CONDITIONER -> {
                    KeyRow(c, 64.dp, Cmd.POWER, "POWER_ON", "POWER_OFF")
                    KeyRow(c, 100.dp, Cmd.TEMP_DOWN, Cmd.TEMP_UP)
                    KeyRow(c, 64.dp, Cmd.MODE, Cmd.FAN_SPEED, Cmd.SWING)
                }
                DeviceCategory.FAN -> {
                    KeyRow(c, 64.dp, Cmd.POWER, "POWER_ON", "POWER_OFF")
                    KeyRow(c, 100.dp, Cmd.SPEED_DOWN, Cmd.SPEED_UP)
                    KeyRow(c, 64.dp, Cmd.MODE, Cmd.SWING, null)
                }
                DeviceCategory.LED_CONTROLLER -> {
                    KeyRow(c, 64.dp, Cmd.POWER, "POWER_ON", "POWER_OFF")
                    KeyRow(c, 100.dp, Cmd.BRIGHTNESS_DOWN, Cmd.BRIGHTNESS_UP)
                    KeyRow(c, 64.dp, Cmd.MODE, null, null)
                }
                else -> {
                    KeyRow(c, 60.dp, Cmd.POWER, Cmd.SOURCE, Cmd.SETTINGS)
                    KeyRow(c, 52.dp, "POWER_ON", "POWER_OFF", null)
                    if (listOf(Cmd.VOLUME_UP, Cmd.VOLUME_DOWN, Cmd.MUTE, "INFO", Cmd.CHANNEL_UP, Cmd.CHANNEL_DOWN).any { c.shown(it) }) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            KeyStack(c, Cmd.VOLUME_UP, Cmd.VOLUME_DOWN)
                            KeyStack(c, Cmd.MUTE, "INFO")
                            KeyStack(c, Cmd.CHANNEL_UP, Cmd.CHANNEL_DOWN)
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    KeyRow(c, 76.dp, null, Cmd.UP, null)
                    KeyRow(c, 76.dp, Cmd.LEFT, Cmd.OK, Cmd.RIGHT)
                    KeyRow(c, 76.dp, null, Cmd.DOWN, null)
                    Spacer(Modifier.height(6.dp))
                    KeyRow(c, 60.dp, Cmd.BACK, Cmd.HOME, Cmd.MENU)
                    KeyRow(c, 52.dp, "PREV_TRACK", "REWIND", "PLAY_PAUSE", "FORWARD", "NEXT_TRACK")
                    KeyRow(c, 52.dp, "STOP", "RECORD", "EJECT")
                    KeyRow(c, 44.dp, "RED", "GREEN", "YELLOW", "BLUE")
                    Spacer(Modifier.height(6.dp))
                    KeyRow(c, 64.dp, Cmd.num(1), Cmd.num(2), Cmd.num(3))
                    KeyRow(c, 64.dp, Cmd.num(4), Cmd.num(5), Cmd.num(6))
                    KeyRow(c, 64.dp, Cmd.num(7), Cmd.num(8), Cmd.num(9))
                    KeyRow(c, 64.dp, "LAST", Cmd.num(0), "CH_LIST")
                }
            }
            if (functions.any { c.shown(it) }) {
                Text(stringResource(R.string.remote_functions), style = MaterialTheme.typography.titleSmall)
                KeyGrid(c, functions)
            }
            if (extra.any { c.shown(it) }) {
                Text(stringResource(R.string.remote_other), style = MaterialTheme.typography.titleSmall)
                KeyGrid(c, extra)
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    fix?.let { f ->
        val overridden = r?.overrideMap()?.containsKey(f.cmd) == true
        AlertDialog(
            onDismissRequest = vm::closeFix,
            title = { Text(stringResource(R.string.fix_title) + ": " + Cmd.label(f.cmd)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        if (f.total < 0) stringResource(R.string.fix_loading) else stringResource(R.string.fix_alternatives, f.total),
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    f.alt?.let { Text(stringResource(R.string.fix_trying, it.displayName, f.index + 1, f.total), style = MaterialTheme.typography.bodySmall) }
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { vm.send(f.cmd) }) { Text(stringResource(R.string.fix_send)) }
                        OutlinedButton(onClick = vm::nextFix, enabled = f.total > 0) { Text(stringResource(R.string.fix_next)) }
                        Button(onClick = vm::acceptFix, enabled = f.alt != null) { Text(stringResource(R.string.fix_use)) }
                        if (overridden) OutlinedButton(onClick = { vm.resetKey(f.cmd) }) { Text(stringResource(R.string.fix_reset)) }
                        OutlinedButton(onClick = { vm.toggleHidden(f.cmd) }) {
                            Text(stringResource(if (f.cmd in hidden) R.string.fix_show else R.string.fix_hide))
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = vm::closeFix) { Text(stringResource(R.string.close)) } },
        )
    }

    if (showTips) {
        AlertDialog(
            onDismissRequest = { showTips = false },
            title = { Text(stringResource(R.string.tips_title)) },
            text = { Text(stringResource(R.string.tips_body), Modifier.verticalScroll(rememberScrollState())) },
            confirmButton = { TextButton(onClick = { showTips = false }) { Text(stringResource(R.string.close)) } },
        )
    }

    if (showRename) {
        var name by remember { mutableStateOf(r?.name ?: "") }
        AlertDialog(
            onDismissRequest = { showRename = false },
            title = { Text(stringResource(R.string.remote_rename)) },
            text = { OutlinedTextField(name, { name = it }, singleLine = true, label = { Text(stringResource(R.string.remote_name)) }) },
            confirmButton = { TextButton(onClick = { vm.rename(name); showRename = false }) { Text(stringResource(R.string.save)) } },
            dismissButton = { TextButton(onClick = { showRename = false }) { Text(stringResource(R.string.cancel)) } },
        )
    }

    if (showMacros) {
        AlertDialog(
            onDismissRequest = { showMacros = false },
            title = { Text(stringResource(R.string.macros)) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (macros.isEmpty()) Text(stringResource(R.string.macro_empty))
                    macros.forEach { m ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(m.name, style = MaterialTheme.typography.titleSmall)
                                Text(m.steps.split(',').joinToString(" → ") { Cmd.label(it) }, style = MaterialTheme.typography.bodySmall)
                            }
                            IconButton(onClick = { vm.runMacro(m); showMacros = false }) { Icon(Icons.Filled.PlayArrow, null) }
                            IconButton(onClick = { vm.deleteMacro(m) }) { Icon(Icons.Filled.Delete, null) }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showMacros = false; showNewMacro = true }) { Text(stringResource(R.string.macro_new)) } },
            dismissButton = { TextButton(onClick = { showMacros = false }) { Text(stringResource(R.string.cancel)) } },
        )
    }

    if (showNewMacro) {
        var name by remember { mutableStateOf("") }
        val steps = remember { mutableStateListOf<String>() }
        var delaySec by remember { mutableFloatStateOf(0.5f) }
        AlertDialog(
            onDismissRequest = { showNewMacro = false },
            title = { Text(stringResource(R.string.macro_new)) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(name, { name = it }, singleLine = true, label = { Text(stringResource(R.string.macro_name)) })
                    Text(stringResource(R.string.macro_steps), style = MaterialTheme.typography.titleSmall)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        st.available.sorted().forEach { k -> AssistChip(onClick = { steps.add(k) }, label = { Text(Cmd.label(k)) }) }
                    }
                    if (steps.isNotEmpty()) {
                        Text(steps.joinToString(" → ") { Cmd.label(it) }, style = MaterialTheme.typography.bodyMedium)
                        TextButton(onClick = { steps.removeAt(steps.lastIndex) }) { Text(stringResource(R.string.macro_undo)) }
                    }
                    Text(stringResource(R.string.macro_delay, delaySec))
                    Slider(delaySec, { delaySec = Math.round(it * 10) / 10f }, valueRange = 0.3f..3f)
                }
            },
            confirmButton = {
                TextButton(
                    enabled = steps.isNotEmpty() && name.isNotBlank(),
                    onClick = { vm.saveMacro(name, steps.toList(), (delaySec * 1000).toLong()); showNewMacro = false },
                ) { Text(stringResource(R.string.save)) }
            },
            dismissButton = { TextButton(onClick = { showNewMacro = false }) { Text(stringResource(R.string.cancel)) } },
        )
    }

    if (showTimer) {
        val keys = st.available.sorted()
        var cmd by remember { mutableStateOf(if (Cmd.POWER in st.available) Cmd.POWER else keys.firstOrNull() ?: "") }
        var minutes by remember { mutableFloatStateOf(30f) }
        AlertDialog(
            onDismissRequest = { showTimer = false },
            title = { Text(stringResource(R.string.timer_title)) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(stringResource(R.string.timer_command), style = MaterialTheme.typography.titleSmall)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        keys.forEach { k -> FilterChip(cmd == k, { cmd = k }, { Text(Cmd.label(k)) }) }
                    }
                    Text(stringResource(R.string.timer_minutes, minutes.toInt()))
                    Slider(minutes, { minutes = Math.round(it).toFloat() }, valueRange = 1f..180f)
                    Text(stringResource(R.string.timer_note), style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = {
                TextButton(enabled = cmd.isNotBlank(), onClick = { vm.startTimer(cmd, minutes.toInt()); showTimer = false }) {
                    Text(stringResource(R.string.timer_start))
                }
            },
            dismissButton = { TextButton(onClick = { showTimer = false }) { Text(stringResource(R.string.cancel)) } },
        )
    }
}

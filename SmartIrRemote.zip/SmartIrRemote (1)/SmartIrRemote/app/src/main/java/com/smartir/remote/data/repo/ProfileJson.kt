package com.smartir.remote.data.repo

import com.smartir.remote.data.AppJson
import com.smartir.remote.data.model.IrProfile
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull

/** Reads every profile container format the app produces, so a file never fails on a missing field. */
object ProfileJson {
    class Parsed(val profiles: List<IrProfile>, val skipped: Int)

    /** Accepts: profile file {"profiles":[..]}, backup {"userProfiles":[..]}, a bare array, or one profile. */
    fun parse(text: String): Parsed {
        val root = AppJson.parseToJsonElement(text)
        val obj = root as? JsonObject
        val items: List<JsonElement> = when {
            root is JsonArray -> root
            obj?.get("profiles") is JsonArray -> obj["profiles"] as JsonArray
            obj?.get("userProfiles") is JsonArray -> obj["userProfiles"] as JsonArray
            obj != null && obj.containsKey("id") && obj.containsKey("protocol") -> listOf(obj)
            else -> throw IllegalArgumentException("No IR profiles found in this file")
        }
        val source = (obj?.get("source") as? JsonPrimitive)?.contentOrNull.orEmpty()
        val license = (obj?.get("license") as? JsonPrimitive)?.contentOrNull.orEmpty()
        var skipped = 0
        val out = ArrayList<IrProfile>()
        for (e in items) {
            val p = runCatching { AppJson.decodeFromJsonElement(IrProfile.serializer(), e) }.getOrNull()
            if (p == null) skipped++ else out += p.copy(source = p.source.ifBlank { source }, license = p.license.ifBlank { license })
        }
        return Parsed(out, skipped)
    }
}

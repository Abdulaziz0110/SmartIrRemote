package com.smartir.remote.ui

import android.net.Uri
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.smartir.remote.ui.screens.*

@Composable
fun AppNav(openRemote: Long = -1L, onOpened: () -> Unit = {}) {
    val nav = rememberNavController()
    // opened from a launcher shortcut
    LaunchedEffect(openRemote) {
        if (openRemote > 0) {
            nav.navigate("remote/$openRemote") { launchSingleTop = true }
            onOpened()
        }
    }
    NavHost(nav, startDestination = "home") {
        composable("home") {
            HomeScreen(
                onRemotes = { nav.navigate("remotes") },
                onAdd = { nav.navigate("pick/add") },
                onScan = { nav.navigate("pick/scan") },
                onManual = { nav.navigate("pick/manual") },
                onSearch = { nav.navigate("search") },
                onCustom = { nav.navigate("custom") },
                onIrTest = { nav.navigate("irtest") },
                onSettings = { nav.navigate("settings") },
                onRemote = { nav.navigate("remote/$it") },
                onChoose = { cat, scan -> nav.navigate(if (scan) "scan/$cat" else "manual/$cat") },
            )
        }
        composable("pick/{mode}", listOf(navArgument("mode") { type = NavType.StringType })) { e ->
            PickScreen(
                mode = e.arguments?.getString("mode") ?: "add",
                onBack = { nav.popBackStack() },
                onChoose = { cat, scan -> nav.navigate(if (scan) "scan/$cat" else "manual/$cat") },
            )
        }
        composable("scan/{category}") {
            ScanScreen(
                onBack = { nav.popBackStack() },
                onConfirm = { cat, pid -> nav.navigate("confirm/$cat/${Uri.encode(pid)}") },
            )
        }
        composable("manual/{category}") {
            ManualScreen(
                onBack = { nav.popBackStack() },
                onConfirm = { cat, pid -> nav.navigate("confirm/$cat/${Uri.encode(pid)}") },
            )
        }
        composable("search") {
            SearchScreen(
                onBack = { nav.popBackStack() },
                onPick = { cat, pid -> nav.navigate("confirm/$cat/${Uri.encode(pid)}") },
            )
        }
        composable("custom") {
            CustomRemoteScreen(
                onBack = { nav.popBackStack() },
                onSaved = { id -> nav.navigate("remote/$id") { popUpTo("home") } },
            )
        }
        composable("irtest") { IrTestScreen(onBack = { nav.popBackStack() }) }
        composable("confirm/{category}/{profileId}") {
            ConfirmScreen(
                onBack = { nav.popBackStack() },
                onSaved = { id -> nav.navigate("remote/$id") { popUpTo("home") } },
            )
        }
        composable("remote/{id}", listOf(navArgument("id") { type = NavType.LongType })) {
            RemoteScreen(onBack = { nav.popBackStack() })
        }
        composable("remotes") { RemotesScreen(onBack = { nav.popBackStack() }, onOpen = { nav.navigate("remote/$it") }) }
        composable("settings") { SettingsScreen(onBack = { nav.popBackStack() }, onHistory = { nav.navigate("history") }) }
        composable("history") { HistoryScreen(onBack = { nav.popBackStack() }) }
    }
}

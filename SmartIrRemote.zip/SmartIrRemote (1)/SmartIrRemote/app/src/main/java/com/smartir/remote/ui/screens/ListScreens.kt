package com.smartir.remote.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.smartir.remote.R
import com.smartir.remote.domain.DeviceCategory
import java.text.DateFormat
import java.util.Date

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun RemotesScreen(onBack: () -> Unit, onOpen: (Long) -> Unit, vm: RemotesViewModel = hiltViewModel()) {
    val list by vm.remotes.collectAsStateWithLifecycle()
    var query by remember { mutableStateOf("") }
    var catFilter by remember { mutableStateOf<String?>(null) }
    var renaming by remember { mutableStateOf<com.smartir.remote.data.db.RemoteEntity?>(null) }
    val shown = list.filter { r ->
        (catFilter == null || r.category == catFilter) &&
            (query.isBlank() || r.name.contains(query, true) || r.brand.contains(query, true) || r.model.contains(query, true))
    }
    Scaffold(topBar = { AppTopBar(stringResource(R.string.remotes_title) + " (" + list.size + ")", onBack) }) { pad ->
        Column(Modifier.padding(pad)) {
            if (list.isEmpty()) Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                Text(stringResource(R.string.remotes_empty))
            } else {
                OutlinedTextField(
                    query, { query = it }, singleLine = true,
                    placeholder = { Text(stringResource(R.string.search)) },
                    leadingIcon = { Icon(Icons.Filled.Search, null) },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                )
                FlowRow(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(catFilter == null, { catFilter = null }, { Text(stringResource(R.string.filter_all)) })
                    list.map { it.category }.distinct().forEach { c ->
                        val cat = runCatching { DeviceCategory.valueOf(c) }.getOrNull()
                        if (cat != null) FilterChip(catFilter == c, { catFilter = c }, { Text(stringResource(cat.labelRes)) })
                    }
                }
                LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(shown, key = { it.id }) { r ->
                        val cat = runCatching { DeviceCategory.valueOf(r.category) }.getOrDefault(DeviceCategory.OTHER)
                        var menu by remember { mutableStateOf(false) }
                        Card(Modifier.fillMaxWidth().clickable { onOpen(r.id) }) {
                            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(cat.icon, null, tint = MaterialTheme.colorScheme.primary)
                                Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                                    Text(r.name, style = MaterialTheme.typography.titleMedium)
                                    Text("${stringResource(cat.labelRes)} · ${r.brand} · ${r.protocol}", style = MaterialTheme.typography.bodySmall)
                                    Spacer(Modifier.height(4.dp))
                                    StatusChip(r.status)
                                }
                                IconButton(onClick = { vm.toggleFavorite(r) }) {
                                    Icon(if (r.favorite) Icons.Filled.Star else Icons.Filled.StarBorder, null)
                                }
                                Box {
                                    IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, null) }
                                    DropdownMenu(menu, { menu = false }) {
                                        DropdownMenuItem(text = { Text(stringResource(R.string.remote_rename)) }, onClick = { menu = false; renaming = r })
                                        DropdownMenuItem(text = { Text(stringResource(R.string.duplicate)) }, onClick = { menu = false; vm.duplicate(r) })
                                        DropdownMenuItem(text = { Text(stringResource(R.string.delete)) }, onClick = { menu = false; vm.delete(r) })
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    renaming?.let { r ->
        var name by remember(r.id) { mutableStateOf(r.name) }
        AlertDialog(
            onDismissRequest = { renaming = null },
            title = { Text(stringResource(R.string.remote_rename)) },
            text = { OutlinedTextField(name, { name = it }, singleLine = true, label = { Text(stringResource(R.string.remote_name)) }) },
            confirmButton = { TextButton(onClick = { vm.rename(r, name); renaming = null }) { Text(stringResource(R.string.save)) } },
            dismissButton = { TextButton(onClick = { renaming = null }) { Text(stringResource(R.string.cancel)) } },
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(onBack: () -> Unit, onHistory: () -> Unit, vm: SettingsViewModel = hiltViewModel()) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(Unit) { vm.messages.collect { snack.showSnackbar(it) } }
    var lang by remember { mutableStateOf(vm.language()) }
    var showPaste by remember { mutableStateOf(false) }
    val stats by vm.stats.collectAsStateWithLifecycle()
    val dl by vm.downloading.collectAsStateWithLifecycle()
    val view = androidx.compose.ui.platform.LocalView.current
    DisposableEffect(dl != null) {
        view.keepScreenOn = dl != null // keep the screen awake while the database downloads
        onDispose { view.keepScreenOn = false }
    }

    val importL = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { if (it.isNotEmpty()) vm.importProfiles(it) }
    val restoreL = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let(vm::restore) }
    val exportL = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { it?.let(vm::exportProfiles) }
    val backupL = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { it?.let(vm::backup) }
    val any = arrayOf("*/*")

    Scaffold(topBar = { AppTopBar(stringResource(R.string.settings_title), onBack) }, snackbarHost = { SnackbarHost(snack) }) { pad ->
        Column(Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(stringResource(R.string.set_theme), style = MaterialTheme.typography.titleSmall)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(0 to R.string.theme_system, 1 to R.string.theme_light, 2 to R.string.theme_dark).forEach { (v, l) ->
                    FilterChip(s.theme == v, { vm.setTheme(v) }, { Text(stringResource(l)) })
                }
            }
            Text(stringResource(R.string.set_language), style = MaterialTheme.typography.titleSmall)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("" to stringResource(R.string.lang_system), "uz" to "O'zbekcha", "ru" to "Русский", "en" to "English").forEach { (tag, label) ->
                    FilterChip(lang == tag, { lang = tag; vm.setLanguage(tag) }, { Text(label) })
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(R.string.set_haptic), Modifier.weight(1f))
                Switch(s.haptic, vm::setHaptic)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(R.string.set_volume_keys), Modifier.weight(1f))
                Switch(s.volumeKeys, vm::setVolumeKeys)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(R.string.set_keep_on), Modifier.weight(1f))
                Switch(s.keepScreenOn, vm::setKeepOn)
            }
            HorizontalDivider()
            Text(stringResource(R.string.db_stats, stats.first, stats.second), style = MaterialTheme.typography.titleSmall)
            Button(onClick = vm::downloadDatabase, enabled = dl == null, modifier = Modifier.fillMaxWidth()) {
                Text(dl ?: stringResource(R.string.set_download))
            }
            OutlinedButton({ showPaste = true }, Modifier.fillMaxWidth()) { Text(stringResource(R.string.set_paste)) }
            OutlinedButton({ importL.launch(any) }, Modifier.fillMaxWidth()) { Text(stringResource(R.string.set_import)) }
            OutlinedButton({ exportL.launch("my_ir_profiles.json") }, Modifier.fillMaxWidth()) { Text(stringResource(R.string.set_export)) }
            OutlinedButton({ backupL.launch("smart_ir_backup.json") }, Modifier.fillMaxWidth()) { Text(stringResource(R.string.set_backup)) }
            OutlinedButton({ restoreL.launch(any) }, Modifier.fillMaxWidth()) { Text(stringResource(R.string.set_restore)) }
            OutlinedButton(onHistory, Modifier.fillMaxWidth()) { Text(stringResource(R.string.set_history)) }
        }
    }
    if (showPaste) {
        var text by remember { mutableStateOf("") }
        var cat by remember { mutableStateOf(DeviceCategory.TV) }
        AlertDialog(
            onDismissRequest = { showPaste = false },
            title = { Text(stringResource(R.string.set_paste)) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(stringResource(R.string.paste_hint), style = MaterialTheme.typography.bodySmall)
                    OutlinedTextField(text, { text = it }, minLines = 5, maxLines = 8, modifier = Modifier.fillMaxWidth())
                    Text(stringResource(R.string.paste_category), style = MaterialTheme.typography.labelMedium)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        DeviceCategory.entries.forEach { c -> FilterChip(cat == c, { cat = c }, { Text(stringResource(c.labelRes)) }) }
                    }
                }
            },
            confirmButton = {
                TextButton(enabled = text.isNotBlank(), onClick = { vm.importPasted(text, cat); showPaste = false }) { Text(stringResource(R.string.ok)) }
            },
            dismissButton = { TextButton(onClick = { showPaste = false }) { Text(stringResource(R.string.cancel)) } },
        )
    }
}

@Composable
fun HistoryScreen(onBack: () -> Unit, vm: HistoryViewModel = hiltViewModel()) {
    val items by vm.items.collectAsStateWithLifecycle()
    val df = remember { DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT) }
    Scaffold(topBar = {
        AppTopBar(stringResource(R.string.history_title), onBack) {
            TextButton(onClick = vm::clear, enabled = items.isNotEmpty()) { Text(stringResource(R.string.history_clear)) }
        }
    }) { pad ->
        if (items.isEmpty()) Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) { Text(stringResource(R.string.history_empty)) }
        else LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(items, key = { it.id }) { h ->
                val cat = runCatching { DeviceCategory.valueOf(h.category) }.getOrNull()
                val outcome = when (h.outcome) {
                    "FOUND" -> R.string.outcome_found; "FINISHED" -> R.string.outcome_finished; else -> R.string.outcome_stopped
                }
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text("${cat?.let { stringResource(it.labelRes) } ?: h.category} · ${stringResource(outcome)}", style = MaterialTheme.typography.titleSmall)
                        Text("${h.testCommand} · ${h.delayMs / 1000.0} s · ${h.testedCount}/${h.totalCount}", style = MaterialTheme.typography.bodySmall)
                        h.profileId?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
                        Text(df.format(Date(h.createdAt)), style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }
}

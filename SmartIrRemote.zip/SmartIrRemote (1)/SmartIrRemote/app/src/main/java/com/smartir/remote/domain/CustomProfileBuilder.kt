package com.smartir.remote.domain

import com.smartir.remote.data.model.CommandDef
import com.smartir.remote.data.model.IrProfile
import com.smartir.remote.data.repo.FlipperIrParser
import com.smartir.remote.ir.IrEncoder
import com.smartir.remote.ir.IrProtocol

enum class BuildError { ADDRESS, NO_BUTTONS, BAD_CODE, INVALID }

class BuildResult(val profile: IrProfile? = null, val error: BuildError? = null, val detail: String = "")

/** Builds a validated profile from what the user typed in the "custom remote" form. */
object CustomProfileBuilder {
    val PROTOCOLS = listOf(
        IrProtocol.NEC, IrProtocol.NEC_EXT, IrProtocol.SAMSUNG, IrProtocol.SONY_SIRC, IrProtocol.RC5,
        IrProtocol.RC6, IrProtocol.PANASONIC, IrProtocol.JVC, IrProtocol.SHARP,
    )

    val STANDARD_KEYS = listOf(
        Cmd.POWER, Cmd.VOLUME_UP, Cmd.VOLUME_DOWN, Cmd.MUTE, Cmd.MENU, Cmd.OK, Cmd.UP, Cmd.DOWN, Cmd.LEFT, Cmd.RIGHT,
        Cmd.BACK, Cmd.HOME, Cmd.SOURCE, Cmd.CHANNEL_UP, Cmd.CHANNEL_DOWN,
    )

    /** "0x1F" -> 31 (hex), "12" -> 12 (decimal). Returns null when it is not a number. */
    fun parseNumber(s: String): Int? {
        val t = s.trim()
        if (t.isEmpty()) return null
        return if (t.startsWith("0x", ignoreCase = true)) t.drop(2).toIntOrNull(16) else t.toIntOrNull()
    }

    fun build(
        id: String, name: String, brand: String, category: DeviceCategory, protocol: IrProtocol,
        addressText: String, subText: String, bits: Int, buttons: List<Pair<String, String>>,
    ): BuildResult {
        val address = parseNumber(addressText) ?: return BuildResult(error = BuildError.ADDRESS)
        val sub = if (subText.isBlank()) 0 else (parseNumber(subText) ?: return BuildResult(error = BuildError.ADDRESS))
        val cmds = LinkedHashMap<String, CommandDef>()
        for ((k, c) in buttons) {
            if (c.isBlank()) continue
            val key = FlipperIrParser.normName(k) ?: return BuildResult(error = BuildError.BAD_CODE, detail = k)
            val code = parseNumber(c) ?: return BuildResult(error = BuildError.BAD_CODE, detail = k)
            cmds[key] = CommandDef(code = code)
        }
        if (cmds.isEmpty()) return BuildResult(error = BuildError.NO_BUTTONS)
        val sony = protocol == IrProtocol.SONY_SIRC
        val cats = if (category == DeviceCategory.TV || category == DeviceCategory.SMART_TV) listOf("TV", "SMART_TV") else listOf(category.name)
        val p = IrProfile(
            id = id, brand = brand.trim().ifBlank { "Custom" }, model = name.trim(), categories = cats,
            protocol = protocol, address = address, subAddress = if (sony && bits == 20) sub else 0,
            bits = if (sony) bits else 0, commands = cmds, source = "user", license = "",
        )
        IrEncoder.validate(p)?.let { return BuildResult(error = BuildError.INVALID, detail = it) }
        return BuildResult(profile = p)
    }
}

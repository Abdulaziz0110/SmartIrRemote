package com.smartir.remote.scan

import com.smartir.remote.data.model.IrProfile
import com.smartir.remote.domain.Cmd
import com.smartir.remote.domain.DeviceCategory
import com.smartir.remote.ir.IrEncoder
import com.smartir.remote.ir.IrSignal

class ScanTarget(val profile: IrProfile, val signal: IrSignal)

object ScanPlanner {
    /**
     * Builds the finite, ordered list of known profiles to test. Only verified profiles in the
     * database are used (no random brute force) and dangerous commands are refused.
     */
    fun build(
        profiles: List<IrProfile>,
        category: DeviceCategory,
        command: String,
        includeRelated: Boolean,
        brand: String = "",
    ): List<ScanTarget> {
        require(!Cmd.isDangerous(command)) { "Command $command is not allowed in auto scan" }
        val cats = category.scanCategories(includeRelated)
        return profiles.asSequence()
            .filter { p -> p.categories.any { it in cats } }
            .filter { it.commands[command] != null }
            .filter { brand.isBlank() || it.brand.contains(brand.trim(), ignoreCase = true) }
            .filter { IrEncoder.validate(it) == null }
            .sortedWith(compareBy<IrProfile>({ if (category.name in it.categories) 0 else 1 }, { it.brand }, { it.id }))
            .mapNotNull { p ->
                runCatching { ScanTarget(p, IrEncoder.encode(p, p.commands.getValue(command))) }.getOrNull()
            }
            // Many databases share the exact same code for different models: test each signal once.
            // Alternatives stay available in the Confirm step ("Try alternative").
            .distinctBy { t -> Triple(t.signal.frequency, t.signal.pattern.size, t.signal.pattern.contentHashCode()) }
            .toList()
    }
}

package com.smartir.remote.scan

import com.smartir.remote.ir.IrException
import com.smartir.remote.ir.IrTransmitter
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

enum class ScanStatus { IDLE, RUNNING, PAUSED, FOUND, STOPPED, FINISHED, ERROR }

data class ScanState(
    val status: ScanStatus = ScanStatus.IDLE,
    val total: Int = 0,
    /** index of the last transmitted target, -1 when nothing was sent yet */
    val sentIndex: Int = -1,
    val maxSent: Int = -1,
    val elapsedMs: Long = 0,
    val delayMs: Long = 2000,
    /** most recently transmitted indices, oldest first */
    val recent: List<Int> = emptyList(),
    val error: String? = null,
) {
    val tested: Int get() = maxSent + 1
    val progress: Float get() = if (total == 0) 0f else tested.toFloat() / total
    val remainingMs: Long? get() =
        if (status == ScanStatus.RUNNING && total > 0) (total - (sentIndex + 1)).coerceAtLeast(0) * delayMs else null
}

/**
 * Sequential scan engine. Only transmits after an explicit user action (start, resume, next,
 * previous, retest). Transmissions are serialised by a mutex and the next code never starts
 * before the previous pattern has finished, so signals cannot overlap.
 */
class ScanEngine(
    private val transmitter: IrTransmitter,
    private val scope: CoroutineScope,
    private val io: CoroutineDispatcher = Dispatchers.Default,
) {
    private val _state = MutableStateFlow(ScanState())
    val state: StateFlow<ScanState> = _state.asStateFlow()

    private var targets: List<ScanTarget> = emptyList()
    private var loopJob: Job? = null
    private var tickJob: Job? = null
    private val sendLock = Mutex()

    fun load(newTargets: List<ScanTarget>, delayMs: Long, startIndex: Int = -1) {
        cancelJobs()
        targets = newTargets
        val s = startIndex.coerceIn(-1, newTargets.size - 1)
        _state.value = ScanState(
            status = if (s >= 0) ScanStatus.PAUSED else ScanStatus.IDLE,
            total = newTargets.size, sentIndex = s, maxSent = s,
            delayMs = delayMs.coerceIn(MIN_DELAY_MS, MAX_DELAY_MS),
        )
    }

    fun setDelay(ms: Long) = _state.update { it.copy(delayMs = ms.coerceIn(MIN_DELAY_MS, MAX_DELAY_MS)) }

    fun start() {
        if (_state.value.status == ScanStatus.RUNNING) return
        if (targets.isEmpty()) {
            _state.update { it.copy(status = ScanStatus.ERROR, error = "No profiles") }
            return
        }
        _state.update {
            it.copy(status = ScanStatus.RUNNING, sentIndex = -1, maxSent = -1, elapsedMs = 0, recent = emptyList(), error = null)
        }
        launchLoop()
    }

    fun resume() {
        val s = _state.value.status
        if (s == ScanStatus.PAUSED || s == ScanStatus.FOUND) {
            _state.update { it.copy(status = ScanStatus.RUNNING, error = null) }
            launchLoop()
        }
    }

    fun pause() {
        if (_state.value.status == ScanStatus.RUNNING) {
            cancelJobs()
            _state.update { it.copy(status = ScanStatus.PAUSED) }
        }
    }

    fun stop() {
        cancelJobs()
        _state.update { it.copy(status = ScanStatus.STOPPED, sentIndex = -1, maxSent = -1, recent = emptyList()) }
    }

    /** FOUND IT: stops transmission immediately; recent codes stay available for retesting. */
    fun found() {
        val s = _state.value.status
        if (s == ScanStatus.RUNNING || s == ScanStatus.PAUSED) {
            cancelJobs()
            _state.update { it.copy(status = ScanStatus.FOUND) }
        }
    }

    fun next() = manual(_state.value.sentIndex + 1)
    fun previous() = manual(_state.value.sentIndex - 1)
    fun retest() = manual(_state.value.sentIndex)
    fun testIndex(i: Int) = manual(i)

    private fun manual(i: Int) {
        if (_state.value.status == ScanStatus.RUNNING || i !in targets.indices) return
        scope.launch { sendAt(i) }
    }

    private fun cancelJobs() {
        loopJob?.cancel(); tickJob?.cancel()
        loopJob = null; tickJob = null
    }

    private fun launchLoop() {
        cancelJobs()
        tickJob = scope.launch {
            while (true) {
                delay(TICK_MS)
                _state.update { if (it.status == ScanStatus.RUNNING) it.copy(elapsedMs = it.elapsedMs + TICK_MS) else it }
            }
        }
        loopJob = scope.launch {
            while (true) {
                val next = _state.value.sentIndex + 1
                if (next >= targets.size) {
                    tickJob?.cancel()
                    _state.update { it.copy(status = ScanStatus.FINISHED) }
                    break
                }
                if (!sendAt(next)) { tickJob?.cancel(); break }
                val dur = targets[next].signal.durationMs
                delay((_state.value.delayMs - dur).coerceAtLeast(0))
            }
        }
    }

    private suspend fun sendAt(i: Int): Boolean {
        val t = targets[i]
        return sendLock.withLock {
            // Not cancellable: once the signal is out it must be recorded, otherwise FOUND IT
            // could miss the code that was just transmitted.
            val ok = withContext(NonCancellable + io) {
                try {
                    transmitter.transmit(t.signal)
                    _state.update { s ->
                        s.copy(
                            sentIndex = i, maxSent = maxOf(s.maxSent, i),
                            recent = (s.recent.filter { it != i } + i).takeLast(RECENT_SIZE),
                        )
                    }
                    true
                } catch (e: IrException) {
                    _state.update { it.copy(status = ScanStatus.ERROR, error = e.message) }
                    false
                }
            }
            if (ok) delay(t.signal.durationMs) // never overlap with the next transmission
            ok
        }
    }

    companion object {
        const val MIN_DELAY_MS = 300L
        const val MAX_DELAY_MS = 10_000L
        const val RECENT_SIZE = 12
        const val TICK_MS = 200L
    }
}

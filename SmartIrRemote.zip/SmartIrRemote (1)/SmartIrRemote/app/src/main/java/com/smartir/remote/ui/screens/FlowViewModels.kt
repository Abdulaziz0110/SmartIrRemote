package com.smartir.remote.ui.screens

import android.content.Context
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.smartir.remote.R
import com.smartir.remote.data.db.HistoryDao
import com.smartir.remote.data.db.MacroDao
import com.smartir.remote.data.db.RemoteEntity
import com.smartir.remote.data.db.ScanHistoryEntity
import com.smartir.remote.data.model.CommandDef
import com.smartir.remote.data.model.IrProfile
import com.smartir.remote.data.repo.ProfileRepository
import com.smartir.remote.data.repo.RemoteRepository
import com.smartir.remote.data.repo.ScanSession
import com.smartir.remote.data.repo.SettingsStore
import com.smartir.remote.domain.CompatStatus
import com.smartir.remote.domain.DeviceCategory
import com.smartir.remote.ir.IrEncoder
import com.smartir.remote.ir.IrTransmitter
import com.smartir.remote.scan.ScanEngine
import com.smartir.remote.scan.ScanPlanner
import com.smartir.remote.scan.ScanState
import com.smartir.remote.scan.ScanStatus
import com.smartir.remote.scan.ScanTarget
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.withContext
import javax.inject.Inject

// ------------------------------------------------------------------ My remotes list
@HiltViewModel
class RemotesViewModel @Inject constructor(
    private val repo: RemoteRepository,
    private val macroDao: MacroDao,
    @ApplicationContext private val ctx: Context,
) : ViewModel() {
    val remotes: StateFlow<List<RemoteEntity>> =
        repo.observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun toggleFavorite(r: RemoteEntity) { viewModelScope.launch { repo.setFavorite(r.id, !r.favorite) } }

    fun rename(r: RemoteEntity, name: String) {
        viewModelScope.launch { repo.update(r.copy(name = name.trim().ifBlank { r.name })) }
    }

    fun duplicate(r: RemoteEntity) {
        viewModelScope.launch { repo.duplicate(r.id, ctx.getString(R.string.copy_suffix)) }
    }

    fun delete(r: RemoteEntity) {
        viewModelScope.launch { macroDao.deleteForRemote(r.id); repo.delete(r.id) }
    }
}

// ------------------------------------------------------------------ Auto scan
data class ScanSetup(
    val loading: Boolean = true,
    /** number of distinct signals that will be tested */
    val count: Int = 0,
    val command: String = "",
    /** test command -> number of profiles that contain it */
    val commandCounts: Map<String, Int> = emptyMap(),
    val delayMs: Long = 2000,
    val includeRelated: Boolean = true,
    /** optional brand filter (substring, case-insensitive) */
    val brand: String = "",
    /** interrupted session that can be continued */
    val recover: ScanSession? = null,
)

@HiltViewModel
class ScanViewModel @Inject constructor(
    saved: SavedStateHandle,
    transmitter: IrTransmitter,
    private val profiles: ProfileRepository,
    private val settings: SettingsStore,
    private val history: HistoryDao,
) : ViewModel() {
    val category: DeviceCategory = DeviceCategory.valueOf(checkNotNull(saved.get<String>("category")))
    val hasIr: Boolean = transmitter.isAvailable
    val engine = ScanEngine(transmitter, viewModelScope)

    private val _setup = MutableStateFlow(
        ScanSetup(command = category.testCommands.first(), delayMs = category.recommendedDelayMs),
    )
    val setup: StateFlow<ScanSetup> = _setup.asStateFlow()

    private var pool: List<IrProfile> = emptyList()
    @Volatile private var targets: List<ScanTarget> = emptyList()
    private var rebuildJob: Job? = null

    init {
        viewModelScope.launch {
            val rec = settings.session.first()?.takeIf { it.category == category.name }
            pool = withContext(Dispatchers.Default) { profiles.getForCategories(category.scanCategories(true)) }
            val counts = withContext(Dispatchers.Default) { countCommands(true) }
            val first = category.testCommands.firstOrNull { (counts[it] ?: 0) > 0 } ?: category.testCommands.first()
            _setup.update { it.copy(command = first, recover = rec) }
            rebuild()
        }
        viewModelScope.launch { trackEngine() }
    }

    private fun countCommands(related: Boolean): Map<String, Int> {
        val cats = category.scanCategories(related)
        val rel = pool.filter { p -> p.categories.any { it in cats } }
        return category.testCommands.associateWith { c -> rel.count { it.commands[c] != null } }
    }

    private fun rebuild(startIndex: Int = -1, debounceMs: Long = 0L) {
        rebuildJob?.cancel()
        rebuildJob = viewModelScope.launch {
            if (debounceMs > 0) delay(debounceMs)
            _setup.update { it.copy(loading = true) }
            val s = _setup.value
            val (counts, list) = withContext(Dispatchers.Default) {
                countCommands(s.includeRelated) to ScanPlanner.build(pool, category, s.command, s.includeRelated, s.brand)
            }
            targets = list
            engine.load(list, s.delayMs, startIndex)
            _setup.update { it.copy(loading = false, count = list.size, commandCounts = counts) }
        }
    }

    fun setCommand(c: String) {
        if (c == _setup.value.command) return
        _setup.update { it.copy(command = c) }
        rebuild()
    }

    fun setRelated(v: Boolean) {
        if (v == _setup.value.includeRelated) return
        _setup.update { it.copy(includeRelated = v) }
        rebuild()
    }

    fun setBrand(b: String) {
        if (b == _setup.value.brand || engine.state.value.status == ScanStatus.RUNNING) return
        _setup.update { it.copy(brand = b) }
        rebuild(debounceMs = 350)
    }

    fun setDelay(ms: Long) {
        val d = ms.coerceIn(maxOf(ScanEngine.MIN_DELAY_MS, category.minDelayMs), ScanEngine.MAX_DELAY_MS)
        _setup.update { it.copy(delayMs = d) }
        engine.setDelay(d)
    }

    fun start() {
        viewModelScope.launch { settings.clearSession() }
        _setup.update { it.copy(recover = null) }
        engine.start()
    }

    fun resumeSession() {
        val r = _setup.value.recover ?: return
        _setup.update {
            it.copy(
                command = r.command,
                delayMs = r.delayMs.coerceAtLeast(category.minDelayMs),
                includeRelated = r.includeRelated,
                recover = null,
            )
        }
        rebuild(startIndex = r.index)
    }

    fun targetAt(index: Int): ScanTarget? = targets.getOrNull(index)

    /** Persists the interrupted session and writes scan history entries. */
    private suspend fun trackEngine() {
        var lastActive: ScanState? = null
        var prev = ScanStatus.IDLE
        engine.state.collect { st ->
            when (st.status) {
                ScanStatus.RUNNING, ScanStatus.PAUSED, ScanStatus.FOUND -> {
                    lastActive = st
                    // a brand-filtered list differs from the full one, so it cannot be resumed by index
                    if (st.sentIndex >= 0 && _setup.value.brand.isBlank()) {
                        val s = _setup.value
                        settings.saveSession(ScanSession(category.name, s.command, st.delayMs, st.sentIndex, s.includeRelated))
                    }
                }
                ScanStatus.FINISHED, ScanStatus.STOPPED -> settings.clearSession()
                else -> Unit
            }
            if (st.status != prev) {
                val outcome = when (st.status) {
                    ScanStatus.FOUND -> "FOUND"
                    ScanStatus.FINISHED -> "FINISHED"
                    ScanStatus.STOPPED -> "STOPPED"
                    else -> null
                }
                if (outcome != null) {
                    val base = if (st.status == ScanStatus.STOPPED) lastActive ?: st else st
                    if (base.tested > 0) {
                        history.insert(
                            ScanHistoryEntity(
                                category = category.name, testCommand = _setup.value.command,
                                delayMs = base.delayMs, testedCount = base.tested,
                                totalCount = base.total, outcome = outcome,
                            ),
                        )
                    }
                }
                prev = st.status
            }
        }
    }
}

// ------------------------------------------------------------------ Manual search
data class ManualState(
    val loading: Boolean = true,
    val brands: List<String> = emptyList(),
    val selected: String? = null,
    val profiles: List<IrProfile> = emptyList(),
)

@HiltViewModel
class ManualViewModel @Inject constructor(
    saved: SavedStateHandle,
    private val repo: ProfileRepository,
) : ViewModel() {
    val category: DeviceCategory = DeviceCategory.valueOf(checkNotNull(saved.get<String>("category")))
    private val _state = MutableStateFlow(ManualState())
    val state: StateFlow<ManualState> = _state.asStateFlow()
    private var all: List<IrProfile> = emptyList()

    init {
        viewModelScope.launch {
            all = repo.getForCategories(category.scanCategories(true))
            val brands = withContext(Dispatchers.Default) {
                all.map { it.brand }.distinct().sortedBy { it.lowercase() }
            }
            _state.update { it.copy(loading = false, brands = brands) }
        }
    }

    fun selectBrand(brand: String?) {
        _state.update { s ->
            s.copy(
                selected = brand,
                profiles = if (brand == null) emptyList()
                else all.filter { it.brand == brand }.sortedBy { it.model.ifBlank { it.id }.lowercase() },
            )
        }
    }
}

// ------------------------------------------------------------------ Confirm compatibility
data class ConfirmRow(
    val cmd: String,
    val available: Boolean,
    /** null = not answered yet */
    val works: Boolean? = null,
    /** alternative profile currently being tried for this button */
    val alt: IrProfile? = null,
)

data class ConfirmState(
    val profile: IrProfile? = null,
    val rows: List<ConfirmRow> = emptyList(),
    val status: CompatStatus = CompatStatus.UNVERIFIED,
    val error: String? = null,
    /** bumped when the list of alternative profiles becomes available */
    val altVersion: Int = 0,
)

@HiltViewModel
class ConfirmViewModel @Inject constructor(
    saved: SavedStateHandle,
    private val remotes: RemoteRepository,
    private val repo: ProfileRepository,
    private val transmitter: IrTransmitter,
) : ViewModel() {
    private val category: DeviceCategory = DeviceCategory.valueOf(checkNotNull(saved.get<String>("category")))
    private val profileId: String = checkNotNull(saved.get<String>("profileId"))

    private val _state = MutableStateFlow(ConfirmState())
    val state: StateFlow<ConfirmState> = _state.asStateFlow()
    val hasIr: Boolean = transmitter.isAvailable

    private val sendLock = Mutex()
    /** command -> alternative profile accepted by the user */
    private val overrides = LinkedHashMap<String, IrProfile>()
    /** command -> profile that was transmitted last (main or alternative) */
    private val lastSent = HashMap<String, IrProfile>()
    private val altIndex = HashMap<String, Int>()
    @Volatile private var alts: Map<String, List<IrProfile>> = emptyMap()

    init { viewModelScope.launch { load() } }

    private suspend fun load() {
        val p = repo.getById(profileId)
        if (p == null) {
            _state.update { it.copy(error = "Profile not found") }
            return
        }
        val rows = category.checkCommands.map { ConfirmRow(it, it in p.commands) }
        _state.update { it.copy(profile = p, rows = rows, status = statusOf(rows)) }
        val pool = repo.getForCategories(category.scanCategories(true))
        alts = withContext(Dispatchers.Default) { buildAlternatives(p, pool) }
        _state.update { it.copy(altVersion = it.altVersion + 1) }
    }

    private fun sigKey(p: IrProfile, d: CommandDef): Triple<Int, Int, Int>? = runCatching {
        val s = IrEncoder.encode(p, d)
        Triple(s.frequency, s.pattern.size, s.pattern.contentHashCode())
    }.getOrNull()

    private fun buildAlternatives(main: IrProfile, pool: List<IrProfile>): Map<String, List<IrProfile>> =
        category.checkCommands.associateWith { cmd ->
            val seen = HashSet<Triple<Int, Int, Int>>()
            main.commands[cmd]?.let { d -> sigKey(main, d)?.let { seen.add(it) } }
            pool.asSequence()
                .filter { it.id != main.id && it.commands[cmd] != null }
                .sortedWith(compareBy<IrProfile>({ if (it.brand.equals(main.brand, true)) 0 else 1 }, { it.brand }, { it.id }))
                .filter { p -> val k = sigKey(p, p.commands.getValue(cmd)); k != null && seen.add(k) }
                .take(100)
                .toList()
        }

    private fun statusOf(rows: List<ConfirmRow>): CompatStatus =
        CompatStatus.compute(rows.count { it.available }, rows.count { it.works == true })

    private fun updateRow(cmd: String, change: (ConfirmRow) -> ConfirmRow) {
        _state.update { s ->
            val rows = s.rows.map { if (it.cmd == cmd) change(it) else it }
            s.copy(rows = rows, status = statusOf(rows))
        }
    }

    private fun transmit(p: IrProfile, cmd: String) {
        val def = p.commands[cmd] ?: return
        lastSent[cmd] = p
        viewModelScope.launch {
            if (!sendLock.tryLock()) return@launch
            try {
                val signal = IrEncoder.encode(p, def)
                withContext(Dispatchers.Default) { transmitter.transmit(signal) }
                _state.update { it.copy(error = null) }
                delay(signal.durationMs)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update { it.copy(error = e.message ?: "IR error") }
            } finally {
                sendLock.unlock()
            }
        }
    }

    fun send(cmd: String) {
        val main = _state.value.profile ?: return
        transmit(overrides[cmd] ?: main, cmd)
    }

    fun mark(cmd: String, ok: Boolean) {
        val main = _state.value.profile ?: return
        val last = lastSent[cmd]
        // The user confirmed an alternative that was just tried: keep it for this button.
        if (ok && last != null && last.id != main.id) overrides[cmd] = last
        updateRow(cmd) { it.copy(works = ok) }
    }

    fun hasAlternatives(cmd: String): Boolean = alts[cmd].orEmpty().isNotEmpty()

    fun tryAlternative(cmd: String) {
        val list = alts[cmd].orEmpty()
        if (list.isEmpty()) return
        val i = altIndex[cmd] ?: 0
        val alt = list[i % list.size]
        altIndex[cmd] = i + 1
        updateRow(cmd) { it.copy(alt = alt) }
        transmit(alt, cmd)
    }

    fun useAlternative(cmd: String) {
        val alt = _state.value.rows.firstOrNull { it.cmd == cmd }?.alt ?: return
        overrides[cmd] = alt
        updateRow(cmd) { it.copy(works = true) }
    }

    fun save(name: String, favorite: Boolean, onSaved: (Long) -> Unit) {
        val s = _state.value
        val p = s.profile ?: return
        viewModelScope.launch {
            val entity = RemoteEntity(
                name = name.trim().ifBlank { p.displayName },
                category = category.name,
                brand = p.brand,
                model = p.model,
                protocol = p.protocol.name,
                profileId = p.id,
                status = s.status.name,
                verified = s.rows.filter { it.works == true }.joinToString(",") { it.cmd },
                overrides = RemoteEntity.encodeOverrides(overrides.mapValues { it.value.id }),
                favorite = favorite,
            )
            onSaved(remotes.insert(entity))
        }
    }
}

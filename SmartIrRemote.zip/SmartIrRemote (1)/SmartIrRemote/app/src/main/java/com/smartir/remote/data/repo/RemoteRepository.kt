package com.smartir.remote.data.repo

import com.smartir.remote.data.db.RemoteDao
import com.smartir.remote.data.db.RemoteEntity
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class RemoteRepository @Inject constructor(private val dao: RemoteDao) {
    fun observeAll(): Flow<List<RemoteEntity>> = dao.observeAll()
    fun observeRecent(): Flow<List<RemoteEntity>> = dao.observeRecent()
    fun observe(id: Long): Flow<RemoteEntity?> = dao.observe(id)
    suspend fun get(id: Long) = dao.get(id)
    suspend fun getAll() = dao.getAll()
    suspend fun insert(r: RemoteEntity): Long = dao.insert(r)
    suspend fun update(r: RemoteEntity) = dao.update(r)
    suspend fun delete(id: Long) = dao.delete(id)
    suspend fun touch(id: Long) = dao.touch(id, System.currentTimeMillis())

    suspend fun duplicate(id: Long, suffix: String): Long? {
        val r = dao.get(id) ?: return null
        return dao.insert(r.copy(id = 0, name = "${r.name} ($suffix)", lastUsed = 0, createdAt = System.currentTimeMillis()))
    }

    suspend fun setFavorite(id: Long, fav: Boolean) {
        dao.get(id)?.let { dao.update(it.copy(favorite = fav)) }
    }
}

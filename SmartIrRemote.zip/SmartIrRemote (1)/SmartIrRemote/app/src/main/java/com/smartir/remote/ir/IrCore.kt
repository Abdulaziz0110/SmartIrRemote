package com.smartir.remote.ir

import kotlinx.serialization.Serializable

@Serializable
enum class IrProtocol { NEC, NEC_EXT, NEC42, NEC42_EXT, SAMSUNG, SONY_SIRC, RC5, RC6, PANASONIC, JVC, SHARP, RAW }

class IrSignal(val frequency: Int, val pattern: IntArray) {
    val durationUs: Long get() = pattern.sumOf { it.toLong() }
    val durationMs: Long get() = durationUs / 1000
}

class IrException(message: String, cause: Throwable? = null) : Exception(message, cause)

interface IrTransmitter {
    val isAvailable: Boolean
    /** carrier frequency ranges (Hz) the phone's IR LED supports; empty when unknown */
    val carrierRanges: List<IntRange> get() = emptyList()
    /** Blocking. Throws [IrException] on failure. */
    fun transmit(signal: IrSignal)
}

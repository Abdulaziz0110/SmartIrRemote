package com.smartir.remote

import android.content.Intent
import android.os.Bundle
import android.view.KeyEvent
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.smartir.remote.data.repo.AppSettings
import com.smartir.remote.data.repo.SettingsStore
import com.smartir.remote.ui.AppNav
import com.smartir.remote.ui.HardwareKeys
import com.smartir.remote.ui.Shortcuts
import com.smartir.remote.ui.theme.SmartIrTheme
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {
    @Inject lateinit var settings: SettingsStore
    private val openRemote = mutableStateOf(-1L)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        openRemote.value = intent?.getLongExtra(Shortcuts.EXTRA_REMOTE, -1L) ?: -1L
        setContent {
            val s by settings.settings.collectAsStateWithLifecycle(AppSettings())
            val dark = when (s.theme) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
            SmartIrTheme(dark) { AppNav(openRemote.value) { openRemote.value = -1L } }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        openRemote.value = intent.getLongExtra(Shortcuts.EXTRA_REMOTE, -1L)
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val h = HardwareKeys.handler
        if (h != null && (event.keyCode == KeyEvent.KEYCODE_VOLUME_UP || event.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN)) {
            // ACTION_DOWN also fires for auto-repeat while the key is held
            if (event.action == KeyEvent.ACTION_DOWN) h(event.keyCode)
            return true
        }
        return super.dispatchKeyEvent(event)
    }
}

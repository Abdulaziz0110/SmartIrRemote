package com.smartir.remote.domain

object Cmd {
    const val POWER = "POWER"
    const val VOLUME_UP = "VOLUME_UP"
    const val VOLUME_DOWN = "VOLUME_DOWN"
    const val MUTE = "MUTE"
    const val CHANNEL_UP = "CHANNEL_UP"
    const val CHANNEL_DOWN = "CHANNEL_DOWN"
    const val HOME = "HOME"
    const val MENU = "MENU"
    const val BACK = "BACK"
    const val OK = "OK"
    const val UP = "UP"
    const val DOWN = "DOWN"
    const val LEFT = "LEFT"
    const val RIGHT = "RIGHT"
    const val SOURCE = "SOURCE"
    const val SETTINGS = "SETTINGS"
    const val TEMP_UP = "TEMP_UP"
    const val TEMP_DOWN = "TEMP_DOWN"
    const val MODE = "MODE"
    const val FAN_SPEED = "FAN_SPEED"
    const val SWING = "SWING"
    const val SPEED_UP = "SPEED_UP"
    const val SPEED_DOWN = "SPEED_DOWN"
    const val BRIGHTNESS_UP = "BRIGHTNESS_UP"
    const val BRIGHTNESS_DOWN = "BRIGHTNESS_DOWN"

    fun num(n: Int) = "NUM_$n"

    /** Never sent by Auto Scan: hard or annoying to undo. */
    val DANGEROUS = setOf(
        "POWER", "POWER_ON", "POWER_OFF", "POWER_TOGGLE", "FACTORY_RESET",
        "SERVICE_MENU", "RESET", "SLEEP", "FORMAT", "INSTALL_MENU",
    )

    fun isDangerous(key: String) = key.uppercase() in DANGEROUS

    private val labels = mapOf(
        VOLUME_UP to "Vol +", VOLUME_DOWN to "Vol –", MUTE to "Mute",
        CHANNEL_UP to "Ch +", CHANNEL_DOWN to "Ch –", HOME to "Home", MENU to "Menu",
        BACK to "Back", OK to "OK", UP to "▲", DOWN to "▼", LEFT to "◀", RIGHT to "▶",
        SOURCE to "Source", SETTINGS to "Settings", TEMP_UP to "Temp +", TEMP_DOWN to "Temp –",
        MODE to "Mode", FAN_SPEED to "Fan", SWING to "Swing", SPEED_UP to "Speed +",
        SPEED_DOWN to "Speed –", BRIGHTNESS_UP to "Bright +", BRIGHTNESS_DOWN to "Bright –",
        "PLAY_PAUSE" to "Play/Pause", "STOP" to "Stop", "REWIND" to "Rew", "FORWARD" to "Fwd",
        "PREV_TRACK" to "Prev", "NEXT_TRACK" to "Next",
    )

    fun label(key: String): String {
        labels[key]?.let { return it }
        if (key.startsWith("NUM_")) return key.removePrefix("NUM_")
        return key.lowercase().replace('_', ' ').replaceFirstChar { it.uppercase() }
    }

    val CHECK_DEFAULT = listOf(VOLUME_UP, VOLUME_DOWN, MUTE, MENU, OK, BACK, UP, DOWN, LEFT, RIGHT)
}

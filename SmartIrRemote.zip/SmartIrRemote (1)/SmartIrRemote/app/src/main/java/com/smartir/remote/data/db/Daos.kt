package com.smartir.remote.data.db

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ProfileDao {
    @Query("SELECT id, brand, model, categories, protocol FROM profiles WHERE brand LIKE '%' || :q || '%' OR model LIKE '%' || :q || '%' ORDER BY brand COLLATE NOCASE, model LIMIT 300")
    suspend fun search(q: String): List<ProfileHit>
    @Query("SELECT categories FROM profiles") fun observeCategories(): Flow<List<String>>
    @Query("SELECT COUNT(*) FROM profiles") fun observeCount(): Flow<Int>
    @Query("SELECT COUNT(DISTINCT brand) FROM profiles") fun observeBrandCount(): Flow<Int>
    @Query("SELECT * FROM profiles") suspend fun getAll(): List<ProfileEntity>
    @Query("SELECT * FROM profiles WHERE id = :id") suspend fun getById(id: String): ProfileEntity?
    @Query("SELECT * FROM profiles WHERE categories LIKE '%' || :cat || '%'") suspend fun getByCategoryLike(cat: String): List<ProfileEntity>
    @Query("SELECT * FROM profiles ORDER BY id LIMIT :limit OFFSET :offset") suspend fun page(limit: Int, offset: Int): List<ProfileEntity>
    @Query("SELECT * FROM profiles WHERE isUser = 1") suspend fun getUser(): List<ProfileEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAll(items: List<ProfileEntity>)
}

@Dao
interface RemoteDao {
    @Query("SELECT * FROM remotes ORDER BY favorite DESC, name COLLATE NOCASE")
    fun observeAll(): Flow<List<RemoteEntity>>

    @Query("SELECT * FROM remotes WHERE lastUsed > 0 ORDER BY lastUsed DESC LIMIT 10")
    fun observeRecent(): Flow<List<RemoteEntity>>

    @Query("SELECT * FROM remotes WHERE id = :id") fun observe(id: Long): Flow<RemoteEntity?>
    @Query("SELECT * FROM remotes WHERE id = :id") suspend fun get(id: Long): RemoteEntity?
    @Query("SELECT * FROM remotes") suspend fun getAll(): List<RemoteEntity>
    @Insert suspend fun insert(r: RemoteEntity): Long
    @Update suspend fun update(r: RemoteEntity)
    @Query("DELETE FROM remotes WHERE id = :id") suspend fun delete(id: Long)
    @Query("UPDATE remotes SET lastUsed = :t WHERE id = :id") suspend fun touch(id: Long, t: Long)
}

@Dao
interface HistoryDao {
    @Query("SELECT * FROM scan_history ORDER BY createdAt DESC LIMIT 100")
    fun observe(): Flow<List<ScanHistoryEntity>>
    @Insert suspend fun insert(h: ScanHistoryEntity)
    @Query("DELETE FROM scan_history") suspend fun clear()
}

@Dao
interface MacroDao {
    @Query("SELECT * FROM macros WHERE remoteId = :rid ORDER BY name COLLATE NOCASE")
    fun observe(rid: Long): Flow<List<MacroEntity>>
    @Insert suspend fun insert(m: MacroEntity): Long
    @Query("DELETE FROM macros WHERE id = :id") suspend fun delete(id: Long)
    @Query("DELETE FROM macros WHERE remoteId = :rid") suspend fun deleteForRemote(rid: Long)
}

val MIGRATION_1_2 = object : androidx.room.migration.Migration(1, 2) {
    override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS `macros` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `remoteId` INTEGER NOT NULL, `name` TEXT NOT NULL, `steps` TEXT NOT NULL, `delayMs` INTEGER NOT NULL)")
    }
}

@Database(
    entities = [ProfileEntity::class, RemoteEntity::class, ScanHistoryEntity::class, MacroEntity::class],
    version = 2,
    exportSchema = false,
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun profiles(): ProfileDao
    abstract fun remotes(): RemoteDao
    abstract fun history(): HistoryDao
    abstract fun macros(): MacroDao
}

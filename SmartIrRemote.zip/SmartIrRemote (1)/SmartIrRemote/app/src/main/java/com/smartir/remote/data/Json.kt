package com.smartir.remote.data

import kotlinx.serialization.json.Json

/** Compact, single-line output (one profile per line in exports). */
val CompactJson = Json {
    ignoreUnknownKeys = true
    encodeDefaults = true
}

val AppJson = Json {
    ignoreUnknownKeys = true
    encodeDefaults = true
    prettyPrint = true
}

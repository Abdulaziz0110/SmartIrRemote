package com.smartir.remote.data.repo

import com.smartir.remote.data.model.IrProfile
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Downloads public CC0 IR databases (Flipper-IRDB and probonopd/irdb). Runs in an app-wide scope,
 * so leaving the Settings screen does not cancel it, and retries dropped connections up to 3 times
 * (inserts are idempotent). Archives are streamed and parsed file by file to keep memory small.
 */
@Singleton
class IrdbDownloader @Inject constructor(private val profiles: ProfileRepository) {

    class Progress(val source: String, val count: Int)

    private class Source(val name: String, val urls: List<String>)
    private class Attempt(val result: ImportResult, val stats: Map<String, Int>)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val _progress = MutableStateFlow<Progress?>(null)
    val progress: StateFlow<Progress?> = _progress.asStateFlow()
    private val _results = MutableSharedFlow<ImportResult>(extraBufferCapacity = 4)
    val results: SharedFlow<ImportResult> = _results.asSharedFlow()

    private val sources = listOf(
        Source("Flipper-IRDB", listOf(
            "https://codeload.github.com/UberGuidoZ/Flipper-IRDB/zip/refs/heads/main",
            "https://codeload.github.com/UberGuidoZ/Flipper-IRDB/zip/refs/heads/master",
        )),
        Source("irdb", listOf(
            "https://codeload.github.com/probonopd/irdb/zip/refs/heads/master",
            "https://codeload.github.com/probonopd/irdb/zip/refs/heads/main",
        )),
    )

    fun start() {
        if (!_progress.compareAndSet(null, Progress("", 0))) return
        scope.launch {
            val r = try { run() } catch (e: Exception) { ImportResult(0, 0, e.message ?: "error") }
            _progress.value = null
            _results.emit(r)
        }
    }

    private suspend fun run(): ImportResult {
        var total = 0
        var skipped = 0
        val errors = ArrayList<String>()
        val stats = HashMap<String, Int>()
        for (src in sources) {
            var done = false
            var lastErr = ""
            urls@ for (url in src.urls) {
                var best: Attempt? = null
                for (attempt in 1..3) {
                    val st = HashMap<String, Int>()
                    val base = total
                    val r = downloadOne(url, st) { n -> _progress.value = Progress(src.name, base + n) }
                    if (best == null || r.imported > best.result.imported) best = Attempt(r, st)
                    if (r.error == null) { best = Attempt(r, st); break }
                    lastErr = r.error
                    if (r.error.startsWith("HTTP 4")) break // wrong branch name: no point retrying
                    if (attempt < 3) delay(3000)
                }
                val b = best!!
                total += b.result.imported
                skipped += b.result.skipped
                b.stats.forEach { (k, v) -> stats.merge(k, v) { x, y -> x + y } }
                if (b.result.error == null) { done = true; break@urls }
                if (b.result.imported > 0) break@urls // partial data kept; do not try another URL
            }
            if (!done) errors += "${src.name}: $lastErr"
        }
        val note = stats.entries.sortedByDescending { it.value }.take(6)
            .joinToString(", ") { "${it.key}×${it.value}" }.ifBlank { null }
        return ImportResult(total, skipped, errors.takeIf { it.isNotEmpty() }?.joinToString("; "), note)
    }

    private suspend fun downloadOne(url: String, stats: MutableMap<String, Int>, onCount: (Int) -> Unit): ImportResult {
        var total = 0
        var skipped = 0
        val buffer = ArrayList<IrProfile>()

        suspend fun flush() {
            if (buffer.isEmpty()) return
            val r = profiles.insertProfiles(buffer.toList(), isUser = false)
            total += r.imported; skipped += r.skipped
            buffer.clear()
            onCount(total)
        }

        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 20_000; readTimeout = 120_000; instanceFollowRedirects = true
            setRequestProperty("User-Agent", "SmartIrRemote")
        }
        return try {
            if (conn.responseCode != 200) return ImportResult(0, 0, "HTTP ${conn.responseCode}")
            ZipInputStream(conn.inputStream.buffered()).use { zis ->
                var e = zis.nextEntry
                while (e != null) {
                    if (!e.isDirectory) {
                        val lower = e.name.lowercase()
                        val parts = e.name.split('/').drop(1) // drop archive root folder
                        if (lower.endsWith(".ir")) {
                            buffer += FlipperIrParser.parse(String(zis.readBytes(), Charsets.UTF_8), parts, skipped = stats)
                        } else if (lower.endsWith(".csv") && parts.firstOrNull() == "codes") {
                            buffer += IrdbCsvParser.parse(String(zis.readBytes(), Charsets.UTF_8), parts)
                        }
                        if (buffer.size >= 300) flush()
                    }
                    e = zis.nextEntry
                }
            }
            flush()
            ImportResult(total, skipped)
        } catch (ex: Exception) {
            ImportResult(total, skipped, ex.message ?: "network error")
        } finally {
            conn.disconnect()
        }
    }
}

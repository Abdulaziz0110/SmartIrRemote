package com.smartir.remote.ir

import com.smartir.remote.data.model.CommandDef
import com.smartir.remote.data.model.IrProfile

object IrEncoder {

    fun encode(profile: IrProfile, def: CommandDef): IrSignal {
        if (profile.protocol == IrProtocol.RAW) {
            val raw = def.raw ?: throw IrException("RAW command without pattern")
            return IrSignal(def.frequency ?: 38000, raw.toIntArray())
        }
        val code = def.code ?: throw IrException("Command without code")
        val a = profile.address
        return when (profile.protocol) {
            IrProtocol.NEC -> Encoders.nec(a, code, false)
            IrProtocol.NEC_EXT -> Encoders.nec(a, code, true)
            IrProtocol.NEC42 -> Encoders.nec42(a, code, false)
            IrProtocol.NEC42_EXT -> Encoders.nec42(a, code, true)
            IrProtocol.SAMSUNG -> Encoders.samsung(a, code)
            IrProtocol.SONY_SIRC -> Encoders.sony(a, profile.subAddress, code, profile.bits)
            IrProtocol.RC5 -> Encoders.rc5(a, code)
            IrProtocol.RC6 -> Encoders.rc6(a, code)
            IrProtocol.PANASONIC -> Encoders.panasonic(a, code)
            IrProtocol.JVC -> Encoders.jvc(a, code)
            IrProtocol.SHARP -> Encoders.sharp(a, code)
            IrProtocol.RAW -> error("unreachable")
        }
    }

    /** Returns null when the profile is valid, otherwise a human readable reason. */
    fun validate(p: IrProfile): String? {
        if (p.id.isBlank()) return "empty id"
        if (p.brand.isBlank()) return "${p.id}: empty brand"
        if (p.categories.isEmpty()) return "${p.id}: no categories"
        if (p.commands.isEmpty()) return "${p.id}: no commands"
        val (maxAddr, maxCmd) = when (p.protocol) {
            IrProtocol.NEC, IrProtocol.SAMSUNG, IrProtocol.JVC -> 255 to 255
            IrProtocol.NEC_EXT -> 65535 to 255
            IrProtocol.NEC42 -> 8191 to 255
            IrProtocol.NEC42_EXT -> 67108863 to 65535
            IrProtocol.SONY_SIRC -> {
                if (p.bits !in listOf(12, 15, 20)) return "${p.id}: Sony bits must be 12, 15 or 20"
                (if (p.bits == 15) 255 else 31) to 127
            }
            IrProtocol.RC5 -> 31 to 127
            IrProtocol.RC6 -> 255 to 255
            IrProtocol.PANASONIC -> 4095 to 255
            IrProtocol.SHARP -> 31 to 255
            IrProtocol.RAW -> 0 to 0
        }
        if (p.protocol != IrProtocol.RAW && p.address !in 0..maxAddr) return "${p.id}: address out of range"
        for ((name, c) in p.commands) {
            if (p.protocol == IrProtocol.RAW) {
                val raw = c.raw
                if (raw.isNullOrEmpty() || raw.size > 2000 || raw.any { it <= 0 }) return "${p.id}.$name: bad raw pattern"
                if ((c.frequency ?: 38000) !in 15000..60000) return "${p.id}.$name: bad frequency"
            } else {
                val code = c.code ?: return "${p.id}.$name: missing code"
                if (code !in 0..maxCmd) return "${p.id}.$name: code out of range"
            }
        }
        return null
    }
}

package com.smartir.remote.ir

/**
 * Builds an alternating mark/space pattern in microseconds. The first element is always a mark
 * (required by ConsumerIrManager); a leading space is dropped. Consecutive same-level segments
 * are merged, so Manchester codes can be written as half-bit levels.
 */
class PulseBuilder {
    private val list = ArrayList<Int>()
    fun mark(us: Int) = add(true, us)
    fun space(us: Int) = add(false, us)

    private fun add(isMark: Boolean, us: Int) {
        if (us <= 0) return
        if (list.isEmpty()) { if (isMark) list.add(us); return }
        val lastIsMark = list.size % 2 == 1
        if (lastIsMark == isMark) list[list.lastIndex] = list.last() + us else list.add(us)
    }

    fun total(): Int = list.sum()
    fun toArray(): IntArray = list.toIntArray()

    /** Pulse-distance bits, least significant bit first. */
    fun lsb(value: Int, count: Int, mark: Int, zero: Int, one: Int) {
        for (i in 0 until count) {
            mark(mark)
            space(if (((value shr i) and 1) == 1) one else zero)
        }
    }
}

object Encoders {
    private fun inv8(v: Int) = v.inv() and 0xFF

    /** NEC: 8-bit address (+inverse) and 8-bit command (+inverse). Extended: 16-bit address. */
    fun nec(address: Int, command: Int, extended: Boolean): IrSignal {
        val b = PulseBuilder()
        b.mark(9000); b.space(4500)
        if (extended) {
            b.lsb(address and 0xFFFF, 16, 560, 560, 1690)
        } else {
            b.lsb(address and 0xFF, 8, 560, 560, 1690)
            b.lsb(inv8(address), 8, 560, 560, 1690)
        }
        b.lsb(command and 0xFF, 8, 560, 560, 1690)
        b.lsb(inv8(command), 8, 560, 560, 1690)
        b.mark(560)
        return IrSignal(38000, b.toArray())
    }

    /** NEC42 (38 kHz): 13-bit address + inverse, 8-bit command + inverse. NEC42ext: 26-bit address, 16-bit command. */
    fun nec42(address: Int, command: Int, extended: Boolean): IrSignal {
        val b = PulseBuilder()
        b.mark(9000); b.space(4500)
        if (extended) {
            b.lsb(address and 0x3FFFFFF, 26, 560, 560, 1690)
            b.lsb(command and 0xFFFF, 16, 560, 560, 1690)
        } else {
            b.lsb(address and 0x1FFF, 13, 560, 560, 1690)
            b.lsb(address.inv() and 0x1FFF, 13, 560, 560, 1690)
            b.lsb(command and 0xFF, 8, 560, 560, 1690)
            b.lsb(inv8(command), 8, 560, 560, 1690)
        }
        b.mark(560)
        return IrSignal(38000, b.toArray())
    }

    /** Samsung32: address byte sent twice, then command and inverted command. */
    fun samsung(address: Int, command: Int): IrSignal {
        val b = PulseBuilder()
        b.mark(4500); b.space(4500)
        b.lsb(address and 0xFF, 8, 560, 560, 1690)
        b.lsb(address and 0xFF, 8, 560, 560, 1690)
        b.lsb(command and 0xFF, 8, 560, 560, 1690)
        b.lsb(inv8(command), 8, 560, 560, 1690)
        b.mark(560)
        return IrSignal(38000, b.toArray())
    }

    /**
     * Sony SIRC 12/15/20 bit. Pulse-width coding (mark 600 = 0, 1200 = 1, space 600),
     * command 7 bits then address (5 bits, or 8 bits for 15-bit frames, or 5 + 8 extension
     * bits for 20-bit frames), LSB first. Frame sent 3 times with a 45 ms start-to-start period.
     */
    fun sony(address: Int, subAddress: Int, command: Int, bits: Int): IrSignal {
        val b = PulseBuilder()
        fun field(v: Int, n: Int) {
            for (i in 0 until n) {
                b.mark(if (((v shr i) and 1) == 1) 1200 else 600)
                b.space(600)
            }
        }
        repeat(3) { n ->
            val start = b.total()
            b.mark(2400); b.space(600)
            field(command, 7)
            when (bits) {
                12 -> field(address, 5)
                15 -> field(address, 8)
                else -> { field(address, 5); field(subAddress, 8) }
            }
            if (n < 2) b.space(45000 - (b.total() - start))
        }
        return IrSignal(40000, b.toArray())
    }

    /** RC5 (36 kHz, Manchester, 889 us half-bit). 14 bits: S1, S2(=~cmd bit 6), T, 5 addr, 6 cmd. */
    fun rc5(address: Int, command: Int, toggle: Boolean = false): IrSignal {
        val b = PulseBuilder()
        fun bit(v: Int) {
            if (v == 1) { b.space(889); b.mark(889) } else { b.mark(889); b.space(889) }
        }
        bit(1)
        bit(if (command >= 64) 0 else 1)
        bit(if (toggle) 1 else 0)
        for (i in 4 downTo 0) bit((address shr i) and 1)
        for (i in 5 downTo 0) bit((command shr i) and 1)
        return IrSignal(36000, b.toArray())
    }

    /** RC6 mode 0 (36 kHz): leader, start bit, 3 mode bits, double-width trailer bit, 8 addr, 8 cmd. */
    fun rc6(address: Int, command: Int, toggle: Boolean = false): IrSignal {
        val b = PulseBuilder()
        fun bit(v: Int, unit: Int = 444) {
            if (v == 1) { b.mark(unit); b.space(unit) } else { b.space(unit); b.mark(unit) }
        }
        b.mark(2664); b.space(889)
        bit(1)
        repeat(3) { bit(0) }
        bit(if (toggle) 1 else 0, 889)
        for (i in 7 downTo 0) bit((address shr i) and 1)
        for (i in 7 downTo 0) bit((command shr i) and 1)
        return IrSignal(36000, b.toArray())
    }

    /**
     * Panasonic / Kaseikyo 48-bit (37 kHz): vendor 0x2002, 4-bit vendor parity, 12-bit address,
     * 8-bit command, 8-bit XOR check over the three preceding bytes.
     */
    fun panasonic(address: Int, command: Int): IrSignal {
        val vendor = 0x2002
        var par = (vendor xor (vendor shr 8)) and 0xFF
        par = (par xor (par shr 4)) and 0xF
        val word = par or ((address and 0xFFF) shl 4)
        val check = (word and 0xFF) xor ((word shr 8) and 0xFF) xor (command and 0xFF)
        val b = PulseBuilder()
        b.mark(3456); b.space(1728)
        b.lsb(vendor, 16, 432, 432, 1296)
        b.lsb(word, 16, 432, 432, 1296)
        b.lsb(command and 0xFF, 8, 432, 432, 1296)
        b.lsb(check, 8, 432, 432, 1296)
        b.mark(432)
        return IrSignal(37000, b.toArray())
    }

    /** JVC (38 kHz): header 8400/4200, 8-bit address, 8-bit command, stop mark. */
    fun jvc(address: Int, command: Int): IrSignal {
        val b = PulseBuilder()
        b.mark(8400); b.space(4200)
        b.lsb(address and 0xFF, 8, 525, 525, 1575)
        b.lsb(command and 0xFF, 8, 525, 525, 1575)
        b.mark(525)
        return IrSignal(38000, b.toArray())
    }

    /** Sharp (38 kHz): 5-bit address, 8-bit command, expansion, check; second frame inverted. */
    fun sharp(address: Int, command: Int): IrSignal {
        val b = PulseBuilder()
        fun frame(cmd: Int, exp: Int, chk: Int) {
            b.lsb(address and 0x1F, 5, 320, 680, 1680)
            b.lsb(cmd and 0xFF, 8, 320, 680, 1680)
            b.lsb(exp, 1, 320, 680, 1680)
            b.lsb(chk, 1, 320, 680, 1680)
            b.mark(320)
        }
        frame(command, 1, 0)
        b.space(40000 - b.total())
        frame(inv8(command), 1, 1)
        return IrSignal(38000, b.toArray())
    }
}

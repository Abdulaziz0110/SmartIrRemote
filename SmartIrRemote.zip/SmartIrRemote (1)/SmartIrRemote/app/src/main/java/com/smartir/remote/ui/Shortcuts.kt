package com.smartir.remote.ui

import android.content.Context
import android.content.Intent
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import com.smartir.remote.MainActivity
import com.smartir.remote.R
import com.smartir.remote.data.db.RemoteEntity

/** Long-press launcher shortcuts that open a saved remote directly. */
object Shortcuts {
    const val EXTRA_REMOTE = "remoteId"

    fun update(ctx: Context, remotes: List<RemoteEntity>) {
        runCatching {
            val max = minOf(4, ShortcutManagerCompat.getMaxShortcutCountPerActivity(ctx))
            val top = remotes
                .sortedWith(compareByDescending<RemoteEntity> { it.favorite }.thenByDescending { it.lastUsed })
                .take(max)
            val infos = top.map { r ->
                ShortcutInfoCompat.Builder(ctx, "remote_${r.id}")
                    .setShortLabel(r.name.take(24).ifBlank { "Remote" })
                    .setLongLabel(r.name.ifBlank { "Remote" })
                    .setIcon(IconCompat.createWithResource(ctx, R.mipmap.ic_launcher))
                    .setIntent(
                        Intent(ctx, MainActivity::class.java)
                            .setAction(Intent.ACTION_VIEW)
                            .putExtra(EXTRA_REMOTE, r.id),
                    )
                    .build()
            }
            ShortcutManagerCompat.setDynamicShortcuts(ctx, infos)
        }
    }
}

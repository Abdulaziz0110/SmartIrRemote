package com.smartir.remote.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.smartir.remote.data.AppJson
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString

@Entity(tableName = "profiles")
data class ProfileEntity(
    @PrimaryKey val id: String,
    val brand: String,
    val model: String,
    val categories: String,
    val protocol: String,
    val address: Int,
    val subAddress: Int,
    val bits: Int,
    val commandsJson: String,
    val source: String,
    val license: String,
    val notes: String,
    val isUser: Boolean,
)

@Serializable
@Entity(tableName = "remotes")
data class RemoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val category: String,
    val brand: String,
    val model: String,
    val protocol: String,
    val profileId: String,
    val status: String,
    /** comma separated command keys confirmed as working */
    val verified: String = "",
    /** comma separated command keys hidden by the user (custom layout) */
    val hidden: String = "",
    /** JSON map command -> profileId for buttons replaced from another profile */
    val overrides: String = "{}",
    val favorite: Boolean = false,
    val lastUsed: Long = 0,
    val createdAt: Long = System.currentTimeMillis(),
) {
    fun verifiedSet(): Set<String> = verified.split(',').filter { it.isNotBlank() }.toSet()
    fun hiddenSet(): Set<String> = hidden.split(',').filter { it.isNotBlank() }.toSet()
    fun overrideMap(): Map<String, String> =
        try { AppJson.decodeFromString<Map<String, String>>(overrides) } catch (e: Exception) { emptyMap() }

    companion object {
        fun encodeOverrides(m: Map<String, String>): String = AppJson.encodeToString(m)
    }
}

/** Lightweight search result: no command data is loaded. */
data class ProfileHit(
    val id: String, val brand: String, val model: String, val categories: String, val protocol: String,
)

@Entity(tableName = "macros")
data class MacroEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val remoteId: Long,
    val name: String,
    /** comma separated command keys, sent in order */
    val steps: String,
    val delayMs: Long = 500,
)

@Entity(tableName = "scan_history")
data class ScanHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val category: String,
    val testCommand: String,
    val delayMs: Long,
    val testedCount: Int,
    val totalCount: Int,
    val outcome: String,
    val profileId: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
)

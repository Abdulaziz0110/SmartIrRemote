package com.smartir.remote.data.repo

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore by preferencesDataStore("settings")

data class AppSettings(
    val theme: Int = 0, val haptic: Boolean = true, val scanDelayMs: Long = 2000,
    val volumeKeys: Boolean = true, val keepScreenOn: Boolean = true,
)

/** Interrupted scan, restored after app/process restart. */
data class ScanSession(
    val category: String, val command: String, val delayMs: Long,
    val index: Int, val includeRelated: Boolean,
)

@Singleton
class SettingsStore @Inject constructor(@ApplicationContext private val ctx: Context) {
    private object K {
        val theme = intPreferencesKey("theme")
        val haptic = booleanPreferencesKey("haptic")
        val delay = longPreferencesKey("scan_delay")
        val seed = intPreferencesKey("seed_version")
        val seedSig = stringPreferencesKey("seed_sig")
        val volKeys = booleanPreferencesKey("vol_keys")
        val keepOn = booleanPreferencesKey("keep_on")
        val onboarded = booleanPreferencesKey("onboarded")
        val sCat = stringPreferencesKey("s_cat")
        val sCmd = stringPreferencesKey("s_cmd")
        val sDelay = longPreferencesKey("s_delay")
        val sIdx = intPreferencesKey("s_idx")
        val sRel = booleanPreferencesKey("s_rel")
    }

    val settings: Flow<AppSettings> = ctx.dataStore.data.map {
        AppSettings(it[K.theme] ?: 0, it[K.haptic] ?: true, it[K.delay] ?: 2000, it[K.volKeys] ?: true, it[K.keepOn] ?: true)
    }

    suspend fun setTheme(v: Int) { ctx.dataStore.edit { it[K.theme] = v } }
    suspend fun setHaptic(v: Boolean) { ctx.dataStore.edit { it[K.haptic] = v } }
    val onboarded: Flow<Boolean> = ctx.dataStore.data.map { it[K.onboarded] ?: false }
    suspend fun setOnboarded() { ctx.dataStore.edit { it[K.onboarded] = true } }
    suspend fun setVolumeKeys(v: Boolean) { ctx.dataStore.edit { it[K.volKeys] = v } }
    suspend fun setKeepOn(v: Boolean) { ctx.dataStore.edit { it[K.keepOn] = v } }
    suspend fun setScanDelay(v: Long) { ctx.dataStore.edit { it[K.delay] = v } }
    suspend fun seedSignature(): String? = ctx.dataStore.data.first()[K.seedSig]
    suspend fun setSeedSignature(v: String) { ctx.dataStore.edit { it[K.seedSig] = v } }
    suspend fun seedVersion(): Int = ctx.dataStore.data.first()[K.seed] ?: 0
    suspend fun setSeedVersion(v: Int) { ctx.dataStore.edit { it[K.seed] = v } }

    val session: Flow<ScanSession?> = ctx.dataStore.data.map {
        val c = it[K.sCat] ?: return@map null
        ScanSession(c, it[K.sCmd] ?: return@map null, it[K.sDelay] ?: 2000, it[K.sIdx] ?: return@map null, it[K.sRel] ?: true)
    }

    suspend fun saveSession(s: ScanSession) {
        ctx.dataStore.edit {
            it[K.sCat] = s.category; it[K.sCmd] = s.command; it[K.sDelay] = s.delayMs
            it[K.sIdx] = s.index; it[K.sRel] = s.includeRelated
        }
    }

    suspend fun clearSession() {
        ctx.dataStore.edit { it.remove(K.sCat); it.remove(K.sCmd); it.remove(K.sDelay); it.remove(K.sIdx); it.remove(K.sRel) }
    }
}

package com.smartir.remote.ui.screens

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.smartir.remote.R
import com.smartir.remote.data.db.RemoteEntity
import com.smartir.remote.data.repo.ProfileRepository
import com.smartir.remote.data.repo.RemoteRepository
import com.smartir.remote.domain.*
import com.smartir.remote.ir.IrEncoder
import com.smartir.remote.ir.IrProtocol
import com.smartir.remote.ir.IrTransmitter
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

data class CustomButton(val key: String = "", val code: String = "")

data class CustomState(
    val name: String = "",
    val brand: String = "",
    val category: DeviceCategory = DeviceCategory.TV,
    val protocol: IrProtocol = IrProtocol.NEC,
    val address: String = "",
    val sub: String = "",
    val bits: Int = 12,
    val buttons: List<CustomButton> = CustomProfileBuilder.STANDARD_KEYS.take(6).map { CustomButton(it) },
    val error: String? = null,
)

@HiltViewModel
class CustomRemoteViewModel @Inject constructor(
    private val profiles: ProfileRepository,
    private val remotes: RemoteRepository,
    private val transmitter: IrTransmitter,
    @ApplicationContext private val ctx: Context,
) : ViewModel() {
    private val _state = MutableStateFlow(CustomState())
    val state: StateFlow<CustomState> = _state.asStateFlow()

    fun setName(v: String) = _state.update { it.copy(name = v) }
    fun setBrand(v: String) = _state.update { it.copy(brand = v) }
    fun setCategory(v: DeviceCategory) = _state.update { it.copy(category = v) }
    fun setProtocol(v: IrProtocol) = _state.update { it.copy(protocol = v) }
    fun setAddress(v: String) = _state.update { it.copy(address = v) }
    fun setSub(v: String) = _state.update { it.copy(sub = v) }
    fun setBits(v: Int) = _state.update { it.copy(bits = v) }

    fun updateButton(i: Int, key: String, code: String) = _state.update { s ->
        s.copy(buttons = s.buttons.mapIndexed { idx, b -> if (idx == i) CustomButton(key, code) else b })
    }
    fun addButton() = _state.update { it.copy(buttons = it.buttons + CustomButton()) }
    fun removeButton(i: Int) = _state.update { s -> s.copy(buttons = s.buttons.filterIndexed { idx, _ -> idx != i }) }
    fun addStandard() = _state.update { s ->
        val have = s.buttons.map { it.key.uppercase() }.toSet()
        s.copy(buttons = s.buttons + CustomProfileBuilder.STANDARD_KEYS.filter { it !in have }.map { CustomButton(it) })
    }

    private fun message(r: BuildResult): String = when (r.error) {
        BuildError.ADDRESS -> ctx.getString(R.string.cr_err_address)
        BuildError.NO_BUTTONS -> ctx.getString(R.string.cr_err_buttons)
        BuildError.BAD_CODE -> ctx.getString(R.string.cr_err_code, r.detail)
        BuildError.INVALID -> ctx.getString(R.string.cr_err_invalid, r.detail)
        null -> ""
    }

    private fun build(id: String, buttons: List<Pair<String, String>>): BuildResult {
        val s = _state.value
        return CustomProfileBuilder.build(id, s.name, s.brand, s.category, s.protocol, s.address, s.sub, s.bits, buttons)
    }

    /** Sends only this one button, so every code can be verified before saving. */
    fun test(i: Int) {
        val b = _state.value.buttons.getOrNull(i) ?: return
        val r = build("test", listOf(b.key.ifBlank { "TEST" } to b.code))
        val p = r.profile
        if (p == null) { _state.update { it.copy(error = message(r)) }; return }
        viewModelScope.launch {
            try {
                withContext(Dispatchers.Default) { transmitter.transmit(IrEncoder.encode(p, p.commands.values.first())) }
                _state.update { it.copy(error = null) }
            } catch (e: Exception) { _state.update { it.copy(error = e.message ?: "IR error") } }
        }
    }

    fun save(onSaved: (Long) -> Unit) {
        val s = _state.value
        val r = build("custom_${System.currentTimeMillis()}", s.buttons.map { it.key to it.code })
        val p = r.profile
        if (p == null) { _state.update { it.copy(error = message(r)) }; return }
        viewModelScope.launch {
            val ins = profiles.insertProfiles(listOf(p), isUser = true)
            if (ins.imported != 1) { _state.update { it.copy(error = message(BuildResult(error = BuildError.INVALID, detail = p.id))) }; return@launch }
            val id = remotes.insert(
                RemoteEntity(
                    name = s.name.trim().ifBlank { p.brand }, category = s.category.name, brand = p.brand, model = p.model,
                    protocol = p.protocol.name, profileId = p.id, status = CompatStatus.UNVERIFIED.name,
                ),
            )
            onSaved(id)
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CustomRemoteScreen(onBack: () -> Unit, onSaved: (Long) -> Unit, vm: CustomRemoteViewModel = hiltViewModel()) {
    val s by vm.state.collectAsStateWithLifecycle()
    Scaffold(
        topBar = { AppTopBar(stringResource(R.string.cr_title), onBack) },
        bottomBar = {
            Surface(tonalElevation = 3.dp) {
                Button(
                    onClick = { vm.save(onSaved) },
                    modifier = Modifier.fillMaxWidth().navigationBarsPadding().padding(12.dp),
                ) { Text(stringResource(R.string.save_remote)) }
            }
        },
    ) { pad ->
        Column(
            Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text(stringResource(R.string.cr_intro), style = MaterialTheme.typography.bodySmall)
            OutlinedTextField(s.name, vm::setName, singleLine = true, modifier = Modifier.fillMaxWidth(), label = { Text(stringResource(R.string.cr_name)) })
            OutlinedTextField(s.brand, vm::setBrand, singleLine = true, modifier = Modifier.fillMaxWidth(), label = { Text(stringResource(R.string.cr_brand)) })

            Text(stringResource(R.string.cr_category), style = MaterialTheme.typography.titleSmall)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DeviceCategory.entries.forEach { c ->
                    FilterChip(s.category == c, { vm.setCategory(c) }, { Text(stringResource(c.labelRes)) })
                }
            }

            Text(stringResource(R.string.cr_protocol), style = MaterialTheme.typography.titleSmall)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CustomProfileBuilder.PROTOCOLS.forEach { p -> FilterChip(s.protocol == p, { vm.setProtocol(p) }, { Text(p.name) }) }
            }
            if (s.protocol == IrProtocol.SONY_SIRC) {
                Text(stringResource(R.string.cr_bits), style = MaterialTheme.typography.labelMedium)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(12, 15, 20).forEach { b -> FilterChip(s.bits == b, { vm.setBits(b) }, { Text("$b") }) }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(s.address, vm::setAddress, singleLine = true, modifier = Modifier.weight(1f), label = { Text(stringResource(R.string.cr_address)) })
                if (s.protocol == IrProtocol.SONY_SIRC && s.bits == 20) {
                    OutlinedTextField(s.sub, vm::setSub, singleLine = true, modifier = Modifier.weight(1f), label = { Text(stringResource(R.string.cr_sub)) })
                }
            }
            Text(stringResource(R.string.cr_hint), style = MaterialTheme.typography.bodySmall)

            s.buttons.forEachIndexed { i, b ->
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(b.key, { vm.updateButton(i, it, b.code) }, singleLine = true, modifier = Modifier.weight(1.3f), label = { Text(stringResource(R.string.cr_key)) })
                    OutlinedTextField(b.code, { vm.updateButton(i, b.key, it) }, singleLine = true, modifier = Modifier.weight(1f), label = { Text(stringResource(R.string.cr_code)) })
                    IconButton(onClick = { vm.test(i) }) { Icon(Icons.Filled.PlayArrow, stringResource(R.string.send)) }
                    IconButton(onClick = { vm.removeButton(i) }) { Icon(Icons.Filled.Delete, stringResource(R.string.delete)) }
                }
            }
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = vm::addButton) { Text(stringResource(R.string.cr_add)) }
                OutlinedButton(onClick = vm::addStandard) { Text(stringResource(R.string.cr_add_std)) }
            }
            s.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            Spacer(Modifier.height(16.dp))
        }
    }
}

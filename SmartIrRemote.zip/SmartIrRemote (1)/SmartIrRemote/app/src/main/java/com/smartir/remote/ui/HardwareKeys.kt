package com.smartir.remote.ui

/** Lets the remote screen take over the phone's volume keys. Set only while that screen is visible. */
object HardwareKeys {
    @Volatile var handler: ((Int) -> Boolean)? = null
}

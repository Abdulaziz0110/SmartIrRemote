package com.smartir.remote.data.repo

import android.content.Context
import com.smartir.remote.data.AppJson
import com.smartir.remote.data.db.ProfileDao
import com.smartir.remote.data.db.ProfileEntity
import com.smartir.remote.data.model.CommandDef
import com.smartir.remote.data.model.IrProfile
import com.smartir.remote.data.model.ProfileFile
import com.smartir.remote.ir.IrEncoder
import com.smartir.remote.ir.IrProtocol
import dagger.hilt.android.qualifiers.ApplicationContext
import com.smartir.remote.data.CompactJson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.InputStream
import java.io.Writer
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.serialization.encodeToString
import javax.inject.Inject
import javax.inject.Singleton

data class ImportResult(val imported: Int, val skipped: Int, val error: String? = null, val note: String? = null)

@Singleton
class ProfileRepository @Inject constructor(
    private val dao: ProfileDao,
    @ApplicationContext private val ctx: Context,
    private val settings: SettingsStore,
) {
    private val seedLock = Mutex()
    /** true while the bundled database is being imported (first launch / after an update) */
    val seeding = kotlinx.coroutines.flow.MutableStateFlow(false)
    @Volatile private var seeded = false

    suspend fun ensureSeeded() {
        if (seeded) return
        seedLock.withLock {
            if (seeded) return
            val files = (ctx.assets.list("profiles") ?: emptyArray()).filter { it.endsWith(".json") }.sorted()
            // Signature = file names + sizes: the bundled database is re-imported only when it changes.
            val sig = "$SEED_VERSION:" + files.joinToString(",") { name ->
                name + "=" + (try { ctx.assets.open("profiles/$name").use { it.available() } } catch (e: Exception) { 0 })
            }
            if (settings.seedSignature() != sig) {
                seeding.value = true
                try {
                    for (name in files) importStream({ ctx.assets.open("profiles/$name") }, isUser = false, ensure = false)
                    settings.setSeedSignature(sig)
                } finally {
                    seeding.value = false
                }
            }
            seeded = true
        }
    }

    suspend fun getAll(): List<IrProfile> { ensureSeeded(); return dao.getAll().map { it.toModel() } }
    /** Loads only profiles of the given categories (fast even with tens of thousands of profiles). */
    suspend fun getForCategories(names: Set<String>): List<IrProfile> {
        ensureSeeded()
        val entities = LinkedHashMap<String, ProfileEntity>()
        for (c in names) dao.getByCategoryLike(c).forEach { e ->
            if (c in e.categories.split(',')) entities[e.id] = e
        }
        return kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) { entities.values.map { it.toModel() } }
    }

    fun observeCategoryCounts(): kotlinx.coroutines.flow.Flow<Map<String, Int>> =
        dao.observeCategories().map { list ->
            val m = HashMap<String, Int>()
            for (s in list) for (c in s.split(',')) if (c.isNotBlank()) m[c] = (m[c] ?: 0) + 1
            m as Map<String, Int>
        }.flowOn(kotlinx.coroutines.Dispatchers.Default)

    suspend fun search(q: String): List<com.smartir.remote.data.db.ProfileHit> {
        ensureSeeded()
        return dao.search(q.replace("%", "").replace("_", ""))
    }

    fun observeCount() = dao.observeCount()
    fun observeBrandCount() = dao.observeBrandCount()

    suspend fun insertProfiles(list: List<IrProfile>, isUser: Boolean): ImportResult {
        val valid = list.filter { IrEncoder.validate(it) == null }
        dao.insertAll(valid.map { it.toEntity(isUser) })
        return ImportResult(valid.size, list.size - valid.size)
    }

    suspend fun getById(id: String): IrProfile? { ensureSeeded(); return dao.getById(id)?.toModel() }

    suspend fun importText(text: String, isUser: Boolean = true, ensure: Boolean = true): ImportResult {
        if (ensure) ensureSeeded()
        val parsed = try {
            ProfileJson.parse(text)
        } catch (e: Exception) {
            return ImportResult(0, 0, e.message ?: "invalid JSON")
        }
        val r = insertProfiles(parsed.profiles, isUser)
        return ImportResult(r.imported, r.skipped + parsed.skipped)
    }

    /** Streams one-profile-per-line exports (low memory); any other JSON layout is parsed in full. */
    suspend fun importStream(open: () -> InputStream?, isUser: Boolean = true, ensure: Boolean = true): ImportResult = withContext(Dispatchers.IO) {
        if (ensure) ensureSeeded()
        val head = open()?.bufferedReader()?.use { it.readLine() }
            ?: return@withContext ImportResult(0, 0, "cannot open file")
        if (!head.trimEnd().endsWith("\"profiles\":[")) {
            val text = open()?.bufferedReader()?.use { it.readText() }
                ?: return@withContext ImportResult(0, 0, "cannot open file")
            return@withContext importText(text, isUser, ensure = false)
        }
        var imported = 0
        var skipped = 0
        val batch = ArrayList<IrProfile>()
        suspend fun flush() {
            if (batch.isEmpty()) return
            val r = insertProfiles(batch.toList(), isUser)
            imported += r.imported; skipped += r.skipped
            batch.clear()
        }
        val input = open() ?: return@withContext ImportResult(0, 0, "cannot open file")
        input.bufferedReader().use { r ->
            r.readLine() // header
            while (true) {
                val line = r.readLine() ?: break
                val t = line.trim().removeSuffix(",")
                if (t.startsWith("]")) break
                if (!t.startsWith("{")) continue
                val p = runCatching { CompactJson.decodeFromString(IrProfile.serializer(), t) }.getOrNull()
                if (p == null) skipped++ else batch += p
                if (batch.size >= 300) flush()
            }
        }
        flush()
        ImportResult(imported, skipped)
    }

    /** Writes the WHOLE profile database, one profile per line, page by page. Returns the count. */
    suspend fun exportAll(out: Writer): Int = withContext(Dispatchers.IO) {
        out.write("{\"schema\":1,\"source\":\"Smart IR Remote export\",\"license\":\"\",\"profiles\":[\n")
        var first = true
        var n = 0
        var offset = 0
        while (true) {
            val page = dao.page(500, offset)
            if (page.isEmpty()) break
            for (e in page) {
                if (!first) out.write(",\n")
                first = false
                out.write(CompactJson.encodeToString(IrProfile.serializer(), e.toModel()))
                n++
            }
            offset += page.size
        }
        out.write("\n]}\n")
        out.flush()
        n
    }

    suspend fun exportUserProfiles(): String {
        val list = dao.getUser().map { it.toModel() }
        return AppJson.encodeToString(ProfileFile(profiles = list))
    }

    suspend fun userProfiles(): List<IrProfile> = dao.getUser().map { it.toModel() }

    companion object { const val SEED_VERSION = 1 }
}

fun IrProfile.toEntity(isUser: Boolean) = ProfileEntity(
    id = id, brand = brand, model = model, categories = categories.joinToString(","),
    protocol = protocol.name, address = address, subAddress = subAddress, bits = bits,
    commandsJson = AppJson.encodeToString(commands),
    source = source, license = license, notes = notes, isUser = isUser,
)

fun ProfileEntity.toModel() = IrProfile(
    id = id, brand = brand, model = model,
    categories = categories.split(',').filter { it.isNotBlank() },
    protocol = IrProtocol.valueOf(protocol), address = address, subAddress = subAddress, bits = bits,
    commands = AppJson.decodeFromString<Map<String, CommandDef>>(commandsJson),
    source = source, license = license, notes = notes,
)

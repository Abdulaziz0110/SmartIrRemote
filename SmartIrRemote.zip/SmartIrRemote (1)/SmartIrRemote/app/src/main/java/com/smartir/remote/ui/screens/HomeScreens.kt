package com.smartir.remote.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.smartir.remote.R
import com.smartir.remote.domain.DeviceCategory

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onRemotes: () -> Unit, onAdd: () -> Unit, onScan: () -> Unit, onManual: () -> Unit,
    onSearch: () -> Unit, onCustom: () -> Unit, onIrTest: () -> Unit,
    onSettings: () -> Unit, onRemote: (Long) -> Unit, onChoose: (DeviceCategory, Boolean) -> Unit,
    vm: HomeViewModel = hiltViewModel(),
) {
    val recent by vm.recent.collectAsStateWithLifecycle()
    val count by vm.profileCount.collectAsStateWithLifecycle()
    val counts by vm.categoryCounts.collectAsStateWithLifecycle()
    val seeding by vm.seeding.collectAsStateWithLifecycle()
    val favorites by vm.favorites.collectAsStateWithLifecycle()
    val showWelcome by vm.showWelcome.collectAsStateWithLifecycle()
    var dialogFor by remember { mutableStateOf<DeviceCategory?>(null) }
    Scaffold(topBar = { AppTopBar(stringResource(R.string.app_name), null) }) { pad ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(3), modifier = Modifier.padding(pad),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            if (!vm.hasIr) item(span = { GridItemSpan(maxLineSpan) }) {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                    Column(Modifier.padding(12.dp)) {
                        Text(stringResource(R.string.no_ir_title), style = MaterialTheme.typography.titleSmall)
                        Text(stringResource(R.string.no_ir_msg), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            if (seeding) item(span = { GridItemSpan(maxLineSpan) }) {
                Card {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(stringResource(R.string.home_preparing, count.coerceAtLeast(0)), style = MaterialTheme.typography.bodyMedium)
                        LinearProgressIndicator(Modifier.fillMaxWidth())
                    }
                }
            }
            if (!seeding && count in 0..99) item(span = { GridItemSpan(maxLineSpan) }) {
                Card(Modifier.clickable(onClick = onSettings), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)) {
                    Text(stringResource(R.string.home_db_banner, count), Modifier.padding(12.dp), style = MaterialTheme.typography.bodyMedium)
                }
            }
            val actions = listOf(
                Triple(Icons.Filled.SettingsRemote, R.string.home_my_remotes, onRemotes),
                Triple(Icons.Filled.Add, R.string.home_add_remote, onAdd),
                Triple(Icons.Filled.Sensors, R.string.home_auto_scan, onScan),
                Triple(Icons.Filled.Search, R.string.home_manual, onManual),
                Triple(Icons.Filled.FindInPage, R.string.home_search, onSearch),
                Triple(Icons.Filled.Build, R.string.home_custom, onCustom),
                Triple(Icons.Filled.FlashOn, R.string.home_irtest, onIrTest),
                Triple(Icons.Filled.Settings, R.string.home_settings, onSettings),
            )
            items(actions) { (icon, label, click) -> ActionTile(icon, stringResource(label), click) }

            if (favorites.isNotEmpty()) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Text(stringResource(R.string.home_favorites), style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 8.dp))
                }
                item(span = { GridItemSpan(maxLineSpan) }) {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(favorites, key = { it.id }) { r ->
                            Card(Modifier.clickable { onRemote(r.id) }, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                                Column(Modifier.padding(12.dp)) {
                                    Text(r.name, style = MaterialTheme.typography.titleSmall)
                                    Text(r.brand, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                }
            }
            item(span = { GridItemSpan(maxLineSpan) }) {
                Text(stringResource(R.string.home_recent), style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 8.dp))
            }
            item(span = { GridItemSpan(maxLineSpan) }) {
                if (recent.isEmpty()) Text(stringResource(R.string.home_no_recent), style = MaterialTheme.typography.bodySmall)
                else LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(recent, key = { it.id }) { r ->
                        Card(Modifier.clickable { onRemote(r.id) }) {
                            Column(Modifier.padding(12.dp)) {
                                Text(r.name, style = MaterialTheme.typography.titleSmall)
                                Text(r.brand, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
            item(span = { GridItemSpan(maxLineSpan) }) {
                Text(stringResource(R.string.home_categories), style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 8.dp))
            }
            items(DeviceCategory.entries.toList()) { c -> CategoryTile(c, counts[c.name] ?: 0) { dialogFor = it } }
        }
    }
    dialogFor?.let { CategoryChoiceDialog(it, onChoose) { dialogFor = null } }
    if (showWelcome) {
        AlertDialog(
            onDismissRequest = vm::dismissWelcome,
            title = { Text(stringResource(R.string.welcome_title)) },
            text = { Text(stringResource(R.string.welcome_body), Modifier.verticalScroll(rememberScrollState())) },
            confirmButton = { TextButton(onClick = vm::dismissWelcome) { Text(stringResource(R.string.welcome_ok)) } },
        )
    }
}

@Composable
private fun ActionTile(icon: ImageVector, label: String, onClick: () -> Unit) {
    ElevatedCard(Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Column(
            Modifier.fillMaxWidth().padding(12.dp).heightIn(min = 80.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
        ) {
            Icon(icon, null, Modifier.size(30.dp), tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(6.dp))
            Text(label, style = MaterialTheme.typography.labelMedium, textAlign = TextAlign.Center)
        }
    }
}

@Composable
fun PickScreen(mode: String, onBack: () -> Unit, onChoose: (DeviceCategory, Boolean) -> Unit, vm: HomeViewModel = hiltViewModel()) {
    val counts by vm.categoryCounts.collectAsStateWithLifecycle()
    var dialogFor by remember { mutableStateOf<DeviceCategory?>(null) }
    Scaffold(topBar = { AppTopBar(stringResource(R.string.pick_title), onBack) }) { pad ->
        CategoryGrid(
            onClick = { c ->
                when (mode) {
                    "scan" -> onChoose(c, true)
                    "manual" -> onChoose(c, false)
                    else -> dialogFor = c
                }
            },
            counts = counts,
            modifier = Modifier.padding(pad),
        )
    }
    dialogFor?.let { CategoryChoiceDialog(it, onChoose) { dialogFor = null } }
}

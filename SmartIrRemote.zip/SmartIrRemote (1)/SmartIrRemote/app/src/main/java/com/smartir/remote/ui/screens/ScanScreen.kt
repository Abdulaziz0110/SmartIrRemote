package com.smartir.remote.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.smartir.remote.R
import com.smartir.remote.domain.Cmd
import com.smartir.remote.scan.ScanState
import com.smartir.remote.scan.ScanStatus

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ScanScreen(
    onBack: () -> Unit,
    onConfirm: (category: String, profileId: String) -> Unit,
    vm: ScanViewModel = hiltViewModel(),
) {
    val st by vm.engine.state.collectAsStateWithLifecycle()
    val setup by vm.setup.collectAsStateWithLifecycle()
    val haptic = LocalHapticFeedback.current
    val cat = vm.category
    val idle = st.status in setOf(ScanStatus.IDLE, ScanStatus.STOPPED, ScanStatus.FINISHED, ScanStatus.ERROR)
    val manualOk = st.status == ScanStatus.PAUSED || st.status == ScanStatus.FOUND

    Scaffold(
        topBar = { AppTopBar(stringResource(R.string.scan_title) + " · " + stringResource(cat.labelRes), onBack) },
        bottomBar = {
            Surface(tonalElevation = 3.dp) {
                Column(Modifier.navigationBarsPadding().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        when (st.status) {
                            ScanStatus.RUNNING -> {
                                OutlinedButton(onClick = vm.engine::pause, Modifier.weight(1f)) { Text(stringResource(R.string.btn_pause)) }
                                OutlinedButton(onClick = vm.engine::stop, Modifier.weight(1f)) { Text(stringResource(R.string.btn_stop)) }
                            }
                            ScanStatus.PAUSED, ScanStatus.FOUND -> {
                                Button(onClick = vm.engine::resume, Modifier.weight(1f)) { Text(stringResource(R.string.btn_resume)) }
                                OutlinedButton(onClick = vm.engine::stop, Modifier.weight(1f)) { Text(stringResource(R.string.btn_stop)) }
                            }
                            else -> Button(
                                onClick = vm::start, Modifier.weight(1f),
                                enabled = vm.hasIr && setup.count > 0 && !setup.loading,
                            ) { Text(stringResource(R.string.btn_start)) }
                        }
                    }
                    // FOUND IT! is always large and visible
                    Button(
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            vm.engine.found()
                        },
                        enabled = st.status == ScanStatus.RUNNING || st.status == ScanStatus.PAUSED,
                        modifier = Modifier.fillMaxWidth().height(72.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary, contentColor = MaterialTheme.colorScheme.onTertiary),
                    ) { Text(stringResource(R.string.btn_found), fontSize = 26.sp) }
                }
            }
        },
    ) { pad ->
        Column(
            Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (!vm.hasIr) Text(stringResource(R.string.no_ir_msg), color = MaterialTheme.colorScheme.error)

            if (idle) {
                Card { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(stringResource(R.string.scan_hint), style = MaterialTheme.typography.bodyMedium)
                    Text(stringResource(R.string.scan_safe_note), style = MaterialTheme.typography.bodySmall)
                    if (cat.stateful) Text(stringResource(R.string.scan_ac_warn), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)

                    Text(stringResource(R.string.scan_command), style = MaterialTheme.typography.titleSmall)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        cat.testCommands.forEach { c ->
                            val n = setup.commandCounts[c] ?: 0
                            FilterChip(selected = setup.command == c, enabled = n > 0 || setup.loading, onClick = { vm.setCommand(c) }, label = { Text("${Cmd.label(c)} ($n)") })
                        }
                    }

                    OutlinedTextField(
                        setup.brand, vm::setBrand, singleLine = true, modifier = Modifier.fillMaxWidth(),
                        label = { Text(stringResource(R.string.scan_brand)) },
                    )
                    Text(stringResource(R.string.scan_speed), style = MaterialTheme.typography.titleSmall)
                    var custom by remember { mutableStateOf(false) }
                    val presets = listOf(R.string.scan_slow to 1500L, R.string.scan_normal to 1000L, R.string.scan_fast to 500L)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        presets.forEach { (label, ms) ->
                            FilterChip(
                                selected = !custom && setup.delayMs == ms, enabled = ms >= cat.minDelayMs,
                                onClick = { custom = false; vm.setDelay(ms) }, label = { Text(stringResource(label)) },
                            )
                        }
                        FilterChip(selected = custom, onClick = { custom = true }, label = { Text(stringResource(R.string.scan_custom)) })
                    }
                    if (custom) {
                        val lo = maxOf(0.3f, cat.minDelayMs / 1000f)
                        Text("%.1f s".format(setup.delayMs / 1000f))
                        Slider(
                            value = (setup.delayMs / 1000f).coerceIn(lo, 10f),
                            onValueChange = { vm.setDelay(Math.round(it * 10) * 100L) },
                            valueRange = lo..10f, steps = ((10f - lo) / 0.1f).toInt() - 1,
                        )
                    }
                    Text(stringResource(R.string.scan_recommended, "%.1f".format(cat.recommendedDelayMs / 1000f)), style = MaterialTheme.typography.bodySmall)
                    TextButton(onClick = { vm.setDelay(cat.recommendedDelayMs); custom = false }) { Text(stringResource(R.string.ok)) }

                    if (cat.related.isNotEmpty()) Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(stringResource(R.string.scan_related), Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                        Switch(checked = setup.includeRelated, onCheckedChange = vm::setRelated)
                    }
                    Text(
                        if (setup.count > 0) stringResource(R.string.scan_count, setup.count) else stringResource(R.string.scan_none),
                        style = MaterialTheme.typography.titleSmall,
                        color = if (setup.count > 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                    )
                    setup.recover?.let { r ->
                        OutlinedButton(onClick = vm::resumeSession, Modifier.fillMaxWidth()) {
                            Text(stringResource(R.string.scan_resume_session, r.index + 1))
                        }
                    }
                } }
            }

            if (st.status == ScanStatus.ERROR) Text(stringResource(R.string.scan_error, st.error ?: ""), color = MaterialTheme.colorScheme.error)
            if (st.status == ScanStatus.FINISHED) Text(stringResource(R.string.scan_finished), style = MaterialTheme.typography.titleMedium)
            if (st.status == ScanStatus.FOUND) Text(stringResource(R.string.scan_found_hint), style = MaterialTheme.typography.titleSmall)

            var tick by remember { mutableStateOf(true) }
            LaunchedEffect(st.sentIndex, st.status) {
                if (tick && st.status == ScanStatus.RUNNING && st.sentIndex >= 0) {
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(R.string.scan_tick), Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                Switch(tick, { tick = it })
            }
            StatsCard(st, vm)

            if (manualOk) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = vm.engine::previous, Modifier.weight(1f), contentPadding = PaddingValues(4.dp)) { Text(stringResource(R.string.btn_prev), fontSize = 11.sp) }
                    OutlinedButton(onClick = vm.engine::retest, Modifier.weight(1f), contentPadding = PaddingValues(4.dp)) { Text(stringResource(R.string.btn_retest), fontSize = 11.sp) }
                    OutlinedButton(onClick = vm.engine::next, Modifier.weight(1f), contentPadding = PaddingValues(4.dp)) { Text(stringResource(R.string.btn_next), fontSize = 11.sp) }
                }
                Text(stringResource(R.string.scan_recent), style = MaterialTheme.typography.titleSmall)
                st.recent.reversed().forEach { idx ->
                    val t = vm.targetAt(idx) ?: return@forEach
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            Text("#${idx + 1}  ${t.profile.displayName}", style = MaterialTheme.typography.titleSmall)
                            Text(t.profile.protocol.name, style = MaterialTheme.typography.bodySmall)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { vm.engine.testIndex(idx) }) { Text(stringResource(R.string.btn_retest)) }
                                Button(onClick = { onConfirm(cat.name, t.profile.id) }) { Text(stringResource(R.string.scan_this)) }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatsCard(st: ScanState, vm: ScanViewModel) {
    val t = vm.targetAt(st.sentIndex)
    Card {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            StatRow(stringResource(R.string.lbl_brand), t?.profile?.brand ?: "—")
            StatRow(stringResource(R.string.lbl_protocol), t?.profile?.protocol?.name ?: "—")
            StatRow(stringResource(R.string.lbl_profile), t?.profile?.model?.ifBlank { t.profile.id } ?: "—")
            StatRow(stringResource(R.string.lbl_tested), st.tested.toString())
            StatRow(stringResource(R.string.lbl_total), st.total.toString())
            StatRow(stringResource(R.string.lbl_progress), "${(st.progress * 100).toInt()}%")
            LinearProgressIndicator(progress = { st.progress }, Modifier.fillMaxWidth())
            StatRow(stringResource(R.string.lbl_elapsed), fmtTime(st.elapsedMs))
            StatRow(stringResource(R.string.lbl_remaining), st.remainingMs?.let { fmtTime(it) } ?: "—")
        }
    }
}

@Composable
private fun StatRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodyMedium)
        Text(value, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
    }
}

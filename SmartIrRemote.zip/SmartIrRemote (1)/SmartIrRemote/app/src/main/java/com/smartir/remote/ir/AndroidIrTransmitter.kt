package com.smartir.remote.ir

import android.content.Context
import android.hardware.ConsumerIrManager
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AndroidIrTransmitter @Inject constructor(
    @ApplicationContext ctx: Context,
) : IrTransmitter {

    private val manager: ConsumerIrManager? =
        ctx.getSystemService(Context.CONSUMER_IR_SERVICE) as? ConsumerIrManager

    override val isAvailable: Boolean
        get() = try { manager?.hasIrEmitter() == true } catch (e: Exception) { false }

    override val carrierRanges: List<IntRange>
        get() = try {
            manager?.carrierFrequencies?.map { it.minFrequency..it.maxFrequency } ?: emptyList()
        } catch (e: Exception) { emptyList() }

    override fun transmit(signal: IrSignal) {
        val m = manager ?: throw IrException("No IR transmitter")
        try {
            m.transmit(clamp(m, signal.frequency), signal.pattern)
        } catch (e: Exception) {
            throw IrException(e.message ?: "IR transmit failed", e)
        }
    }

    /** Some phones only accept carriers inside their supported ranges. */
    private fun clamp(m: ConsumerIrManager, freq: Int): Int {
        val ranges = try { m.carrierFrequencies } catch (e: Exception) { null }
        if (ranges.isNullOrEmpty()) return freq
        if (ranges.any { freq in it.minFrequency..it.maxFrequency }) return freq
        return ranges.map { r -> if (freq < r.minFrequency) r.minFrequency else r.maxFrequency }
            .minByOrNull { kotlin.math.abs(it - freq) } ?: freq
    }
}

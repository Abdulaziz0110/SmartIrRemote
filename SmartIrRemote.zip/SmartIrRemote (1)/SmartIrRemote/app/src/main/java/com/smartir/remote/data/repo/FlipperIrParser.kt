package com.smartir.remote.data.repo

import com.smartir.remote.data.model.CommandDef
import com.smartir.remote.data.model.IrProfile
import com.smartir.remote.ir.IrProtocol

/** Converts one Flipper-IRDB `.ir` file into IR profiles (Kotlin port of tools/build_profiles.py). */
object FlipperIrParser {
    const val SOURCE = "UberGuidoZ/Flipper-IRDB"
    const val LICENSE = "CC0-1.0"

    private val NAMES = mapOf(
        "POWER" to "POWER", "PWR" to "POWER", "POWER_TOGGLE" to "POWER", "POWER_ON" to "POWER_ON", "POWER_OFF" to "POWER_OFF",
        "VOL+" to "VOLUME_UP", "VOL_UP" to "VOLUME_UP", "VOLUME_UP" to "VOLUME_UP", "VOLUP" to "VOLUME_UP", "VOL_PLUS" to "VOLUME_UP",
        "VOL-" to "VOLUME_DOWN", "VOL_DN" to "VOLUME_DOWN", "VOL_DOWN" to "VOLUME_DOWN", "VOLUME_DOWN" to "VOLUME_DOWN",
        "VOLDOWN" to "VOLUME_DOWN", "VOL_MINUS" to "VOLUME_DOWN", "MUTE" to "MUTE",
        "CH+" to "CHANNEL_UP", "CH_UP" to "CHANNEL_UP", "CH_NEXT" to "CHANNEL_UP", "CHANNEL_UP" to "CHANNEL_UP", "CH_PLUS" to "CHANNEL_UP",
        "CH-" to "CHANNEL_DOWN", "CH_DN" to "CHANNEL_DOWN", "CH_DOWN" to "CHANNEL_DOWN", "CH_PREV" to "CHANNEL_DOWN",
        "CHANNEL_DOWN" to "CHANNEL_DOWN", "CH_MINUS" to "CHANNEL_DOWN",
        "MENU" to "MENU", "HOME" to "HOME", "BACK" to "BACK", "RETURN" to "BACK", "EXIT" to "BACK",
        "OK" to "OK", "ENTER" to "OK", "SELECT" to "OK", "UP" to "UP", "DOWN" to "DOWN", "LEFT" to "LEFT", "RIGHT" to "RIGHT",
        "INPUT" to "SOURCE", "SOURCE" to "SOURCE", "TV_INPUT" to "SOURCE", "SETTINGS" to "SETTINGS",
        "TEMP_UP" to "TEMP_UP", "TEMP+" to "TEMP_UP", "TEMP_DOWN" to "TEMP_DOWN", "TEMP_DN" to "TEMP_DOWN", "TEMP-" to "TEMP_DOWN",
        "MODE" to "MODE", "FAN" to "FAN_SPEED", "FAN_SPEED" to "FAN_SPEED", "SWING" to "SWING",
        "SPEED_UP" to "SPEED_UP", "SPEED_DOWN" to "SPEED_DOWN", "SPEED+" to "SPEED_UP", "SPEED-" to "SPEED_DOWN",
        "BRIGHT_UP" to "BRIGHTNESS_UP", "BRIGHTNESS_UP" to "BRIGHTNESS_UP", "BRIGHT_DOWN" to "BRIGHTNESS_DOWN",
        "BRIGHTNESS_DOWN" to "BRIGHTNESS_DOWN", "PLAY" to "PLAY_PAUSE", "PAUSE" to "PLAY_PAUSE", "PLAY_PAUSE" to "PLAY_PAUSE",
        "STOP" to "STOP", "REWIND" to "REWIND", "RW" to "REWIND", "FF" to "FORWARD", "FORWARD" to "FORWARD",
        "NEXT" to "NEXT_TRACK", "PREV" to "PREV_TRACK",
    )
    private val ws = Regex("\\s+")
    private val digit = Regex("(?:NUM_?|NUMBER_?|DIGIT_?|KEY_?|BTN_?)?([0-9])")

    private val EXTRA = mapOf(
        "INFO" to "INFO", "DISPLAY" to "INFO", "DISP" to "INFO", "GUIDE" to "GUIDE", "EPG" to "GUIDE",
        "LAST" to "LAST", "RECALL" to "LAST", "PREV_CH" to "LAST", "FLASHBACK" to "LAST", "JUMP" to "LAST",
        "SUBTITLE" to "SUBTITLE", "SUB" to "SUBTITLE", "SUB_TITLE" to "SUBTITLE", "CC" to "SUBTITLE",
        "TEXT" to "TEXT", "TELETEXT" to "TEXT", "TTX" to "TEXT",
        "FAV" to "FAV", "FAVORITE" to "FAV", "FAVOURITE" to "FAV", "FAV_CH" to "FAV",
        "SLEEP" to "SLEEP", "SLEEP_TIMER" to "SLEEP",
        "ASPECT" to "ASPECT", "FORMAT" to "ASPECT", "ZOOM" to "ASPECT", "ASPECT_RATIO" to "ASPECT", "SCREEN_SIZE" to "ASPECT",
        "PICTURE" to "PICTURE", "PIC" to "PICTURE", "P_MODE" to "PICTURE", "PICTURE_MODE" to "PICTURE", "PMODE" to "PICTURE",
        "SOUND" to "SOUND", "S_MODE" to "SOUND", "SOUND_MODE" to "SOUND", "SMODE" to "SOUND", "AUDIO" to "SOUND",
        "RED" to "RED", "GREEN" to "GREEN", "YELLOW" to "YELLOW", "BLUE" to "BLUE",
        "APPS" to "APPS", "APP" to "APPS", "SMART" to "SMART_HUB", "SMART_HUB" to "SMART_HUB", "HUB" to "SMART_HUB",
        "NETFLIX" to "NETFLIX", "YOUTUBE" to "YOUTUBE", "REC" to "RECORD", "RECORD" to "RECORD",
        "EJECT" to "EJECT", "OPEN_CLOSE" to "EJECT", "OPEN" to "EJECT", "TIMER" to "TIMER", "ECO" to "ECO",
        "TURBO" to "TURBO", "POWERFUL" to "TURBO", "TV" to "TV",
    )

    private val EXTRA2 = mapOf(
        "AUDIO_MUTE" to "MUTE", "VOLUME_MUTE" to "MUTE", "SOUND_MUTE" to "MUTE", "MUTE_TOGGLE" to "MUTE", "MUTING" to "MUTE",
        "STANDBY" to "POWER", "ON_OFF" to "POWER", "POWER_ON_OFF" to "POWER", "PWR_TOGGLE" to "POWER", "ONOFF" to "POWER",
        "CENTER" to "OK", "SEL" to "OK", "OK_SELECT" to "OK",
        "MAIN_MENU" to "MENU", "TV_MENU" to "MENU", "OSD" to "MENU", "SETUP" to "SETTINGS",
        "AV" to "SOURCE", "TV_AV" to "SOURCE", "INPUT_SELECT" to "SOURCE", "INPUT_SOURCE" to "SOURCE", "SOURCES" to "SOURCE", "EXT" to "SOURCE",
        "BACK_RETURN" to "BACK", "RETURN_BACK" to "BACK", "CANCEL" to "BACK", "HOME_MENU" to "HOME", "SMART_HOME" to "HOME",
        "CHANNEL_LIST" to "CH_LIST", "CH_LIST" to "CH_LIST", "LIST" to "CH_LIST", "DASH" to "DASH", "ENTER_CH" to "DASH",
    )
    private val dirRe = Regex("^(VOL|VOLUME|CH|CHANNEL|PROG|PR|TEMP|TEMPERATURE|SPEED|BRIGHT|BRIGHTNESS)_?(PLUS|UP|INC|INCREASE|NEXT|MINUS|DOWN|DN|DEC|DECREASE|PREV|PREVIOUS)$")
    private val arrowRe = Regex("^(?:ARROW|CURSOR|NAV|NAVIGATION|DPAD|D_PAD|KEY|BTN|BUTTON)_?(UP|DOWN|LEFT|RIGHT)$")

    /** Standard key name, or a cleaned-up original name so that no button is lost. */
    fun normName(name: String): String? {
        var n = name.trim().uppercase().replace("+", "_PLUS").replace(Regex("-+$"), "_MINUS")
        n = n.replace(Regex("[\\s\\-]+"), "_").replace(Regex("_+"), "_").trim('_')
        NAMES[n]?.let { return it }
        EXTRA[n]?.let { return it }
        EXTRA2[n]?.let { return it }
        dirRe.matchEntire(n)?.let { m ->
            val base = when (m.groupValues[1]) {
                "VOL", "VOLUME" -> "VOLUME"
                "CH", "CHANNEL", "PROG", "PR" -> "CHANNEL"
                "TEMP", "TEMPERATURE" -> "TEMP"
                "SPEED" -> "SPEED"
                else -> "BRIGHTNESS"
            }
            val up = m.groupValues[2] in setOf("PLUS", "UP", "INC", "INCREASE", "NEXT")
            return base + if (up) "_UP" else "_DOWN"
        }
        arrowRe.matchEntire(n)?.let { return it.groupValues[1] }
        digit.matchEntire(n)?.let { return "NUM_" + it.groupValues[1] }
        val clean = n.replace(Regex("[^A-Z0-9_]"), "").trim('_').take(40)
        return clean.ifBlank { null }
    }

    private val rules: List<Pair<Regex, List<String>>> = listOf(
        Regex("air_cond|\\bacs?\\b|aircon|hvac") to listOf("AIR_CONDITIONER"),
        Regex("projector") to listOf("PROJECTOR"),
        Regex("soundbar|speaker|audio|receiver|amplifier|hi-?fi") to listOf("AUDIO"),
        Regex("fan") to listOf("FAN"),
        Regex("led|light") to listOf("LED_CONTROLLER"),
        Regex("dvd|blu") to listOf("DVD"),
        Regex("streaming|tv_?box|android_box|media_?player") to listOf("TV_BOX"),
        Regex("cable|set_?top|satellite|stb|iptv") to listOf("SET_TOP_BOX"),
        Regex("camera|dvr|nvr") to listOf("CAMERA_DVR"),
        Regex("\\btvs?\\b|television|monitor|display") to listOf("TV", "SMART_TV"),
    )

    fun categoryFor(topFolder: String): List<String> {
        val s = topFolder.lowercase()
        return rules.firstOrNull { it.first.containsMatchIn(s) }?.second ?: listOf("OTHER")
    }

    private fun slug(s: String) = s.lowercase().replace(Regex("[^a-z0-9]+"), "_").trim('_')

    private fun le(s: String): Pair<Long, ByteArray>? = runCatching {
        val b = s.trim().split(ws).map { it.toInt(16).toByte() }.toByteArray()
        var v = 0L
        for (i in b.indices.reversed()) v = (v shl 8) or (b[i].toLong() and 0xFF)
        v to b
    }.getOrNull()

    private class Acc(val id: String, val model: String, val protocol: IrProtocol, val address: Int, val sub: Int, val bits: Int) {
        val commands = LinkedHashMap<String, CommandDef>()
    }

    /** @param parts path inside the repository, e.g. ["TVs", "LG", "LG_42.ir"] */
    fun parse(
        text: String, parts: List<String>, source: String = SOURCE,
        skipped: MutableMap<String, Int>? = null,
    ): List<IrProfile> {
        if (parts.isEmpty()) return emptyList()
        val cats = categoryFor(if (parts.size > 1) parts[0] else "other")
        val brand = (if (parts.size > 2) parts[1] else if (parts.size > 1) parts[0] else "Unknown").replace('_', ' ')
        val fileName = parts.last().substringBeforeLast('.')
        val model = fileName.replace('_', ' ')
        val base = slug((parts.dropLast(1) + fileName).joinToString("_"))
        val accs = LinkedHashMap<String, Acc>()

        fun acc(id: String, m: String, p: IrProtocol, a: Int, s: Int, bits: Int) = accs.getOrPut(id) { Acc(id, m, p, a, s, bits) }

        fun handle(sig: Map<String, String>) {
            val key = normName(sig["name"] ?: return) ?: return
            if (sig["type"] == "raw") {
                val data = runCatching { sig["data"]!!.trim().split(ws).map { it.toInt() } }.getOrNull() ?: return
                val freq = sig["frequency"]?.toIntOrNull() ?: 38000
                if (data.isEmpty() || data.size > 2000 || data.any { it <= 0 } || freq !in 15000..60000) { skipped?.merge("RAW(invalid)", 1) { x, y -> x + y }; return }
                acc(base + "_raw", "$model (raw)", IrProtocol.RAW, 0, 0, 0).commands.putIfAbsent(key, CommandDef(frequency = freq, raw = data))
                return
            }
            val (a, ab) = le(sig["address"] ?: return) ?: return
            val (c, cb) = le(sig["command"] ?: return) ?: return
            val proto = sig["protocol"]
            var p: IrProtocol? = null; var addr = a.toInt(); var sub = 0; var bits = 0; var code = c.toInt()
            when (proto) {
                "NEC" -> if (a < 256 && c < 256) p = IrProtocol.NEC
                "NECext" -> if (a < 65536 && cb.size >= 2 && (cb[1].toInt() and 255) == (cb[0].toInt().inv() and 255)) {
                    p = IrProtocol.NEC_EXT; code = cb[0].toInt() and 255
                }
                "Samsung32" -> if (a < 256 && c < 256) p = IrProtocol.SAMSUNG
                "SIRC" -> if (a < 32 && c < 128) { p = IrProtocol.SONY_SIRC; bits = 12 }
                "SIRC15" -> if (a < 256 && c < 128) { p = IrProtocol.SONY_SIRC; bits = 15 }
                "SIRC20" -> if (c < 128) { p = IrProtocol.SONY_SIRC; bits = 20; addr = (a and 31).toInt(); sub = ((a shr 5) and 255).toInt() }
                "RC5" -> if (a < 32 && c < 128) p = IrProtocol.RC5
                "RC6" -> if (a < 256 && c < 256) p = IrProtocol.RC6
                "NEC42" -> if (a < 8192 && c < 256) p = IrProtocol.NEC42
                "NEC42ext" -> if (a < 67108864 && c < 65536) p = IrProtocol.NEC42_EXT
            }
            if (p == null) { skipped?.merge(proto ?: "?", 1) { x, y -> x + y }; return }
            acc("${base}_${p.name.lowercase()}_${addr}_$sub", model, p, addr, sub, bits).commands.putIfAbsent(key, CommandDef(code = code))
        }

        val cur = HashMap<String, String>()
        fun flush() { if (cur.isNotEmpty()) { handle(HashMap(cur)); cur.clear() } }
        for (raw in text.lineSequence()) {
            val line = raw.trim()
            if (line.isEmpty() || line.startsWith("#")) { flush(); continue }
            val i = line.indexOf(':')
            if (i > 0) cur[line.substring(0, i).trim().lowercase()] = line.substring(i + 1).trim()
        }
        flush()

        return accs.values.filter { it.commands.isNotEmpty() }.map {
            IrProfile(
                id = it.id, brand = brand, model = it.model, categories = cats, protocol = it.protocol,
                address = it.address, subAddress = it.sub, bits = it.bits, commands = it.commands,
                source = source, license = LICENSE,
            )
        }
    }
}

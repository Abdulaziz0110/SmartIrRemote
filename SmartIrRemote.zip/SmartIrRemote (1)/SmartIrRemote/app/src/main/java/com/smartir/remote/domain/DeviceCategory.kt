package com.smartir.remote.domain

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector
import com.smartir.remote.R

enum class DeviceCategory(
    val labelRes: Int,
    val icon: ImageVector,
    /** Safe, easily reversible commands usable for auto scan (first is the default). */
    val testCommands: List<String>,
    val recommendedDelayMs: Long,
    val minDelayMs: Long = 500,
    val stateful: Boolean = false,
    val related: List<String> = emptyList(),
    val checkCommands: List<String> = Cmd.CHECK_DEFAULT,
) {
    TV(R.string.cat_tv, Icons.Filled.Tv, listOf(Cmd.VOLUME_UP, Cmd.VOLUME_DOWN, Cmd.MUTE, Cmd.MENU, Cmd.CHANNEL_UP, Cmd.CHANNEL_DOWN), 1000),
    SMART_TV(R.string.cat_smart_tv, Icons.Filled.SmartDisplay, listOf(Cmd.VOLUME_UP, Cmd.VOLUME_DOWN, Cmd.MUTE, Cmd.MENU, Cmd.CHANNEL_UP, Cmd.CHANNEL_DOWN), 1000, related = listOf("TV")),
    INTERACTIVE_DISPLAY(R.string.cat_display, Icons.Filled.Draw, listOf(Cmd.VOLUME_UP, Cmd.VOLUME_DOWN, Cmd.MUTE, Cmd.MENU, Cmd.CHANNEL_UP, Cmd.CHANNEL_DOWN), 1500, related = listOf("TV", "SMART_TV")),
    AIR_CONDITIONER(
        R.string.cat_ac, Icons.Filled.AcUnit, listOf(Cmd.TEMP_UP, Cmd.TEMP_DOWN, Cmd.FAN_SPEED, Cmd.SWING, Cmd.MODE), 4000,
        minDelayMs = 3000, stateful = true,
        checkCommands = listOf(Cmd.TEMP_UP, Cmd.TEMP_DOWN, Cmd.MODE, Cmd.FAN_SPEED, Cmd.SWING),
    ),
    PROJECTOR(R.string.cat_projector, Icons.Filled.Theaters, listOf(Cmd.VOLUME_UP, Cmd.VOLUME_DOWN, Cmd.MUTE, Cmd.MENU, Cmd.CHANNEL_UP, Cmd.CHANNEL_DOWN), 2000),
    TV_BOX(R.string.cat_tv_box, Icons.Filled.SettingsInputHdmi, listOf(Cmd.VOLUME_UP, Cmd.MENU), 1000),
    SET_TOP_BOX(R.string.cat_stb, Icons.Filled.SettingsInputComponent, listOf(Cmd.MENU, Cmd.CHANNEL_UP, Cmd.VOLUME_UP), 1500),
    DVD(R.string.cat_dvd, Icons.Filled.Album, listOf(Cmd.MENU), 1500),
    AUDIO(R.string.cat_audio, Icons.Filled.Speaker, listOf(Cmd.VOLUME_UP, Cmd.VOLUME_DOWN, Cmd.MUTE), 1000),
    FAN(
        R.string.cat_fan, Icons.Filled.Toys, listOf(Cmd.SPEED_UP, Cmd.SPEED_DOWN), 2000,
        checkCommands = listOf(Cmd.SPEED_UP, Cmd.SPEED_DOWN, Cmd.SWING, Cmd.MODE),
    ),
    LED_CONTROLLER(
        R.string.cat_led, Icons.Filled.Lightbulb, listOf(Cmd.BRIGHTNESS_UP, Cmd.BRIGHTNESS_DOWN), 1000,
        checkCommands = listOf(Cmd.BRIGHTNESS_UP, Cmd.BRIGHTNESS_DOWN, Cmd.MODE),
    ),
    CAMERA_DVR(R.string.cat_camera, Icons.Filled.Videocam, listOf(Cmd.MENU), 1500),
    OTHER(R.string.cat_other, Icons.Filled.SettingsRemote, listOf(Cmd.VOLUME_UP, Cmd.MENU), 1000);

    /** Category names whose profiles may be tested for this category. */
    fun scanCategories(includeRelated: Boolean): Set<String> =
        buildSet { add(name); if (includeRelated) addAll(related) }
}

enum class CompatStatus(val labelRes: Int) {
    FULL(R.string.status_full), PARTIAL(R.string.status_partial), UNVERIFIED(R.string.status_unverified);

    companion object {
        fun compute(available: Int, works: Int): CompatStatus = when {
            available == 0 || works == 0 -> UNVERIFIED
            works >= available -> FULL
            else -> PARTIAL
        }
    }
}

package com.smartir.remote.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.smartir.remote.R
import com.smartir.remote.data.db.ProfileHit
import com.smartir.remote.data.repo.ProfileRepository
import com.smartir.remote.domain.DeviceCategory
import com.smartir.remote.ir.IrSignal
import com.smartir.remote.ir.IrTransmitter
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.mapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

// ------------------------------------------------------------------ search across the whole database
@OptIn(FlowPreview::class, ExperimentalCoroutinesApi::class)
@HiltViewModel
class SearchViewModel @Inject constructor(private val repo: ProfileRepository) : ViewModel() {
    val query = MutableStateFlow("")
    val results: StateFlow<List<ProfileHit>> = query
        .debounce(250)
        .mapLatest { q ->
            val t = q.trim()
            if (t.length < 2) emptyList<ProfileHit>() else repo.search(t)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
}

private fun categoryOf(hit: ProfileHit): DeviceCategory =
    hit.categories.split(',').firstNotNullOfOrNull { runCatching { DeviceCategory.valueOf(it) }.getOrNull() }
        ?: DeviceCategory.OTHER

@Composable
fun SearchScreen(onBack: () -> Unit, onPick: (String, String) -> Unit, vm: SearchViewModel = hiltViewModel()) {
    val q by vm.query.collectAsStateWithLifecycle()
    val results by vm.results.collectAsStateWithLifecycle()
    Scaffold(topBar = { AppTopBar(stringResource(R.string.search_title), onBack) }) { pad ->
        Column(Modifier.padding(pad)) {
            OutlinedTextField(
                q, { vm.query.value = it }, singleLine = true,
                placeholder = { Text(stringResource(R.string.search_hint)) },
                leadingIcon = { Icon(Icons.Filled.Search, null) },
                modifier = Modifier.fillMaxWidth().padding(16.dp),
            )
            if (q.trim().length >= 2 && results.isEmpty()) {
                Text(stringResource(R.string.search_none), Modifier.padding(horizontal = 16.dp))
            }
            LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(results, key = { it.id }) { h ->
                    val cat = categoryOf(h)
                    Card(Modifier.fillMaxWidth().clickable { onPick(cat.name, h.id) }) {
                        Column(Modifier.padding(12.dp)) {
                            Text(h.brand, style = MaterialTheme.typography.titleMedium)
                            Text(
                                listOf(h.model.ifBlank { h.id }, h.protocol, stringResource(cat.labelRes)).joinToString(" · "),
                                style = MaterialTheme.typography.bodySmall,
                            )
                        }
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ IR blaster diagnostics
@HiltViewModel
class IrTestViewModel @Inject constructor(private val tx: IrTransmitter) : ViewModel() {
    val hasIr: Boolean = tx.isAvailable
    val ranges: List<IntRange> = tx.carrierRanges
    val sending = MutableStateFlow(false)
    val error = MutableStateFlow<String?>(null)

    /** 3 s of plain 38 kHz carrier (not a valid remote code, so no device reacts) to check the LED with a camera. */
    fun burst() {
        if (sending.value) return
        viewModelScope.launch {
            sending.value = true
            error.value = null
            try {
                val signal = IrSignal(38000, intArrayOf(20000, 5000))
                withContext(Dispatchers.Default) {
                    val end = System.currentTimeMillis() + 3000
                    while (System.currentTimeMillis() < end) { tx.transmit(signal); delay(25) }
                }
            } catch (e: Exception) { error.value = e.message ?: "IR error" }
            finally { sending.value = false }
        }
    }
}

@Composable
fun IrTestScreen(onBack: () -> Unit, vm: IrTestViewModel = hiltViewModel()) {
    val sending by vm.sending.collectAsStateWithLifecycle()
    val error by vm.error.collectAsStateWithLifecycle()
    Scaffold(topBar = { AppTopBar(stringResource(R.string.irt_title), onBack) }) { pad ->
        Column(Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(
                stringResource(if (vm.hasIr) R.string.irt_present else R.string.irt_missing),
                style = MaterialTheme.typography.titleMedium,
                color = if (vm.hasIr) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
            )
            if (vm.ranges.isNotEmpty()) {
                Text(
                    stringResource(R.string.irt_ranges, vm.ranges.joinToString(", ") { "${it.first / 1000}–${it.last / 1000} kHz" }),
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
            Button(onClick = vm::burst, enabled = vm.hasIr && !sending, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(if (sending) R.string.irt_sending else R.string.irt_burst))
            }
            Text(stringResource(R.string.irt_howto), style = MaterialTheme.typography.bodyMedium)
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            HorizontalDivider()
            Text(stringResource(R.string.tips_title), style = MaterialTheme.typography.titleSmall)
            Text(stringResource(R.string.tips_body), style = MaterialTheme.typography.bodySmall)
        }
    }
}

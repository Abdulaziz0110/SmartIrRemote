package com.smartir.remote.experimental

import kotlin.math.abs

/**
 * EXPERIMENTAL, standalone module (not wired into Auto Scan, so it cannot slow it down).
 * Detects significant brightness changes between consecutive luminance (Y) frames, e.g. from a
 * camera pointed at a display. It only works if the camera actually sees the screen and the
 * reaction is visible; otherwise it silently reports "no change".
 *
 * Feed it Y-plane bytes (e.g. from CameraX ImageAnalysis) from a background thread.
 */
class FrameChangeDetector(
    private val threshold: Double = 12.0,
    private val sampleStep: Int = 4,
    private val smoothing: Double = 0.2,
) {
    private var baseline: DoubleArray? = null
    private val grid = 16

    /** @return true when the frame differs significantly from the running baseline. */
    fun update(luma: ByteArray, width: Int, height: Int): Boolean {
        if (width < grid || height < grid || luma.size < width * height) return false
        val cur = DoubleArray(grid * grid)
        val cw = width / grid
        val ch = height / grid
        for (gy in 0 until grid) for (gx in 0 until grid) {
            var sum = 0L; var n = 0
            var y = gy * ch
            while (y < (gy + 1) * ch) {
                var x = gx * cw
                while (x < (gx + 1) * cw) {
                    sum += luma[y * width + x].toInt() and 0xFF; n++
                    x += sampleStep
                }
                y += sampleStep
            }
            cur[gy * grid + gx] = if (n == 0) 0.0 else sum.toDouble() / n
        }
        val base = baseline
        if (base == null) { baseline = cur; return false }
        var diff = 0.0
        for (i in cur.indices) diff += abs(cur[i] - base[i])
        diff /= cur.size
        for (i in cur.indices) base[i] = base[i] * (1 - smoothing) + cur[i] * smoothing
        return diff >= threshold
    }

    fun reset() { baseline = null }
}

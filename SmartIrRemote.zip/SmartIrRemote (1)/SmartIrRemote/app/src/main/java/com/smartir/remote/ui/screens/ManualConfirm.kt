package com.smartir.remote.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.smartir.remote.R
import com.smartir.remote.domain.Cmd
import com.smartir.remote.domain.CompatStatus

@Composable
fun ManualScreen(onBack: () -> Unit, onConfirm: (String, String) -> Unit, vm: ManualViewModel = hiltViewModel()) {
    val st by vm.state.collectAsStateWithLifecycle()
    var q by remember { mutableStateOf("") }
    Scaffold(topBar = { AppTopBar(stringResource(R.string.manual_title) + " · " + stringResource(vm.category.labelRes), onBack) }) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (!st.loading && st.brands.isEmpty()) item { Text(stringResource(R.string.manual_none)) }
            item {
                if (st.brands.isNotEmpty()) OutlinedTextField(
                    q, { q = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    label = { Text(stringResource(R.string.manual_brand) + " (" + st.brands.size + ")") },
                )
            }
            items(st.brands.filter { q.isBlank() || it.contains(q, ignoreCase = true) }) { b ->
                Card(Modifier.fillMaxWidth().clickable { vm.selectBrand(if (st.selected == b) null else b) }) {
                    Column(Modifier.padding(12.dp)) {
                        Text(b, style = MaterialTheme.typography.titleMedium)
                        if (st.selected == b) st.profiles.forEach { p ->
                            TextButton(onClick = { onConfirm(vm.category.name, p.id) }) {
                                Text("${p.model.ifBlank { p.id }} · ${p.protocol.name}")
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ConfirmScreen(onBack: () -> Unit, onSaved: (Long) -> Unit, vm: ConfirmViewModel = hiltViewModel()) {
    val st by vm.state.collectAsStateWithLifecycle()
    var showSave by remember { mutableStateOf(false) }
    Scaffold(
        topBar = { AppTopBar(stringResource(R.string.confirm_title), onBack) },
        bottomBar = {
            Surface(tonalElevation = 3.dp) {
                Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    val label = stringResource(st.status.labelRes)
                    Text(label, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                    Button(onClick = { showSave = true }, enabled = st.profile != null) { Text(stringResource(R.string.save_remote)) }
                }
            }
        },
    ) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                st.profile?.let { Text("${it.displayName} · ${it.protocol.name}", style = MaterialTheme.typography.titleMedium) }
                Text(stringResource(R.string.confirm_hint), style = MaterialTheme.typography.bodySmall)
                st.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
            items(st.rows, key = { it.cmd }) { row ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(Cmd.label(row.cmd), Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
                            if (row.available) FilledTonalButton(onClick = { vm.send(row.cmd) }) { Text(stringResource(R.string.send)) }
                            else Text(stringResource(R.string.not_in_profile), style = MaterialTheme.typography.bodySmall)
                        }
                        if (row.available) {
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(selected = row.works == true, onClick = { vm.mark(row.cmd, true) }, label = { Text(stringResource(R.string.works)) })
                                FilterChip(selected = row.works == false, onClick = { vm.mark(row.cmd, false) }, label = { Text(stringResource(R.string.not_works)) })
                            }
                            if (row.works == false && vm.hasAlternatives(row.cmd)) {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    OutlinedButton(onClick = { vm.tryAlternative(row.cmd) }) { Text(stringResource(R.string.try_alt)) }
                                    row.alt?.let { alt ->
                                        Text(alt.displayName, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                                        Button(onClick = { vm.useAlternative(row.cmd) }) { Text(stringResource(R.string.use_alt)) }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showSave) {
        var name by remember(st.profile) { mutableStateOf(st.profile?.displayName ?: "") }
        var fav by remember { mutableStateOf(false) }
        AlertDialog(
            onDismissRequest = { showSave = false },
            title = { Text(stringResource(R.string.save_remote)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(name, { name = it }, label = { Text(stringResource(R.string.remote_name)) }, singleLine = true)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(stringResource(R.string.favorite), Modifier.weight(1f))
                        Switch(fav, { fav = it })
                    }
                    Text(stringResource(st.status.labelRes), style = MaterialTheme.typography.labelMedium)
                }
            },
            confirmButton = { TextButton(onClick = { showSave = false; vm.save(name, fav, onSaved) }) { Text(stringResource(R.string.save)) } },
            dismissButton = { TextButton(onClick = { showSave = false }) { Text(stringResource(R.string.cancel)) } },
        )
    }
}

package com.smartir.remote

import com.smartir.remote.data.AppJson
import com.smartir.remote.data.model.ProfileFile
import com.smartir.remote.domain.*
import com.smartir.remote.ir.IrEncoder
import com.smartir.remote.scan.ScanPlanner
import org.junit.Assert.*
import org.junit.Test
import java.io.File

class ProfilesAndPlannerTest {
    private val profiles by lazy {
        AppJson.decodeFromString<ProfileFile>(File("src/main/assets/profiles/starter_tv.json").readText()).profiles
    }

    @Test fun starterProfilesAreValidAndEncodable() {
        assertTrue(profiles.isNotEmpty())
        for (p in profiles) {
            assertNull(p.id, IrEncoder.validate(p))
            for ((_, c) in p.commands) assertTrue(IrEncoder.encode(p, c).pattern.isNotEmpty())
        }
    }

    @Test fun plannerRefusesDangerousCommands() {
        for (c in listOf("POWER", "FACTORY_RESET", "SERVICE_MENU")) {
            assertThrows(IllegalArgumentException::class.java) {
                ScanPlanner.build(profiles, DeviceCategory.TV, c, true)
            }
        }
    }

    @Test fun plannerFiltersByCategoryAndCommand() {
        val tv = ScanPlanner.build(profiles, DeviceCategory.TV, Cmd.VOLUME_UP, false)
        assertEquals(profiles.count { Cmd.VOLUME_UP in it.commands }, tv.size)
        assertTrue(ScanPlanner.build(profiles, DeviceCategory.AIR_CONDITIONER, Cmd.TEMP_UP, true).isEmpty())
        // display falls back to TV profiles only when related categories are included
        assertTrue(ScanPlanner.build(profiles, DeviceCategory.INTERACTIVE_DISPLAY, Cmd.VOLUME_UP, false).isEmpty())
        assertEquals(tv.size, ScanPlanner.build(profiles, DeviceCategory.INTERACTIVE_DISPLAY, Cmd.VOLUME_UP, true).size)
    }

    @Test fun noCategoryScanCommandIsDangerous() {
        for (c in DeviceCategory.entries) for (cmd in c.testCommands) assertFalse("$c $cmd", Cmd.isDangerous(cmd))
    }

    @Test fun compatStatus() {
        assertEquals(CompatStatus.FULL, CompatStatus.compute(10, 10))
        assertEquals(CompatStatus.PARTIAL, CompatStatus.compute(10, 6))
        assertEquals(CompatStatus.UNVERIFIED, CompatStatus.compute(10, 0))
        assertEquals(CompatStatus.UNVERIFIED, CompatStatus.compute(0, 0))
    }
}

class PlannerDedupeTest {
    @Test fun identicalSignalsAreTestedOnce() {
        fun p(id: String, brand: String) = com.smartir.remote.data.model.IrProfile(
            id, brand, categories = listOf("TV"), protocol = com.smartir.remote.ir.IrProtocol.NEC, address = 4,
            commands = mapOf("VOLUME_UP" to com.smartir.remote.data.model.CommandDef(code = 2)),
        )
        val t = ScanPlanner.build(listOf(p("a", "A"), p("b", "B"), p("c", "C")), DeviceCategory.TV, Cmd.VOLUME_UP, false)
        assertEquals(1, t.size)
    }
}

class FlipperParserTest {
    private val sample = """
Filetype: IR signals file
Version: 1
#
name: Power
type: parsed
protocol: NEC
address: 04 00 00 00
command: 08 00 00 00
#
name: Vol_up
type: parsed
protocol: NEC
address: 04 00 00 00
command: 02 00 00 00
#
name: Vol_dn
type: parsed
protocol: Kaseikyo
address: 01 00 00 00
command: 02 00 00 00
#
name: Mute
type: parsed
protocol: Samsung32
address: 07 00 00 00
command: 0F 00 00 00
#
name: Temp_up
type: raw
frequency: 38000
duty_cycle: 0.33
data: 3500 1700 400 1300
""".trimIndent()

    @Test fun parsesSupportedAndSkipsUnsupported() {
        val ps = com.smartir.remote.data.repo.FlipperIrParser.parse(sample, listOf("TVs", "LG", "LG_42.ir"))
        val nec = ps.first { it.protocol == com.smartir.remote.ir.IrProtocol.NEC }
        assertEquals("LG", nec.brand)
        assertEquals(4, nec.address)
        assertEquals(8, nec.commands.getValue("POWER").code)
        assertEquals(2, nec.commands.getValue("VOLUME_UP").code)
        assertFalse(nec.commands.containsKey("VOLUME_DOWN")) // Kaseikyo not supported
        assertEquals(listOf("TV", "SMART_TV"), nec.categories)
        assertEquals(15, ps.first { it.protocol == com.smartir.remote.ir.IrProtocol.SAMSUNG }.commands.getValue("MUTE").code)
        assertTrue(ps.any { it.protocol == com.smartir.remote.ir.IrProtocol.RAW })
        ps.forEach { assertNull(com.smartir.remote.ir.IrEncoder.validate(it)) }
    }

    @Test fun categoryUsesTopFolderOnly() {
        assertEquals(listOf("AIR_CONDITIONER"), com.smartir.remote.data.repo.FlipperIrParser.categoryFor("ACs"))
        assertEquals(listOf("AUDIO"), com.smartir.remote.data.repo.FlipperIrParser.categoryFor("Audio_and_Video_Receivers"))
        assertEquals(listOf("OTHER"), com.smartir.remote.data.repo.FlipperIrParser.categoryFor("Misc"))
    }
}

class IrdbCsvAndNamesTest {
    @Test fun csvParsesAndKeepsExtraButtons() {
        val csv = "functionname,protocol,device,subdevice,function\nPOWER,NEC1,4,-1,8\nVOL+,NEC1,4,-1,2\nGuide,NEC1,4,-1,7\nMy Weird Key,NEC1,4,-1,9\nX,Foo,1,1,1\n"
        val ps = com.smartir.remote.data.repo.IrdbCsvParser.parse(csv, listOf("codes", "LG", "TV", "4,-1.csv"))
        assertEquals(1, ps.size)
        val p = ps.first()
        assertEquals("LG", p.brand)
        assertEquals(2, p.commands.getValue("VOLUME_UP").code)
        assertEquals(7, p.commands.getValue("GUIDE").code)
        assertTrue(p.commands.containsKey("MY_WEIRD_KEY"))
        assertNull(com.smartir.remote.ir.IrEncoder.validate(p))
    }

    @Test fun nonStandardNamesAreKeptNotDropped() {
        val n = com.smartir.remote.data.repo.FlipperIrParser
        assertEquals("VOLUME_UP", n.normName("Vol_up"))
        assertEquals("SMART_HUB", n.normName("Smart Hub"))
        assertEquals("HDMI_2", n.normName("HDMI 2"))
        assertNull(n.normName("***"))
    }

    @Test fun powerVariantsNeverUsedInScan() {
        assertTrue(Cmd.isDangerous("POWER_OFF"))
        assertTrue(Cmd.isDangerous("POWER_ON"))
    }
}

class NamesAndJsonTest {
    private val n = com.smartir.remote.data.repo.FlipperIrParser

    @Test fun plusMinusAndWordVariantsMapToStandardKeys() {
        assertEquals("VOLUME_UP", n.normName("Vol+"))
        assertEquals("VOLUME_DOWN", n.normName("Vol-"))
        assertEquals("VOLUME_UP", n.normName("Volume +"))
        assertEquals("VOLUME_DOWN", n.normName("Volume Down"))
        assertEquals("CHANNEL_UP", n.normName("CH+"))
        assertEquals("CHANNEL_DOWN", n.normName("Channel -"))
        assertEquals("UP", n.normName("Arrow Up"))
        assertEquals("MUTE", n.normName("Audio Mute"))
        assertEquals("POWER", n.normName("Standby"))
        assertEquals("NUM_5", n.normName("Num5"))
    }

    @Test fun volumeUpAndDownNeverCollide() {
        assertNotEquals(n.normName("Volume+"), n.normName("Volume-"))
    }

    @Test fun nec42Length() {
        assertEquals(2 + 84 + 1, com.smartir.remote.ir.Encoders.nec42(0x123, 0x45, false).pattern.size)
        assertEquals(2 + 84 + 1, com.smartir.remote.ir.Encoders.nec42(0x123, 0x4567, true).pattern.size)
    }

    private val one = """{"id":"a","brand":"X","categories":["TV"],"protocol":"NEC","address":4,"commands":{"VOLUME_UP":{"code":2}}}"""

    @Test fun parsesEveryContainerFormat() {
        val P = com.smartir.remote.data.repo.ProfileJson
        assertEquals(1, P.parse("""{"schema":1,"profiles":[$one]}""").profiles.size)
        assertEquals(1, P.parse("""{"schema":1,"remotes":[],"userProfiles":[$one]}""").profiles.size) // backup file
        assertEquals(1, P.parse("[$one]").profiles.size)
        assertEquals(1, P.parse(one).profiles.size)
        val bad = P.parse("""{"profiles":[$one,{"id":"broken"}]}""")
        assertEquals(1, bad.profiles.size); assertEquals(1, bad.skipped)
        assertThrows(Exception::class.java) { P.parse("""{"hello":1}""") }
    }
}

class CustomBuilderAndFilterTest {
    private val B = com.smartir.remote.domain.CustomProfileBuilder

    @Test fun parsesDecimalAndHex() {
        assertEquals(31, B.parseNumber("0x1F"))
        assertEquals(12, B.parseNumber(" 12 "))
        assertNull(B.parseNumber("zz"))
        assertNull(B.parseNumber(""))
    }

    @Test fun buildsValidNecProfileAndNormalizesKeys() {
        val r = B.build("c1", "Classroom", "StudyMax", DeviceCategory.INTERACTIVE_DISPLAY,
            com.smartir.remote.ir.IrProtocol.NEC, "0x04", "", 12, listOf("Vol+" to "2", "Power" to "0x08", "Mute" to ""))
        val p = r.profile!!
        assertEquals(setOf("VOLUME_UP", "POWER"), p.commands.keys)   // empty code skipped, names normalized
        assertEquals(4, p.address)
        assertEquals(listOf("INTERACTIVE_DISPLAY"), p.categories)
        assertNull(com.smartir.remote.ir.IrEncoder.validate(p))
    }

    @Test fun reportsErrors() {
        val nec = com.smartir.remote.ir.IrProtocol.NEC
        assertEquals(com.smartir.remote.domain.BuildError.ADDRESS, B.build("i", "n", "b", DeviceCategory.TV, nec, "x", "", 12, listOf("OK" to "1")).error)
        assertEquals(com.smartir.remote.domain.BuildError.NO_BUTTONS, B.build("i", "n", "b", DeviceCategory.TV, nec, "1", "", 12, listOf("OK" to "")).error)
        assertEquals(com.smartir.remote.domain.BuildError.BAD_CODE, B.build("i", "n", "b", DeviceCategory.TV, nec, "1", "", 12, listOf("OK" to "abc")).error)
        assertEquals(com.smartir.remote.domain.BuildError.INVALID, B.build("i", "n", "b", DeviceCategory.TV, nec, "1", "", 12, listOf("OK" to "300")).error)
    }

    @Test fun sonyBitsAreKept() {
        val p = B.build("s", "n", "b", DeviceCategory.TV, com.smartir.remote.ir.IrProtocol.SONY_SIRC, "1", "", 12, listOf("OK" to "101")).profile!!
        assertEquals(12, p.bits)
    }

    @Test fun scanBrandFilter() {
        fun prof(id: String, brand: String) = com.smartir.remote.data.model.IrProfile(
            id, brand, categories = listOf("TV"), protocol = com.smartir.remote.ir.IrProtocol.NEC, address = id.length,
            commands = mapOf("VOLUME_UP" to com.smartir.remote.data.model.CommandDef(code = 2)),
        )
        val all = listOf(prof("a", "Samsung"), prof("bb", "LG"), prof("ccc", "Samsung Pro"))
        assertEquals(3, ScanPlanner.build(all, DeviceCategory.TV, Cmd.VOLUME_UP, false).size)
        assertEquals(2, ScanPlanner.build(all, DeviceCategory.TV, Cmd.VOLUME_UP, false, "samsung").size)
        assertEquals(0, ScanPlanner.build(all, DeviceCategory.TV, Cmd.VOLUME_UP, false, "sony").size)
    }
}

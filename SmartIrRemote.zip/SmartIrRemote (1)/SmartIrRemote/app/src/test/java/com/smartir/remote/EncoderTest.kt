package com.smartir.remote

import com.smartir.remote.data.model.CommandDef
import com.smartir.remote.data.model.IrProfile
import com.smartir.remote.ir.*
import org.junit.Assert.*
import org.junit.Test

class EncoderTest {
    /** Decodes pulse-distance pairs (mark, space) starting at [from] into bytes, LSB first. */
    private fun bytes(p: IntArray, from: Int, bits: Int, oneThreshold: Int = 1000): List<Int> {
        val out = ArrayList<Int>()
        var cur = 0
        for (i in 0 until bits) {
            val space = p[from + i * 2 + 1]
            if (space > oneThreshold) cur = cur or (1 shl (i % 8))
            if (i % 8 == 7) { out += cur; cur = 0 }
        }
        return out
    }

    @Test fun necLgPower() {
        val s = Encoders.nec(0x04, 0x08, false)
        assertEquals(38000, s.frequency)
        assertEquals(67, s.pattern.size)
        assertEquals(9000, s.pattern[0]); assertEquals(4500, s.pattern[1])
        assertEquals(listOf(0x04, 0xFB, 0x08, 0xF7), bytes(s.pattern, 2, 32))
        assertEquals(560, s.pattern.last())
    }

    @Test fun necExtended() {
        val s = Encoders.nec(0x1234, 0x56, true)
        assertEquals(67, s.pattern.size)
        assertEquals(listOf(0x34, 0x12, 0x56, 0xA9), bytes(s.pattern, 2, 32))
    }

    @Test fun samsungVolumeUp() {
        val s = Encoders.samsung(0x07, 0x07)
        assertEquals(4500, s.pattern[0])
        assertEquals(listOf(0x07, 0x07, 0x07, 0xF8), bytes(s.pattern, 2, 32))
    }

    @Test fun sonyTwelveBitThreeFrames() {
        val s = Encoders.sony(1, 0, 18, 12)
        assertEquals(40000, s.frequency)
        // first frame: header(2) + 12 bits * 2 = 26 entries, start-to-start 45 ms
        assertEquals(45000, s.pattern.take(26).sum())
        var cmd = 0; var addr = 0
        for (i in 0 until 12) {
            val bit = if (s.pattern[2 + i * 2] > 900) 1 else 0
            if (i < 7) cmd = cmd or (bit shl i) else addr = addr or (bit shl (i - 7))
        }
        assertEquals(18, cmd); assertEquals(1, addr)
        assertEquals(26 * 3, s.pattern.size)
    }

    @Test fun rc5Timing() {
        val s = Encoders.rc5(0, 16)
        assertEquals(36000, s.frequency)
        assertTrue(s.pattern.all { it > 0 && it % 889 == 0 })
        assertEquals(14 * 1778 - 889, s.pattern.sum())
    }

    @Test fun rc6Leader() {
        val s = Encoders.rc6(0, 0x10)
        assertEquals(2664, s.pattern[0]); assertEquals(889, s.pattern[1])
    }

    @Test fun panasonicLength() {
        val s = Encoders.panasonic(0x100, 0x20)
        assertEquals(37000, s.frequency)
        assertEquals(2 + 96 + 1, s.pattern.size)
    }

    @Test fun jvcLength() {
        assertEquals(2 + 32 + 1, Encoders.jvc(0x03, 0x10).pattern.size)
    }

    @Test fun sharpTwoFrames() {
        val s = Encoders.sharp(1, 0x20)
        assertEquals(40000, s.pattern.take(32).sum())
        assertEquals(63, s.pattern.size)
    }

    @Test fun rawPassThrough() {
        val p = IrProfile("r", "X", categories = listOf("TV"), protocol = IrProtocol.RAW,
            commands = mapOf("A" to CommandDef(frequency = 36000, raw = listOf(100, 200, 300))))
        val s = IrEncoder.encode(p, p.commands.getValue("A"))
        assertEquals(36000, s.frequency)
        assertArrayEquals(intArrayOf(100, 200, 300), s.pattern)
        assertNull(IrEncoder.validate(p))
    }

    @Test fun validationRejectsOutOfRange() {
        val bad = IrProfile("n", "X", categories = listOf("TV"), protocol = IrProtocol.NEC, address = 4,
            commands = mapOf("A" to CommandDef(code = 300)))
        assertNotNull(IrEncoder.validate(bad))
        val sony = IrProfile("s", "X", categories = listOf("TV"), protocol = IrProtocol.SONY_SIRC, bits = 10,
            commands = mapOf("A" to CommandDef(code = 1)))
        assertNotNull(IrEncoder.validate(sony))
    }

    @Test fun patternAlwaysStartsWithMark() {
        for (s in listOf(Encoders.rc5(5, 70), Encoders.rc5(0, 1), Encoders.rc6(1, 1))) {
            assertTrue(s.pattern.isNotEmpty() && s.pattern[0] > 0)
        }
    }
}

package com.smartir.remote

import com.smartir.remote.data.model.CommandDef
import com.smartir.remote.data.model.IrProfile
import com.smartir.remote.ir.*
import com.smartir.remote.scan.*
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.*
import org.junit.Assert.*
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class ScanEngineTest {
    private fun TestScope.tick() { advanceTimeBy(500); runCurrent() }

    private class Fake : IrTransmitter {
        override val isAvailable = true
        val sent = mutableListOf<IrSignal>()
        override fun transmit(signal: IrSignal) { sent += signal }
    }

    private fun targets(n: Int) = (0 until n).map { i ->
        val p = IrProfile("p$i", "B$i", categories = listOf("TV"), protocol = IrProtocol.NEC, address = i,
            commands = mapOf("VOLUME_UP" to CommandDef(code = 2)))
        ScanTarget(p, IrEncoder.encode(p, p.commands.getValue("VOLUME_UP")))
    }

    @Test fun sendsOnePerDelayThenFinishes() = runTest {
        val tx = Fake()
        val e = ScanEngine(tx, backgroundScope, StandardTestDispatcher(testScheduler))
        e.load(targets(3), 1000)
        assertEquals(0, tx.sent.size) // nothing is sent before START
        e.start(); runCurrent()
        assertEquals(1, tx.sent.size)
        advanceTimeBy(1001); runCurrent()
        assertEquals(2, tx.sent.size)
        advanceTimeBy(1000); runCurrent()
        assertEquals(3, tx.sent.size)
        advanceTimeBy(1500); runCurrent()
        assertEquals(ScanStatus.FINISHED, e.state.value.status)
        assertEquals(3, tx.sent.size)
    }

    @Test fun foundStopsImmediatelyAndKeepsRecent() = runTest {
        val tx = Fake()
        val e = ScanEngine(tx, backgroundScope, StandardTestDispatcher(testScheduler))
        e.load(targets(10), 1000)
        e.start(); runCurrent()
        advanceTimeBy(2100); runCurrent()
        val before = tx.sent.size
        e.found(); runCurrent()
        assertEquals(ScanStatus.FOUND, e.state.value.status)
        advanceTimeBy(10_000); runCurrent()
        assertEquals(before, tx.sent.size)
        assertEquals((0 until before).toList(), e.state.value.recent)
    }

    @Test fun pauseResumeAndManualNavigation() = runTest {
        val tx = Fake()
        val e = ScanEngine(tx, backgroundScope, StandardTestDispatcher(testScheduler))
        e.load(targets(5), 1000)
        e.start(); runCurrent()
        e.pause(); tick()
        advanceTimeBy(5000); runCurrent()
        assertEquals(1, tx.sent.size)           // paused: nothing more is sent
        e.next(); tick()
        assertEquals(1, e.state.value.sentIndex)
        e.retest(); tick()
        assertEquals(3, tx.sent.size)
        e.previous(); tick()
        assertEquals(0, e.state.value.sentIndex)
        e.resume(); tick()
        assertEquals(1, e.state.value.sentIndex) // resumes after the current index
        e.stop(); runCurrent()
        val n = tx.sent.size
        advanceTimeBy(10_000); runCurrent()
        assertEquals(n, tx.sent.size)
    }

    @Test fun emptyTargetsDoNotTransmit() = runTest {
        val tx = Fake()
        val e = ScanEngine(tx, backgroundScope, StandardTestDispatcher(testScheduler))
        e.load(emptyList(), 1000)
        e.start(); runCurrent()
        assertEquals(ScanStatus.ERROR, e.state.value.status)
        assertTrue(tx.sent.isEmpty())
    }
}

package com.smartir.remote

import com.smartir.remote.experimental.FrameChangeDetector
import org.junit.Assert.*
import org.junit.Test

class FrameChangeDetectorTest {
    private fun frame(v: Int) = ByteArray(64 * 64) { v.toByte() }

    @Test fun detectsBrightnessJump() {
        val d = FrameChangeDetector()
        assertFalse(d.update(frame(40), 64, 64))
        assertFalse(d.update(frame(41), 64, 64))
        assertTrue(d.update(frame(200), 64, 64))
    }

    @Test fun ignoresTinyFrames() {
        assertFalse(FrameChangeDetector().update(ByteArray(4), 2, 2))
    }
}

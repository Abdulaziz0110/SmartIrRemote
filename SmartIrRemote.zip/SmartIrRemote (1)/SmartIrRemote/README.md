# Smart IR Remote

Universal IR pult ilovasi (Kotlin, Jetpack Compose, Material 3, MVVM + Clean-ish layering, Hilt, Room,
DataStore, Coroutines/StateFlow, `ConsumerIrManager`). Min SDK 26, target SDK 36, offline-first.

## Ishga tushirish
1. **Android Studio Meerkat (2024.3.2) yoki yangiroq**, JDK 17.
2. `File > Open` → `SmartIrRemote` papkasi. Gradle Sync avtomatik 8.11.1 ni yuklaydi
   (`gradle/wrapper/gradle-wrapper.properties`). `gradlew` skriptlari kiritilmagan; kerak bo'lsa
   terminalda `gradle wrapper --gradle-version 8.11.1` bajaring.
3. IR uzatkichli **haqiqiy telefon** (Redmi/Xiaomi) ulang va `Run`. Emulyatorda IR yo'q.
4. Unit testlar: `./gradlew testDebugUnitTest`.

> Muhim: bu loyiha yozilgan muhitda Android SDK/Gradle yo'q edi, shuning uchun kod **kompilyatsiya
> qilinmagan va testlar ishga tushirilmagan**. Kodlash mantig'i (RC5/Sony/Sharp vaqtlari) Python'da
> alohida tekshirilgan. Birinchi Sync'da kichik import/versiya xatolari chiqishi mumkin.

## Arxitektura
```
ir/        PulseBuilder, Encoders (NEC, NEC-ext, Samsung32, Sony SIRC 12/15/20, RC5, RC6,
           Panasonic/Kaseikyo, JVC, Sharp, RAW), IrEncoder (+validatsiya), AndroidIrTransmitter
data/      Room (profiles, remotes, scan_history), DataStore, repository'lar, JSON modellar
domain/    DeviceCategory (13 ta), Cmd (xavfli komandalar ro'yxati), CompatStatus
scan/      ScanPlanner (faqat ma'lum profillar), ScanEngine (state machine)
experimental/ FrameChangeDetector (kamera moduli, alohida)
ui/        Compose ekranlar: Home, Pick, Scan, Manual, Confirm, Remote, Remotes, Settings, History
```

## Auto Scan qanday ishlaydi
* Faqat START (yoki PREV/RETEST/NEXT) bosilganda signal ketadi; STOP/PAUSE/FOUND IT darhol to'xtatadi.
* Ro'yxat cheklangan: bazadagi tekshirilgan profillar. Random brute-force yo'q.
* `POWER`, `FACTORY_RESET`, `SERVICE_MENU` va h.k. avto-sinovda rad etiladi (`Cmd.DANGEROUS`, testlangan).
* Kodlar orasidagi kutish 0.5–10 s (standart 2 s); har uzatish tugamaguncha keyingisi boshlanmaydi.
  Konditsioner (stateful) uchun minimal 3 s, `TEMP_UP` sinov komandasi va ogohlantirish.
* FOUND IT! bosilganda uzatish to'xtaydi, oxirgi 8 kod saqlanadi, ularni qayta sinab "Aynan shu" tanlanadi.
* Confirm: Vol+/-, Mute, Menu, OK, Back, yo'nalishlar uchun WORKS / DOESN'T WORK → Fully / Partially /
  Unverified. Ishlamagan tugma uchun boshqa profildan "Try alternative" → "Use this" (remote'da override).
* Sessiyani tiklash: jarayon uzilsa, Scan ekranida "Resume previous session" chiqadi.

## Profil bazasi — minglab brendni qo'shish
Ilova bilan faqat 4 ta brendli **starter** to'plam keladi (men faqat aniq bilgan kodlarni kiritdim; boshqalarini
"to'qib chiqarish" soxta profil bo'lardi). Katta baza ochiq manbalardan olinadi:

| Manba | Litsenziya | Hajmi |
|---|---|---|
| `UberGuidoZ/Flipper-IRDB` (`.ir`) | CC0-1.0 | minglab qurilma: TV, AC, proyektor, audio... |
| `probonopd/irdb` (`.csv`) | CC0-1.0 | minglab kod |

Har safar repozitoriy litsenziyasini o'zingiz tekshiring.

```
git clone --depth 1 https://github.com/UberGuidoZ/Flipper-IRDB
python tools/build_profiles.py Flipper-IRDB --out-dir app/src/main/assets/profiles --source "UberGuidoZ/Flipper-IRDB"
```
1. Skript `db_001.json, db_002.json...` fayllarini yaratadi (1500 profildan). Qo'llab-quvvatlanmaydigan
   protokollar (masalan Kaseikyo `.ir`) o'tkazib yuboriladi va hisobotda ko'rsatiladi.
2. Fayllarni `assets/profiles/` ga qo'ying, `ProfileRepository.SEED_VERSION` ni oshiring (1 → 2) va qayta qurib o'rnating.
   Yoki fayllarni telefonga ko'chirib **Settings → Import IR profiles** orqali bir nechtasini birdan tanlang.
3. Skriptga `--keep-unknown` bersangiz nostandart tugma nomlari ham saqlanadi ("Other" bo'limida chiqadi).

Katta baza bilan ishlash: profillar kategoriya bo'yicha bazadan olinadi; Auto Scan bir xil signalni takror
sinamaydi (turli modellar ko'pincha bir xil kod ishlatadi), shuning uchun vaqt profillar sonidan kamroq bo'ladi.
Eng yangi Smart TV'lar ko'pincha WiFi/Bluetooth orqali boshqariladi — baza IR kodlarigina beradi; IR
qabul qiladigan modellar uchun ishlaydi.

## Cheklovlar (halol ro'yxat)
* Kamera aniqlash (`FrameChangeDetector`) faqat mustaqil, testlangan modul; CameraX UI'ga ulanmagan.
* Interactive Display skanerlashda TV profillari ishlatiladi (Settings'siz, "related categories" tumbleri).
* RC5/RC6 toggle biti doim 0; Panasonic/Sharp tuzilmalari soddalashtirilgan umumiy variantlar.
* AC uchun stateful (to'liq holat) protokollar yo'q — faqat RAW buyruqlar profil sifatida import qilinadi.
* Custom layout: tugmalarni yashirish/ko'rsatish (Edit layout). Tartibni o'zgartirish yo'q.

## Yangi imkoniyatlar (v1.1)
* **Ikki manba:** Settings → "IR bazani yuklab olish" Flipper-IRDB va probonopd/irdb (ikkalasi CC0) ni yuklaydi.
  Barcha qurilma turlari (TV, AC, proyektor, audio, fan, LED...) bir yo'la keladi; kategoriya kartochkalarida
  nechta profil borligi ko'rinadi, Auto Scan faqat bazada mavjud sinov komandalarini yoqadi (har birining soni bilan).
* **Barcha tugmalar saqlanadi:** nostandart nomli tugmalar ham yo'qolmaydi ("Other" bo'limida); rang tugmalari,
  Info, Guide, Sleep, Netflix va boshqa funksiyalar uchun alohida bo'lim bor. Eski saqlangan pultlar bazani qayta
  yuklagach yangi tugmalarni avtomatik oladi.
* **Pult ekrani:** tugmani bosib turish = takrorlash (ovoz, kanal, yo'nalish, harorat), telefonning ovoz tugmalari
  bilan boshqarish, ekran o'chmasligi, tugmalarni yashirish, qayta nomlash.
* **Makrolar:** bir nechta tugmani ketma-ket yuborish (masalan Power → Source), qadamlar orasidagi kutish bilan.
* **Taymer:** komandani N daqiqadan keyin yuborish (ilova ochiq turganda ishlaydi).
* **Qidiruv va filtr:** Pultlarim va Qo'lda qidirishda; kategoriya bo'yicha filtr.

## Bazani ilovaning ichiga statik joylash (internetsiz)
`app/src/main/assets/profiles/*.json` ichidagi hamma fayl birinchi ochilishda avtomatik, qatorma-qator (kam xotira)
o'qilib bazaga yoziladi; faqat fayllar o'zgarsa qayta o'qiladi. Yuklash tugmasi ixtiyoriy yangilash uchun qoladi.
1. Telefonda bir marta bazani yuklang (Settings → IR bazani yuklab olish), so'ng **Barcha profillarni eksport** — `smart_ir_profiles.json`.
2. Kompyuterda: `python tools/split_export.py smart_ir_profiles.json app/src/main/assets/profiles --per-file 2000`
   (yoki `tools/build_profiles.py` bilan to'g'ridan-to'g'ri Flipper-IRDB/irdb dan).
3. Qayta quring. APK hajmi biroz oshadi (JSON siqiladi). Manba litsenziyalari CC0 — baribir `README` da manbani ko'rsating.

## Yangi imkoniyatlar (v1.2)
1. **O'z pultimni yaratish** (Bosh sahifa → "O'z pultim"): protokol, adres va har tugma kodi; har kodni ▶ bilan sinash mumkin.
2. **Matn orqali import** (Settings): Flipper `.ir` matni, profil JSON'i yoki ulashilgan pultni joylash.
3. **Pultni ulashish** (pult menyusi): pult + uning profillari matn sifatida boshqa telefonga yuboriladi.
4. **Hammasidan qidirish**: brend/model bo'yicha butun bazada, kategoriyasidan qat'i nazar.
5. **Sevimlilar** bosh sahifada alohida qatorda.
6. **Ilova ikonkasidan tezkor pult**: ikonkani bosib turing, sevimli/oxirgi pultlar chiqadi.
7. **IR tekshiruv**: diod bor-yo'qligi, qo'llab-quvvatlanadigan chastotalar, kamera bilan ko'rish uchun 3 s sinov signali.
8. **Skanerda brend filtri**: brendni bilsangiz, faqat o'sha profillar sinaladi (ancha tez).
9. **Tasdiqlangan tugmalar belgisi (✓)** pult ekranida.
10. **Birinchi ochilishda yo'riqnoma**.
11. **Skanerda tebranish tiki**: telefonga qaramay ritmni his qilasiz.

Eslatma: brend filtri yoqilganda sessiyani tiklash o'chiq (ro'yxat to'liq ro'yxatdan farq qiladi).
